﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class AssetCSVLoader : MonoBehaviour
	{
        public TextAsset CSVText = null;

        [SerializeField]
        protected CSVDataTable m_TableData = null;
        void LoadAssetCSVDataLoad()
        {
            m_TableData = new CSVDataTable();
            m_TableData.Load(CSVText);
            
        }


		void Start()
		{
            LoadAssetCSVDataLoad();

        }

		void Update()
		{
			
		}
	}
}