This is an attempt at porting the python google spreadsheet data client

Original source at: 
http://code.google.com/p/gdata-python-client/source/browse/src/gdata/spreadsheet/text_db.py

[![Please donate](http://www.pledgie.com/campaigns/11248.png)](http://www.pledgie.com/campaigns/11248)