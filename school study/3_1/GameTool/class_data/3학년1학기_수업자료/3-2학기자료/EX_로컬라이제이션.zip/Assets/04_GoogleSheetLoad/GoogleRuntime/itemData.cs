using UnityEngine;
using System.Collections;

///
/// !!! Machine generated code !!!
/// !!! DO NOT CHANGE Tabs to Spaces !!!
///
[System.Serializable]
public class itemData
{
  [SerializeField]
  string key;
  public string Key { get {return key; } set { key = value;} }
  
  [SerializeField]
  string valuea;
  public string Valuea { get {return valuea; } set { valuea = value;} }
  
  [SerializeField]
  string testval;
  public string Testval { get {return testval; } set { testval = value;} }
  
}