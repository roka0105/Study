﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Du3Project
{
	public class UI_Google_Bottom : MonoBehaviour
	{

        public int TempVal = 10;
        public string TempVal2 = "가나다";

        public Text LinkLocalText = null;
        public Text LinkChangeText = null;

        public void UIChangeUpdate(E_LocalType p_type)
        {
            // CONTEXT_ErrorMsg
            string tempstr2 = p_type.ToString();
            LinkLocalText.text = tempstr2;

            // CONTEXT_Test{0}_{1}
            string tempstr = GoogleLocalizationManager.GetI.GetCurrentKeyString("CONTEXT_Test{0}_{1}");
            LinkChangeText.text = string.Format(tempstr, TempVal, TempVal2);
        }


        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}