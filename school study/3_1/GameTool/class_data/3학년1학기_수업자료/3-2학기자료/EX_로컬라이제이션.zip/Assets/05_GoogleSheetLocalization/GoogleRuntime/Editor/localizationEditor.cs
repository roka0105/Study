using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using GDataDB;
using GDataDB.Linq;

using UnityQuickSheet;

///
/// !!! Machine generated code !!!
///
[CustomEditor(typeof(localization))]
public class localizationEditor : BaseGoogleEditor<localization>
{	    
    public override bool Load()
    {        
        localization targetData = target as localization;
        
        var client = new DatabaseClient("", "");
        string error = string.Empty;
        var db = client.GetDatabase(targetData.SheetName, ref error);	
        var table = db.GetTable<localizationData>(targetData.WorksheetName) ?? db.CreateTable<localizationData>(targetData.WorksheetName);
        
        List<localizationData> myDataList = new List<localizationData>();
        
        var all = table.FindAll();
        foreach(var elem in all)
        {
            localizationData data = new localizationData();
            
            data = Cloner.DeepCopy<localizationData>(elem.Element);
            myDataList.Add(data);
        }
                
        targetData.dataArray = myDataList.ToArray();
        
        EditorUtility.SetDirty(targetData);
        AssetDatabase.SaveAssets();
        
        return true;
    }
}
