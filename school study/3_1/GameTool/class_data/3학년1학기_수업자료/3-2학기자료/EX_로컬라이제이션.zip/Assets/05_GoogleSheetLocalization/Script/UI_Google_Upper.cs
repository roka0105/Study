﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Du3Project
{
	public class UI_Google_Upper : MonoBehaviour
	{
        public Text LinkTest01 = null;
        public Text LinkNoneKey = null;

        public void UIChangeUpdate(E_LocalType p_type)
        {
            // CONTEXT_Test01
            string tempstr = GoogleLocalizationManager.GetI.GetCurrentKeyString("CONTEXT_Test01");
            LinkTest01.text = tempstr;

            string tempstr2 = GoogleLocalizationManager.GetI.GetCurrentKeyString("CONTEXT_Test01_None");
            LinkNoneKey.text = tempstr2;
        }

        private void OnDestroy()
        {
            // 코드 등록 방식
            GoogleLocalizationManager.GetI.RemoveLocalization(UIChangeUpdate);
        }

        private void Awake()
        {
            // 코드 등록 방식
            GoogleLocalizationManager.GetI.AddLocalization(UIChangeUpdate);
        }

        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}