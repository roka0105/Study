using UnityEngine;
using System.Collections;

///
/// !!! Machine generated code !!!
/// !!! DO NOT CHANGE Tabs to Spaces !!!
///
[System.Serializable]
public class localizationData
{
  [SerializeField]
  string stringid;
  public string STRINGID { get {return stringid; } set { stringid = value;} }
  
  [SerializeField]
  string description;
  public string DESCRIPTION { get {return description; } set { description = value;} }
  
  [SerializeField]
  string english;
  public string ENGLISH { get {return english; } set { english = value;} }
  
  [SerializeField]
  string simplifiedchinese;
  public string SIMPLIFIEDCHINESE { get {return simplifiedchinese; } set { simplifiedchinese = value;} }
  
  [SerializeField]
  string korean;
  public string KOREAN { get {return korean; } set { korean = value;} }
  
}