﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class GoogleSheetLoader : MonoBehaviour
	{
        public localization SheetLocalizationData = new localization();


        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}