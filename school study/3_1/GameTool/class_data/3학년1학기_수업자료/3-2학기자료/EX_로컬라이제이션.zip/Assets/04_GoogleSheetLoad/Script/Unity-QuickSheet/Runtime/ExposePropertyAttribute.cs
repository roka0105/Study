using UnityEngine;
using System;
using System.Collections;
 
[AttributeUsage( AttributeTargets.Property )]
public class ExposePropertyAttribute : Attribute
{
 
}