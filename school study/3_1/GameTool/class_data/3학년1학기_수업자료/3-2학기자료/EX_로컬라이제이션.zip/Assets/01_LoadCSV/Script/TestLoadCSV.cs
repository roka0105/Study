﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
    // https://welcomeheesuk.tistory.com/34
    public class TestLoadCSV : MonoBehaviour
    {

        void InitLoadCSV()
        {
            // 데이터 형태
            //name,age,speed,description
            //cat,2,4.5,"cat stalks, jumps and meows"
            //dog,2,5.5,dog barks
            //fish,1,1.1,fish swims

            List<Dictionary<string, object>> csvdata = CSVReader.Read("testdata");

            string tempstr = (string)csvdata[0]["name"];
            string descriptionstr = (string)csvdata[0]["description"];

            Debug.LogFormat("[{0}], [{1}], [{2}], [{3}]"
                , csvdata[0]["name"]
                , csvdata[0]["age"]
                , csvdata[0]["speed"]
                , csvdata[0]["description"]);
        }


        void Start()
        {
            InitLoadCSV();

        }

        void Update()
        {

        }
    }
}