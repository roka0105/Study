﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Du3Project
{
    public class UI_Test_Upper : MonoBehaviour
    {
        public Text LinkTest01 = null;
        public Text LinkNoneKey = null;


        public void UIChangeUpdate(E_LocalType p_type)
        {
            // CONTEXT_Test01
            string tempstr = LocalizationManager.GetI.GetCurrentKeyString("CONTEXT_Test01");
            LinkTest01.text = tempstr;

            string tempstr2 = LocalizationManager.GetI.GetCurrentKeyString("CONTEXT_Test01_None");
            LinkNoneKey.text = tempstr2;

        }

        private void OnDestroy()
        {
            // 코드 등록 방식
            LocalizationManager.GetI.RemoveLocalization(UIChangeUpdate);
        }

        private void Awake()
        {
            // 코드 등록 방식
            LocalizationManager.GetI.AddLocalization(UIChangeUpdate);
        }

        void Start()
        {

        }

        //void Update()
        //{

        //}
    }
}