﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Du3Project
{
	public class GoogleLocalizationManager : Singleton_Mono<GoogleLocalizationManager>
    {
        [Header("[이벤트용]")]
        public LocalizationChangeEvent LocalizationEvent;


        [Header("[로딩용데이터]")]
        public localization SheetLocalizationData = null;

        protected Dictionary<string, Dictionary<E_LocalType, string>> m_Localization = new Dictionary<string, Dictionary<E_LocalType, string>>();


        public void _On_KorChangeLocalization()
        {
            ChangeLocalization(E_LocalType.Korean);
        }

        public void _On_EngChangeLocalization()
        {
            ChangeLocalization(E_LocalType.Eng);
        }

        public void _On_ChinaChangeLocalization()
        {
            ChangeLocalization(E_LocalType.China);
        }

        [SerializeField]
        protected E_LocalType m_CurrentLocalType = E_LocalType.Korean;
        public void ChangeLocalization(E_LocalType p_type)
        {
            m_CurrentLocalType = p_type;
            //m_CurrentLocalType
            // 전체 이벤트들 호출하기
            LocalizationEvent.Invoke(m_CurrentLocalType);
        }

        public void AddLocalization(UnityAction<E_LocalType> p_actionfn)
        {
            LocalizationEvent.AddListener(p_actionfn);
        }
        public void RemoveLocalization(UnityAction<E_LocalType> p_actionfn)
        {
            LocalizationEvent.RemoveListener(p_actionfn);
        }
        public void RemoveAllLocalization()
        {
            LocalizationEvent.RemoveAllListeners();
        }


        public void GoogleLoadLocalizationData()
        {
            string tempkeystr = "";
            Dictionary<E_LocalType, string> tempkeydic = null;
            
            localizationData[] dataarr = SheetLocalizationData.dataArray;
            int count = dataarr.Length;
            for (int i=0; i<count; ++i)
            {
                tempkeystr = dataarr[i].STRINGID;
                tempkeydic = new Dictionary<E_LocalType, string>();

                tempkeydic.Add(E_LocalType.Korean, dataarr[i].KOREAN);
                tempkeydic.Add(E_LocalType.Eng, dataarr[i].ENGLISH);
                tempkeydic.Add(E_LocalType.China, dataarr[i].SIMPLIFIEDCHINESE);
                m_Localization.Add(tempkeystr, tempkeydic);
            }

            ChangeLocalization(m_CurrentLocalType);
        }


        public string GetCurrentKeyString(string p_stringid)
        {
            if (!m_Localization.ContainsKey(p_stringid))
            {
                return string.Format("Error NoneString : {0}", p_stringid);
            }

            return m_Localization[p_stringid][m_CurrentLocalType];
        }


        private void Awake()
        {
            GoogleLoadLocalizationData();

        }

        void Start()
        {
            ChangeLocalization(m_CurrentLocalType);

        }
    }
}