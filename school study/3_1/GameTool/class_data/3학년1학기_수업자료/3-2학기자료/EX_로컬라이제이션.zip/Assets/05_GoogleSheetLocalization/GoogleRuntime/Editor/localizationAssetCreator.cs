using UnityEngine;
using UnityEditor;
using System.IO;
using UnityQuickSheet;

///
/// !!! Machine generated code !!!
/// 
public partial class GoogleDataAssetUtility
{
    [MenuItem("Assets/Create/Google/localization")]
    public static void CreatelocalizationAssetFile()
    {
        localization asset = CustomAssetUtility.CreateAsset<localization>();
        asset.SheetName = "testconnect";
        asset.WorksheetName = "localization";
        EditorUtility.SetDirty(asset);        
    }
    
}