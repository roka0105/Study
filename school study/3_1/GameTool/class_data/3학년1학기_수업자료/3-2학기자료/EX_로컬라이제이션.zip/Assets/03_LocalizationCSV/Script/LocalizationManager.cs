﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

namespace Du3Project
{
    // 이벤트 사용하기 위한 클래스
    [System.Serializable]
    public class LocalizationChangeEvent : UnityEvent<E_LocalType>
    {

    }

    public enum E_LocalType
    {
        Korean = 0,
        Eng,
        China,

        Max
    }


    public class LocalizationManager : Singleton_Mono<LocalizationManager>
    {
        // 이벤트용
        [Header("[이벤트용]")]
        public LocalizationChangeEvent LocalizationEvent;


        [Header("[로딩용데이터]")]
        public LocalizationCSVData LocalizationCSVData = new LocalizationCSVData();
        public TextAsset LoalizationCSVFile;

        protected Dictionary<string, Dictionary<E_LocalType, string>> m_Localization = new Dictionary<string, Dictionary<E_LocalType, string>>();


        public void _On_KorChangeLocalization()
        {
            ChangeLocalization(E_LocalType.Korean);
        }

        public void _On_EngChangeLocalization()
        {
            ChangeLocalization(E_LocalType.Eng);
        }

        public void _On_ChinaChangeLocalization()
        {
            ChangeLocalization(E_LocalType.China);
        }

        [SerializeField]
        protected E_LocalType m_CurrentLocalType = E_LocalType.Korean;
        public void ChangeLocalization(E_LocalType p_type)
        {
            m_CurrentLocalType = p_type;
            //m_CurrentLocalType
            // 전체 이벤트들 호출하기
            LocalizationEvent.Invoke(m_CurrentLocalType);
        }

        public void AddLocalization(UnityAction<E_LocalType> p_actionfn)
        {
            LocalizationEvent.AddListener(p_actionfn);
        }
        public void RemoveLocalization(UnityAction<E_LocalType> p_actionfn)
        {
            LocalizationEvent.RemoveListener(p_actionfn);
        }
        public void RemoveAllLocalization()
        {
            LocalizationEvent.RemoveAllListeners();
        }


        protected void InitLoadLocalizationData()
        {
            LocalizationCSVData.Load(LoalizationCSVFile);

            List<LocalizationCSVData.Row> rowalldatalist = LocalizationCSVData.GetRowList();
            int count = rowalldatalist.Count;
            string tempkeystr = "";
            Dictionary<E_LocalType, string> tempkeydic = null;
            for (int i = 0; i < count; ++i)
            {
                tempkeystr = rowalldatalist[i].STRING_ID;
                tempkeydic = new Dictionary<E_LocalType, string>();
                tempkeydic.Add(E_LocalType.Korean, rowalldatalist[i].KOREAN);
                tempkeydic.Add(E_LocalType.Eng, rowalldatalist[i].ENGLISH);
                tempkeydic.Add(E_LocalType.China, rowalldatalist[i].SIMPLIFIED_CHINESE);
                //tempkeydic.Add(E_LocalType.Korean, rowalldatalist[i].DESCRIPTION);
                m_Localization.Add(tempkeystr, tempkeydic);
            }

        }


        public string GetCurrentKeyString(string p_stringid)
        {
            if (!m_Localization.ContainsKey(p_stringid))
            {
                return string.Format("Error NoneString : {0}", p_stringid);
            }

            return m_Localization[p_stringid][m_CurrentLocalType];
        }


        private void Awake()
        {
            InitLoadLocalizationData();

        }

        void Start()
        {
            ChangeLocalization(m_CurrentLocalType);

        }

    }
}