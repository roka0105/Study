﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class LocalizationLoader : MonoBehaviour
	{
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}