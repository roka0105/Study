﻿using System;

[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
public class EX_AudioClipAttribute : UnityEngine.PropertyAttribute
{
    
}
