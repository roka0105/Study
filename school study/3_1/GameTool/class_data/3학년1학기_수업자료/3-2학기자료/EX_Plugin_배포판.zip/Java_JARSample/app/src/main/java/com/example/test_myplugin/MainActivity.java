package com.example.test_myplugin;

//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//
//
//// jar 플러그인 개발용
//// http://www.santacodes.com/?p=105
//
//
//// classes.jar 위치를 확인
//// https://docs.unity3d.com/kr/2018.1/Manual/AndroidUnityPlayerActivity.html
//
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//}



// build.gradle 이용한 빌드이후
// libs 폴더에 있는 jar파일 인식됨

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import java.util.Arrays;


// http://www.santacodes.com/?p=105
public class MainActivity extends UnityPlayerActivity
{

    @Override
    protected  void onCreate(Bundle p_saveInstanceState)
    {
        super.onCreate(p_saveInstanceState);

        Log.d("Unity Call", "onCreate: "   );

        // 초기화에서 강제로 호출하기 위한 방식임
        MainActivity.UnityActivityInst = this;
    }


    public void UnityCallFN( String p_callobj, String p_callfn, String p_val  )
    {
        String tempstr = String.join(", ", p_callobj, p_callfn, p_val);
        Log.d("Unity Call", "UnityCallFN: " + tempstr  );

        // UnitySendMessage
        // var0 : 호출대상의 되는 현재 씬의 게임오브젝트 이름
        // var1 : 첫번째 파라미터의 이름의 GameObject에 존재하는 메소드이름
        // var2 : 두번째 파라미터의 메소드에 전달할 파라미터
        UnityPlayer.UnitySendMessage(p_callobj, p_callfn, p_val);
    }

    public void TestMethod()
    {
        Log.d("Unity Call", "TestMethod 1 : "  );
        UnityPlayer.UnitySendMessage("JARPluginManager"
            , "PrintMessage", "Test Method");
    }

    public int TestMethod(int p_val)
    {
        Log.d("Unity Call", "TestMethod 2 : " +  String.valueOf(p_val) );
        return  p_val;
    }

    public void TestMethod( String p_val)
    {
        Log.d("Unity Call", "TestMethod 3 : " +  p_val );

        // UnitySendMessage
        // var0 : 호출대상의 되는 현재 씬의 게임오브젝트 이름
        // var1 : 첫번째 파라미터의 이름의 GameObject에 존재하는 메소드이름
        // var2 : 두번째 파라미터의 메소드에 전달할 파라미터
        UnityPlayer.UnitySendMessage("JARPluginManager"
            , "PrintMessage", p_val);
    }



    public static UnityPlayerActivity UnityActivityInst = null;
    // 스택틱 방식임
    public static UnityPlayerActivity GetI()
    {
        Log.d("Unity Call", "GetI  : " +  UnityActivityInst );
        return MainActivity.UnityActivityInst;
    }


    // 콜백 방식임
    public static void ShowToast(String message, String p_callobj, String p_callfn )
    {
        String tempstr = String.join(", ", message, p_callobj, p_callfn);
        Log.d("Unity Call", "ShowToast : " +  tempstr );

        // 화면 팝업용
        Toast.makeText(UnityPlayer.currentActivity, message, Toast.LENGTH_SHORT).show();

        // 유니티 호출용 함수
        UnityPlayer.UnitySendMessage(
                // game object name
                p_callobj,
                // function name
                p_callfn,
                // arguments
                "Displayed toast with message: " + message
        );
    }


}





