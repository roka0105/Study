﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class Test_DLLImport : MonoBehaviour
	{

		void Start()
		{
            Debug.LogFormat("DllImport : {0}", UnityDLLExportSample.MyClass.Random(100));
		}

		void Update()
		{
			
		}
	}
}