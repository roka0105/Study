﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityImportNExport;

namespace Du3Project
{
	public class Test_UnityDLLImport : MonoBehaviour
	{
        public List<int> m_TestRand = new List<int>();

		void Start()
		{
            for (int i=0; i<10; ++i)
            {
                m_TestRand.Add(i);
            }

            int testrand = m_TestRand.RandomRange();
            Debug.LogFormat("DLL Test ListRandomRange : {0}", testrand );
            Debug.LogFormat("DLL GameObjet Name : {0}", TestDLL.GetName(this.gameObject) );
        }

		void Update()
		{
			
		}
	}
}