﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{

    // androidmanifest.xml 방식을 잘 처리해야지됨
    // https://jhedde.tistory.com/entry/Unity-Android-Java-%ED%94%8C%EB%9F%AC%EA%B7%B8%EC%9D%B8-%EB%B6%99%EC%9D%B4%EA%B8%B0-1


    // 안드로이드 실행시 관리자 권한으로 실행해야지됨
    // 안드로이드 패키지 package com.example.test_myplugin; 이걸 참고로 호출하면됨
    // 안드로이드 build.gradle 사용시 오른쪽 윗부분 코끼리 모양 클릭하면 빌드 익스포터들 만들어짐



    public class JARPluginManager : MonoBehaviour
    {
        private AndroidJavaObject m_JavaObject;
        AndroidJavaClass m_Class = null;


        void Awake()
        {

        }

        void Start()
        {
            Debug.LogFormat("JARPluginManager Start : ");
            StartCoroutine(DelayCreateJavaActivite());

        }

        // 로드할 시간을 주도록 하기위한 값임
        // 안드로이드에서 호출 하도록 하면 간단히 처리도됨
        IEnumerator DelayCreateJavaActivite()
        {
            yield return new WaitForSeconds(1f);
            CreateJavaActive();
            yield break;
        }

        void CreateJavaActive()
        {
            // 로드방법 1
            // "com.unity3d.player.UnityPlayer" <- 직접 읽어들이기위한 값임 xml 파일 상관없이 읽어들이게됨
            var jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            Debug.LogFormat("Start JavaObject 0 : {0}", jc);
            // currentActivity <- 현재 진행되는 active용
            // 클래스 등이 적용 되도록 처리해서 사용하기
            // 현재 클래스가 어떤 클래스 인지 모르겠음
            m_JavaObject = jc.GetStatic<AndroidJavaObject>("currentActivity");
            Debug.LogFormat("Start JavaObject 1 : {0}", m_JavaObject);



            // 로드방법 2
            // java 소스의 package용으로 적용하면 되는지 매니패스트에 관련된 값으로 해야지 읽어 들일수 있음
            m_Class = new AndroidJavaClass("com.example.test_myplugin.MainActivity");
            Debug.LogFormat("Start JavaObject 2 : {0}", m_Class);


            // 로드 안됨 자바에서 오류 로그캣으로 확인 가능함
            AndroidJavaClass class2 = new AndroidJavaClass("com.example.test_myplugin");
            Debug.LogFormat("Start JavaObject 3 : {0}", class2);
        }


        void OnGUI()
        {
            if (GUI.Button(new Rect(0.0f, 0.0f, 720.0f, 90.0f), "Test Method 1"))
            {
                Debug.Log("call 01 : ");
                // 현재 Activity에 존재하는 TestMethod를 호출한다.
                m_JavaObject.Call("TestMethod");
            }

            if (GUI.Button(new Rect(0.0f, 100.0f, 720.0f, 90.0f), "Test Method 2"))
            {
                Debug.Log("call 02 : ");
                // 현재 Activity에 존재하는 TestMethod를 호출하고 int 타입의 값을 반환 받는다.
                var result = m_JavaObject.Call<int>("TestMethod", 777);
                Debug.Log("Result = " + result);
            }

            if (GUI.Button(new Rect(0.0f, 200.0f, 720.0f, 90.0f), "Test Method 3"))
            {
                Debug.Log("call 03 : ");
                // 현재 Activity에 존재하는 TestMethod에 파라미터를 함께 전달한다.
                //m_JavaObject.Call("TestMethod", "Hello Native Plugin");

                if (m_JavaObject != null)
                    m_JavaObject.CallStatic("ShowToast", "토스트확인", this.name, "ResiveFN");
                else
                {
                    Debug.LogError("call 03 ERROR -- : ");
                }
            }

            if (GUI.Button(new Rect(0.0f, 300.0f, 720.0f, 90.0f), "Test Method 4"))
            {
                Debug.Log("call 04 : ");
                m_JavaObject.Call("UnityCallFN", this.gameObject.name, "ResiveFN", "testaa");
            }

            if (GUI.Button(new Rect(0.0f, 400.0f, 720.0f, 90.0f), "Android Toast"))
            {
                Debug.Log("call 05 : ");
                m_Class.CallStatic("ShowToast", "토스트확인", this.name, "ResiveFN");
                Debug.Log("call 05 End : ");
            }

            if (GUI.Button(new Rect(0.0f, 500.0f, 720.0f, 90.0f), "GetI"))
            {
                Debug.Log("call 06 : ");
                AndroidJavaObject javaobj = m_Class.CallStatic<AndroidJavaObject>("GetI");
                Debug.LogFormat("CallJava getI : {0}", javaobj);
                if (javaobj != null)
                {
                    javaobj.Call("UnityCallFN", this.gameObject.name, "ResiveFN", "testaa");
                }
                else
                {
                    Debug.LogFormat("CallJava getI : Null Data");
                }

            }


        }

        private void ResiveFN(string p_msg)
        {
            Debug.Log("AndroidManager::ResiveFN - " + p_msg);
        }
        private void PrintMessage(string msg)
        {
            Debug.Log("AndroidManager::PrintMessage - " + msg);
        }




        //void Update()
        //{

        //}
    }
}