﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using System;

namespace Du3Project
{
	public class CPluginTest : MonoBehaviour
	{
        // DllImport 사용법 제대로 알아야지됨
        // 실시간 로드 방식임
        [DllImport("C++DLLSample")]
        public static extern int Example(int p_val, int p_val2);
        [DllImport("C++DLLSample")]
        public static extern IntPtr DLL_GetStr(IntPtr p_src);
        [DllImport("C++DLLSample")]
        public static extern IntPtr Dll_VectorAdd(float[] p_src, float[] p_dest);


        void Start()
		{
            int tempval = Example(100, 200);

            Debug.LogFormat("C++ DLLSample Int : {0}", tempval);

            Vector3 vec01 = new Vector3(1, 2, 3);
            Vector3 vec02 = new Vector3(5, 6, 7);
            float[] vec001 = new float[3];
            float[] vec002 = new float[3];
            float[] outvec = new float[3];
            vec001[0] = vec01[0];
            vec001[1] = vec01[1];
            vec001[2] = vec01[2];
            vec002[0] = vec02[0];
            vec002[1] = vec02[1];
            vec002[2] = vec02[2];


            // 배열이 포인터로만 반환하기때문에 이방법을 이용함
            // https://stackoverflow.com/questions/30399339/marshalling-float-array-to-c-sharp
            IntPtr p_outval = Dll_VectorAdd(vec001, vec002);
            Marshal.Copy((IntPtr)p_outval, outvec, 0, 3);

            Debug.LogFormat("C++ Dll_VectorAdd Array : {0}, {1}, {2}, {3}"
                , p_outval
                , outvec[0]
                , outvec[1]
                , outvec[2]
                );


            string tempstr = "abd123";
            IntPtr ptr = DLL_GetStr( GetStringIntPtr(tempstr) );

            //Marshal.PtrToStructure()

            // Marshal 링에 관련된 정보
            // https://comphy.tistory.com/434
            // C++ 구조체를 C# 구조체로 사용하기 위한 중간 방법에 대한 부분
            // http://egloos.zum.com/seraph4021/v/4728982
            Debug.LogFormat("C++ DLL Return String : {0}"
                , Marshal.PtrToStringAuto(ptr) );


            // http://blog.naver.com/PostView.nhn?blogId=seilgogo&logNo=220839267579&parentCategoryNo=&categoryNo=&viewDate=&isShowPopularPosts=false&from=postView
            // 마샬용 정보
            // HANDLE, void*, Pointer -> IntPtr
            //byte, unsigned char   -> Byte
            //short                 -> short
            //WORD, unsigned short  -> ushort
            //int                   -> int
            //UINT, unsigned int    -> uint
            //long                  -> int
            //BOOL, long            -> int
            //DWORD, unsigned long  -> uint
            //char                  -> char
            //LPSTR, char*          -> string or StringBuilder
            //LPCSTR, const char*   -> string or StringBuilder
            //BSTR                  -> string
            //float                 -> float
            //double                -> double;
            //HRESULT               -> int
            //VARIANT               -> object

        }

        IntPtr GetStringIntPtr(string p_src )
        {
            return Marshal.StringToCoTaskMemAuto(p_src);

        }

		void Update()
		{
			
		}
	}
}