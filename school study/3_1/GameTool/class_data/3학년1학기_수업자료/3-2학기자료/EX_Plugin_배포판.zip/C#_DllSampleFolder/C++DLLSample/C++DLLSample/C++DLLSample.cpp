﻿// C++DLLSample.cpp : DLL 응용 프로그램을 위해 내보낸 함수를 정의합니다.
//

#include "stdafx.h"
#include "stdio.h"
#include "C++DLLSample.h"

//namespace C_DLLSample
//{
extern "C"
{
	// dll export 를 하더라도 using 으로 사용할수는 없는 상태임

	// C++ DLL => C# DLL Import 방식에서 처리할것들
	// C# DLL Import 적용시 에러나는것 수정부분
	// 언어를 CLR로 바꿔야지됨
	// https ://marufloor.tistory.com/79

	// dll을 강제로 unity folder 로 바로 copy를 적용하려고 하는데 바로 적용안되고있음
	// *** 유니티에서 dll을 한번 잡고있으면 복사를 못하게됨 강제로 복사하는 옵션 찾아야지됨 ***


	CDLLTEST_API int Example(int p_a, int p_b)
	{
		return p_a + p_b;
	}

	CDLLTEST_API float* Dll_VectorAdd(float p_src[], float* p_dest)
	{
		p_src[0] += p_dest[0];
		p_src[1] += p_dest[1];
		p_src[2] += p_dest[2];
		return p_src;
	}

	CDLLTEST_API LPCTSTR DLL_GetStr(LPCTSTR p_str)
	{
		return p_str;
	}


}


//}