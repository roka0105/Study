﻿using System;
using System.Collections.Generic;
using UnityEngine;

// C:\Program Files\Unity\Hub\Editor\2018.3.5f1\Editor\Data\UnityExtensions\Unity\GUISystem\UnityEngine.UI.dll
using UnityEngine.UI;


namespace UnityImportNExport
{

    public static class CameraExtensions
    {
        //******Orthographic Camera Only******//
        public static Vector2 BoundsMin(this Camera camera)
        {
            return (Vector2)camera.transform.position - camera.Extents();
        }
        public static Vector2 BoundsMax(this Camera camera)
        {
            return (Vector2)camera.transform.position + camera.Extents();
        }

        public static Vector2 Extents(this Camera camera)
        {
            if (camera.orthographic)
                return new Vector2(camera.orthographicSize * Screen.width / Screen.height, camera.orthographicSize);
            else
            {
                Debug.LogError("Camera is not orthographic!", camera);
                return new Vector2();
            }
        }

        public static Bounds OrthographicBounds(this Camera camera)
        {
            float screenAspect = (float)Screen.width / (float)Screen.height;
            float cameraHeight = camera.orthographicSize * 2;
            Bounds bounds = new Bounds(
                camera.transform.position,
                new Vector3(cameraHeight * screenAspect, cameraHeight, 0));
            return bounds;
        }
        //*****End of Orthographic Only*****//
    }


    public static class EX
    {
        //static public Vector3 


        static private Vector3 m_TempVector3 = UnityEngine.Vector3.zero;
        static public UnityEngine.Vector3 Vector3One
        {
            get
            {
                m_TempVector3.x = m_TempVector3.y = m_TempVector3.z = 1f;
                return m_TempVector3;
            }
        }
        static public UnityEngine.Vector3 Vector3val
        {
            get
            {
                m_TempVector3.x = m_TempVector3.y = m_TempVector3.z = 0f;
                return m_TempVector3;
            }
            //set { m_TempVector3 = value; }
        }

        static public UnityEngine.Vector3 Vector3V(float p_x, float p_y, float p_z)
        {
            m_TempVector3.x = p_x;
            m_TempVector3.y = p_y;
            m_TempVector3.z = p_z;

            return m_TempVector3;
        }


        static private Vector2 m_TempVector2 = UnityEngine.Vector2.zero;
        static public UnityEngine.Vector2 Vector2val
        {
            get
            {
                m_TempVector2.x = m_TempVector2.y = 0f;
                return m_TempVector2;
            }
        }
        static public UnityEngine.Vector2 Vector2One
        {
            get
            {
                m_TempVector2.x = m_TempVector2.y = 1f;
                return m_TempVector2;
            }
        }

        static public UnityEngine.Vector3 Vector2V(float p_x, float p_y, float p_z)
        {
            m_TempVector2.x = p_x;
            m_TempVector2.y = p_y;

            return m_TempVector2;
        }



        static private Vector2Int m_TempVectorInt = Vector2Int.zero;
        static public Vector2Int Vector2Intval
        {
            get
            {
                m_TempVectorInt.x = m_TempVectorInt.y = 0;
                return m_TempVectorInt;
            }
        }

        static public Vector2Int Vector2V(int p_x, int p_y)
        {
            m_TempVectorInt.x = p_x;
            m_TempVectorInt.y = p_y;

            return m_TempVectorInt;
        }

    }

    public static class ShortcutExtensions
    {
        public static void SetLabel(this Button p_btn, string p_label)
        {
            Text label = p_btn.GetComponentInChildren<Text>();
            if (label != null)
            {
                label.text = p_label;
            }
            else
            {
                Debug.LogError("SetLabel NullData : " + p_btn.name);
            }

        }

        public static void SetActiveSelf(this UnityEngine.GameObject p_gameobj, bool p_flag)
        {
            if (p_gameobj == null)
            {
                Debug.LogErrorFormat("SetActive Null GameObj :");
                return;
            }

            if (p_gameobj.activeSelf != p_flag)
                p_gameobj.SetActive(p_flag);
        }

    }





    [System.Serializable]
    public class TransformData
    {
        [SerializeField]
        protected Vector3 m_LocalPos;
        [SerializeField]
        protected Vector3 m_LocalRot;
        [SerializeField]
        protected Vector3 m_LocalScale;
        [SerializeField]
        protected Quaternion m_LocalQuatern;





        public void SetLocalRot(Vector3 p_rot)
        {
            m_LocalRot = p_rot;
            m_LocalQuatern = Quaternion.Euler(m_LocalRot);
        }

        public void SetLocalRot(float px, float py, float pz)
        {
            m_LocalRot.x = px;
            m_LocalRot.y = py;
            m_LocalRot.z = pz;
            m_LocalQuatern = Quaternion.Euler(m_LocalRot);
        }

        public void SetLocalRot(Quaternion p_qua)
        {
            m_LocalQuatern = p_qua;
            m_LocalRot = p_qua.eulerAngles;
        }

        public void SetTransformData(Transform p_transform)
        {
            m_LocalPos = p_transform.localPosition;
            m_LocalScale = p_transform.localScale;
            m_LocalQuatern = p_transform.localRotation;
            m_LocalRot = m_LocalQuatern.eulerAngles;
        }
        public UnityEngine.Vector3 LocalPos
        {
            get { return m_LocalPos; }
            set { m_LocalPos = value; }
        }

        //     public UnityEngine.Vector3 LocalRot
        //     {
        //         get { return m_LocalRot; }
        //         set { m_LocalRot = value; }
        //     }

        public UnityEngine.Vector3 LocalScale
        {
            get { return m_LocalScale; }
            set { m_LocalScale = value; }
        }

        public UnityEngine.Vector3 LocalRot
        {
            get { return m_LocalRot; }
        }
        public UnityEngine.Quaternion LocalQuatern
        {
            get { return m_LocalQuatern; }
        }
    }


    public static class RectTransformExtensions
    {

        public static void SetTransData(this Transform p_transform, Transform p_data)
        {
            p_transform.localScale = p_data.localScale;
            p_transform.localRotation = p_data.localRotation;
            p_transform.localPosition = p_data.localPosition;
        }

        public static void GetTransData(this Transform p_transform, ref TransformData p_data)
        {
            p_data.LocalPos = p_transform.localPosition;
            p_data.LocalScale = p_transform.localScale;
            p_data.SetLocalRot(p_transform.localRotation);
        }

        public static void SetTransData(this Transform p_transform, TransformData p_data)
        {
            p_transform.localScale = p_data.LocalScale;
            p_transform.localRotation = p_data.LocalQuatern;
            p_transform.localPosition = p_data.LocalPos;
        }

        public static void SetLayerRecursive(this Transform trans, int p_layerindex)
        {
            trans.gameObject.layer = p_layerindex;
            int count = trans.childCount;
            for (int i = 0; i < count; ++i)
            {
                trans.GetChild(i).SetLayerRecursive(p_layerindex);
            }

        }

        public static void SetDefaultScale(this RectTransform trans)
        {
            trans.localScale = new Vector3(1, 1, 1);
        }
        public static void SetPivotAndAnchors(this RectTransform trans, Vector2 aVec)
        {
            trans.pivot = aVec;
            trans.anchorMin = aVec;
            trans.anchorMax = aVec;
        }

        public static Vector2 GetSize(this RectTransform trans)
        {
            return trans.rect.size;
        }
        public static float GetWidth(this RectTransform trans)
        {
            return trans.rect.width;
        }
        public static float GetHeight(this RectTransform trans)
        {
            return trans.rect.height;
        }

        private static Vector3 m_TempVec = new Vector3(0f, 0f, 0f);
        public static void SetPositionOfPivot(this RectTransform trans, Vector2 newPos)
        {
            //trans.localPosition = new Vector3(newPos.x, newPos.y, trans.localPosition.z);
            m_TempVec.x = newPos.x;
            m_TempVec.y = newPos.y;
            m_TempVec.z = trans.localPosition.z;
            trans.localPosition = m_TempVec;
        }

        public static void SetLeftBottomPosition(this RectTransform trans, Vector2 newPos)
        {
            //trans.localPosition = new Vector3(newPos.x + (trans.pivot.x * trans.rect.width), newPos.y + (trans.pivot.y * trans.rect.height), trans.localPosition.z);
            m_TempVec.x = newPos.x + (trans.pivot.x * trans.rect.width);
            m_TempVec.y = newPos.y + (trans.pivot.y * trans.rect.height);
            m_TempVec.z = trans.localPosition.z;
            trans.localPosition = m_TempVec;
        }
        public static void SetLeftTopPosition(this RectTransform trans, Vector2 newPos)
        {
            //trans.localPosition = new Vector3(newPos.x + (trans.pivot.x * trans.rect.width), newPos.y - ((1f - trans.pivot.y) * trans.rect.height), trans.localPosition.z);

            m_TempVec.x = newPos.x + (trans.pivot.x * trans.rect.width);
            m_TempVec.y = newPos.y - ((1f - trans.pivot.y) * trans.rect.height);
            m_TempVec.z = trans.localPosition.z;
            trans.localPosition = m_TempVec;
        }
        public static void SetRightBottomPosition(this RectTransform trans, Vector2 newPos)
        {
            //trans.localPosition = new Vector3(newPos.x - ((1f - trans.pivot.x) * trans.rect.width), newPos.y + (trans.pivot.y * trans.rect.height), trans.localPosition.z);
            m_TempVec.x = newPos.x - ((1f - trans.pivot.x) * trans.rect.width);
            m_TempVec.y = newPos.y + (trans.pivot.y * trans.rect.height);
            m_TempVec.z = trans.localPosition.z;
            trans.localPosition = m_TempVec;
        }
        public static void SetRightTopPosition(this RectTransform trans, Vector2 newPos)
        {
            //trans.localPosition = new Vector3(newPos.x - ((1f - trans.pivot.x) * trans.rect.width), newPos.y - ((1f - trans.pivot.y) * trans.rect.height), trans.localPosition.z);
            m_TempVec.x = newPos.x - ((1f - trans.pivot.x) * trans.rect.width);
            m_TempVec.y = newPos.y - ((1f - trans.pivot.y) * trans.rect.height);
            m_TempVec.z = trans.localPosition.z;
            trans.localPosition = m_TempVec;
        }

        public static void SetSize(this RectTransform trans, Vector2 newSize)
        {
            Vector2 oldSize = trans.rect.size;
            Vector2 deltaSize = newSize - oldSize;
            m_TempSize.x = deltaSize.x * trans.pivot.x;
            m_TempSize.y = deltaSize.y * trans.pivot.y;
            //trans.offsetMin = trans.offsetMin - new Vector2(deltaSize.x * trans.pivot.x, deltaSize.y * trans.pivot.y);
            trans.offsetMin = trans.offsetMin - m_TempSize;

            m_TempSize.x = deltaSize.x * (1f - trans.pivot.x);
            m_TempSize.y = deltaSize.y * (1f - trans.pivot.y);
            //trans.offsetMax = trans.offsetMax + new Vector2(deltaSize.x * (1f - trans.pivot.x), deltaSize.y * (1f - trans.pivot.y));
            trans.offsetMax = trans.offsetMax + m_TempSize;
        }

        public static void SetSize(this RectTransform trans, float p_width, float p_height)
        {
            m_TempSize.x = p_width;
            m_TempSize.y = p_height;
            SetSize(trans, m_TempSize);
        }


        private static Vector2 m_TempSize = new Vector2(0f, 0f);
        public static void SetWidth(this RectTransform trans, float newSize)
        {
            m_TempSize.x = newSize;
            m_TempSize.y = trans.rect.size.y;
            SetSize(trans, m_TempSize);
        }
        public static void SetHeight(this RectTransform trans, float newSize)
        {
            m_TempSize.x = trans.rect.size.x;
            m_TempSize.y = newSize;
            SetSize(trans, m_TempSize);
        }

        public static float RandomRange(this Vector2 p_vec)
        {
            return UnityEngine.Random.Range(p_vec.x, p_vec.y);
        }



    }



    public static class ListExtra
    {
        public static T RandomRange<T>(this List<T> list)
        {
            int index = UnityEngine.Random.Range(0, list.Count);
            return list[index];
        }

        public static T RandomRange<T>(this T[] p_array)
        {
            int index = UnityEngine.Random.Range(0, p_array.Length);
            return p_array[index];
        }
    }


}
