﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace UnityDLLExportSample
{
    public class MyClass
    {
        public static int Random(int p_min, int p_max)
        {
            System.Random rand = new System.Random();
            return rand.Next(p_min, p_max);
        }

        public static int Random(int p_max)
        {
            System.Random rand = new System.Random();
            return rand.Next(p_max);
        }



    }
}
