﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace UnityImportNExport
{
    public class TestDLL
    {
        public static string GetName(GameObject p_obj)
        {
            return p_obj.name;
        }

    }
}
