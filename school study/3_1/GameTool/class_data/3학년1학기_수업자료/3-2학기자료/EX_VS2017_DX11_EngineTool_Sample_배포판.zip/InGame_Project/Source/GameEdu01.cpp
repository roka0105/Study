#include "StdAfx.h"
#include "GameEdu01.h"
#include "Triangle.h"
#include "macroheader.h"

CGameEdu01::CGameEdu01(void)
{
}

CGameEdu01::~CGameEdu01(void)
{
	SAFE_DELETE(m_Triangle);
}

void CGameEdu01::OnInit()
{
	CTriangle* triangle = new CTriangle();
	m_Triangle = triangle;

	m_Triangle->OnInit(m_pd3dDevice);

}

void CGameEdu01::OnRender()
{
	m_Triangle->OnRender();
}

void CGameEdu01::OnUpdate()
{
	
}

void CGameEdu01::OnRelease()
{
	m_Triangle->OnRelease();

}