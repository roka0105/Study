#pragma once
#include <D3DApp.h>


// ���漱��
class ObjectNode;
class MeshBase;


class CGameEdu01 : public CD3DApp
{
	virtual void OnInit();
	virtual void OnRender();
	virtual void OnUpdate();
	virtual void OnRelease();

public:
	CGameEdu01(void);
	~CGameEdu01(void);


private:
	MeshBase* m_Triangle = NULL;


};

