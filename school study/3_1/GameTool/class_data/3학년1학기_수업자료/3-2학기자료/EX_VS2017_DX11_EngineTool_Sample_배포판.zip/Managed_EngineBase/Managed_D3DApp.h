﻿#pragma once
#include <D3DApp.h>


using namespace System;

namespace ManagedEngineBase
{
	public class Managed_D3DApp : public CD3DApp
	{
	public:
		Managed_D3DApp(void);
		virtual ~Managed_D3DApp(void);

	private:
		virtual void OnInit();
		virtual void OnRender();
		virtual void OnUpdate();
		virtual void OnRelease();

	};

}

