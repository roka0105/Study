﻿#pragma once
#using <system.drawing.dll>
using namespace System;
using namespace System::Drawing;


// clr 기본 베이스용
// https://eastroot1590.tistory.com/entry/C-%ED%8A%9C%ED%86%A0%EB%A6%AC%EC%96%BC-1C-Tutorial-1


namespace ManagedEngineBase 
{
	class Managed_D3DApp;
	//struct Color;

	public ref class Managed_D3DEngine
	{
		Managed_D3DApp* m_D3DApp = nullptr;

	public:
		void OnInit( IntPtr p_hwnd, int p_width, int p_height );
		void OnRender();
		void OnUpdate();
		void OnRelease();


		void MainLoop();
		bool MessageProc(IntPtr hWnd, int uMsg, IntPtr wParam, IntPtr lParam);

		// c# 자료형 포인터 형으로 가지고 오는 방법 ^
		void ChangeColor(Color p_bgcolor);
		Color GetBGColor();


		// ^ 키워드 사용하기
		//Color^ GetBGColorPTR();
		//void ChangeColorPTR(Color^ p_bgcolor);

	protected:
		bool m_ISExitFlag = false;
	};

	/*public ref class MeshBase
	{
	public:
	};*/

	public __interface IInterface
	{
	public:
		void M2CResive(int p_val);
		void C2MSend(int p_val);

	};
}
