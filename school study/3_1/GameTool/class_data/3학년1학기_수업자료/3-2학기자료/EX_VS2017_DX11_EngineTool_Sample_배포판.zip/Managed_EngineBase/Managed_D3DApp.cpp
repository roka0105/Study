#include "stdafx.h"
#include "Managed_D3DApp.h"

namespace ManagedEngineBase
{
	Managed_D3DApp::Managed_D3DApp(void)
	{
	}

	Managed_D3DApp::~Managed_D3DApp(void)
	{
	}

	void Managed_D3DApp::OnInit()
	{

	}

	void Managed_D3DApp::OnRender()
	{
	}

	void Managed_D3DApp::OnUpdate()
	{
	}

	void Managed_D3DApp::OnRelease()
	{
	}

}



