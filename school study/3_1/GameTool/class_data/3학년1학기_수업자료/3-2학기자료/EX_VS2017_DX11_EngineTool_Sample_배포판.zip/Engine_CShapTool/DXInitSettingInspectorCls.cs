﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;



// http://www.gisdeveloper.co.kr/?p=226
// https://docs.microsoft.com/en-us/previous-versions/dotnet/articles/aa302326(v=msdn.10)?redirectedfrom=MSDN

// c++ propertygrid
// https://docs.microsoft.com/ko-kr/dotnet/api/system.windows.forms.propertygrid?view=netframework-4.8


// 프로퍼티 그리드 사용설명 대략 적으로 나온것
// http://whiteat.com/WhiteAT_Csharp/34124
namespace Engine_CShapTool
{
    public class SpellingOptionsConverter : ExpandableObjectConverter
    {
        public override bool CanConvertTo(ITypeDescriptorContext context,
                                  System.Type destinationType)
        {
            if (destinationType == typeof(SpellingOptions))
                return true;

            return base.CanConvertTo(context, destinationType);
        }

        //public override object ConvertTo(ITypeDescriptorContext context,
        //                       CultureInfo culture,
        //                       object value,
        //                       System.Type destinationType)
        //{
        //    if (destinationType == typeof(System.String) &&
        //         value is SpellingOptions)
        //    {

        //        SpellingOptions so = (SpellingOptions)value;

        //        return "Check while typing:" + so.SpellCheckWhileTyping +
        //               ", check CAPS: " + so.SpellCheckCAPS +
        //               ", suggest corrections: " + so.SuggestCorrections;
        //    }
        //    return base.ConvertTo(context, culture, value, destinationType);
        //}

        public override bool CanConvertFrom(ITypeDescriptorContext context,
                              System.Type sourceType)
        {
            if (sourceType == typeof(string))
                return true;

            return base.CanConvertFrom(context, sourceType);
        }
    }

    [TypeConverterAttribute(typeof(SpellingOptionsConverter)), DescriptionAttribute("Expand to see the spelling options for the application.")]
    public class SpellingOptions
    {
        private bool spellCheckWhileTyping = true;
        private bool spellCheckCAPS = false;
        private bool suggestCorrections = true;

        [DefaultValueAttribute(true)]
        public bool SpellCheckWhileTyping
        {
            get { return spellCheckWhileTyping; }
            set { spellCheckWhileTyping = value; }
        }

        [DefaultValueAttribute(false)]
        public bool SpellCheckCAPS
        {
            get { return spellCheckCAPS; }
            set { spellCheckCAPS = value; }
        }
        [DefaultValueAttribute(true)]
        public bool SuggestCorrections
        {
            get { return suggestCorrections; }
            set { suggestCorrections = value; }
        }
    }

    



    class DXInitSettingInspectorCls
    {
        private bool saveOnClose = true;
        private string greetingText = "Welcome to your application!";
        private int itemsInMRU = 4;
        private int maxRepeatRate = 10;
        private bool settingsChanged = false;
        private string appVersion = "1.0";
        private Color m_BGColor = new Color();

        public bool SaveOnClose
        {
            get { return saveOnClose; }
            set { saveOnClose = value; }
        }
        public string GreetingText
        {
            get { return greetingText; }
            set { greetingText = value; }
        }
        public int MaxRepeatRate
        {
            get { return maxRepeatRate; }
            set { maxRepeatRate = value; }
        }
        public int ItemsInMRUList
        {
            get { return itemsInMRU; }
            set { itemsInMRU = value; }
        }

        [CategoryAttribute("Global Settings")]
        public bool SettingsChanged
        {
            get { return settingsChanged; }
            set { settingsChanged = value; }
        }
        public string AppVersion
        {
            get { return appVersion; }
            set { appVersion = value; }
        }

        public Color BGColor
        {
            get
            {
                return m_BGColor;
            }
            set
            {
                m_BGColor = value;

            }
        }

    }
}
