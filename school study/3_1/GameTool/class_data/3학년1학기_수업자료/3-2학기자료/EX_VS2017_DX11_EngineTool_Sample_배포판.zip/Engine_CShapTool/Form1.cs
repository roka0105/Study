﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ManagedEngineBase;


// 에러 사항들
// System.BadImageFormatException
// clr사용시 에러사항
// https://bigenergy.tistory.com/673 빌드 속성x86으로 맞추면됨


namespace Engine_CShapTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeSetting();
            InitInspectorPropertyGrid();

            Application.Idle += UpdatePanel;
        }
        
        protected override void WndProc(ref Message m)
        {
            //if (m_ManagedEngineBase != null)
            //{
            //    m_ManagedEngineBase.MessageProc(this.Handle, m.Msg, m.WParam, m.LParam);
            //    //m_ManagedEngineBase.MainLoop();
            //}
            
            base.WndProc(ref m);
        }


        DXInitSettingInspectorCls m_DXSettingInspectorCls = null;// new DXInitSettingInspectorCls();
        //DXInitSettingInspectorCls m_DXSettingInspectorCls2 = null;// new DXInitSettingInspectorCls();
        void InitInspectorPropertyGrid()
        {
            m_DXSettingInspectorCls = new DXInitSettingInspectorCls();
            //m_DXSettingInspectorCls2 = new DXInitSettingInspectorCls();
            //object[] arrobj = new object[] { m_DXSettingInspectorCls, m_DXSettingInspectorCls2 };
            //inspectorgrid.SelectedObjects = arrobj;
            inspectorgrid.SelectedObject = m_DXSettingInspectorCls;

            //inspectorgrid.PropertyValueChanged += inspectorgrid_ValueChange;


            // https://docs.microsoft.com/en-us/previous-versions/dotnet/articles/aa302326(v=msdn.10)?redirectedfrom=MSDN
            Color bgcol = m_ManagedEngineBase.GetBGColor();
            m_DXSettingInspectorCls.BGColor = bgcol;
        }

        Managed_D3DEngine m_ManagedEngineBase = new Managed_D3DEngine();
        void InitializeSetting()
        {
            m_ManagedEngineBase.OnInit( dxpanel.Handle, dxpanel.Width, dxpanel.Height );


            // dx연결하기
            //dxpanel.Handle
            //m_ManagedEngineBase.
            //Managed_D3DApp m_ManagedEngineBase = new Managed_D3DApp();


            // 업데이트
            m_ManagedEngineBase.OnUpdate();
            m_ManagedEngineBase.OnRender();


            // C++ 방식으로 루프 처리하는것 작업 해두도록 하기
            //while (true)
            //{
            //    // GetMessage
            //    if (PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) // 메시지 루프빠지지않고 한번 찾아내는 방식의 함수
            //    {
            //        if (msg.message == WM_QUIT)
            //            break;

            //        TranslateMessage(&msg);
            //        DispatchMessage(&msg);
            //    }
            //    else
            //    {
            //        // 업데이트및 렌더링
            //        //Render();
            //        g_GameEdu01.Update();
            //        g_GameEdu01.Render();

            //    }
            //}


        }

        void UpdatePanel(object sender, EventArgs e)
        {
            m_ManagedEngineBase.OnUpdate();
            m_ManagedEngineBase.OnRender();
        }
        private void dxpanel_Paint(object sender, PaintEventArgs e)
        {
            m_ManagedEngineBase.OnUpdate();
            m_ManagedEngineBase.OnRender();
        }

        private void inspectorgrid_ValueChange(object s, PropertyValueChangedEventArgs e)
        {
            if(e.ChangedItem.Label == "BGColor")
            {
                if(e.ChangedItem.Value is Color)
                {
                    Color bgcol = (Color)e.ChangedItem.Value;
                    m_ManagedEngineBase.ChangeColor(bgcol);
                }
            }
        }

        private void inspectorgrid_Click(object sender, EventArgs e)
        {
            Color bgcol = m_ManagedEngineBase.GetBGColor();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // https://makemethink.tistory.com/131
            // 키보드 입력시 Form 속성에서 keypreview 속성값 True로 해야지됨

            Debug.Write("키 눌림 : ");
            //if (e.KeyCode == Keys.A)
            //    e.SuppressKeyPress = true;
        }
    }
}
