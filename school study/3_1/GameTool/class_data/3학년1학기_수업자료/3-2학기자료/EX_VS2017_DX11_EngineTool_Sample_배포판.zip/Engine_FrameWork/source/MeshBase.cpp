#include "MeshBase.h"

MeshBase::MeshBase()
{
}

MeshBase::~MeshBase()
{
}

void MeshBase::OnInit(LPDIRECT3DDEVICE9 pd3dDevice)
{

}

void MeshBase::OnRender()
{

}

void MeshBase::OnRelease()
{

}
