#pragma once
#include <d3d9.h>

class MeshBase
{
public:
	MeshBase();
	virtual ~MeshBase();

public:
	virtual void OnInit(LPDIRECT3DDEVICE9  pd3dDevice);
	virtual void OnRender();
	virtual void OnRelease();


};

