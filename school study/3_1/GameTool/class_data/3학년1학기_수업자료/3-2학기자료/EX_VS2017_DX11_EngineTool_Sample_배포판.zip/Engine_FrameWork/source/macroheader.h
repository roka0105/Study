#pragma once


#ifndef IN
#define IN
#endif //	IN

#ifndef OUT
#define OUT
#endif //	OUT


#define SAFE_DELETE( p )	{delete (p); (p) = NULL;}

#define SAFE_ADELETE( p )	{delete[] (p); (p) = NULL;}


#define	PRIVATE_MEMBER(Type,Name)	\
private:\
	Type	m_##Name;\
public:\
	inline	const Type& Get##Name() const\
	{\
		return this->m_##Name;\
	}\
	inline void Set##Name(const Type& in##Name)\
	{\
		this->m_##Name	= in##Name;\
	}\
private:


#define	PROTECTED_MEMBER(Type,Name)	\
protected:\
	Type	m_##Name;\
public:\
	inline	const Type& Get##Name() const\
	{\
		return this->m_##Name;\
	}\
	inline void Set##Name(const Type& in##Name)\
	{\
		this->m_##Name	= in##Name;\
	}\
protected: