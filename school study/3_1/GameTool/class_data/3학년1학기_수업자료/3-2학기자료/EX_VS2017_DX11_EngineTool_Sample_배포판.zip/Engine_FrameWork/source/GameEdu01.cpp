//#include "StdAfx.h"
//#include "GameEdu01.h"
//
//
//CGameEdu01::CGameEdu01(void)
//{
//}
//
//
//CGameEdu01::~CGameEdu01(void)
//{
//}
//
//void CGameEdu01::OnInit()
//{
//
//}
//
//void CGameEdu01::OnRender()
//{
//
//}
//
//void CGameEdu01::OnUpdate()
//{
//
//}
//
//void CGameEdu01::OnRelease()
//{
//
//}