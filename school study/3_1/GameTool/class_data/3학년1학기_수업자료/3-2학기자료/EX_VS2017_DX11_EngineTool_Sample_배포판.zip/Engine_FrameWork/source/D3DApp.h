#pragma once
#include <d3d9.h>
#include <d3dx9.h>
#include "macroheader.h"


class CD3DApp
{
protected:
	LPDIRECT3D9         m_pD3D; 
	LPDIRECT3DDEVICE9   m_pd3dDevice; 
	HWND m_hWnd;
	
	

protected:
	virtual void OnInit()=0;
	virtual void OnRender()=0;
	virtual void OnUpdate()=0;
	virtual void OnRelease()=0;

public:
	HRESULT InitD3D( HWND hWnd );
	void Render();
	void Update();
	void Cleanup();

public:
	CD3DApp(void);
	~CD3DApp(void);


protected:
	//D3DXCOLOR m_BGColor = D3DCOLOR_XRGB(0, 0, 255);
	PROTECTED_MEMBER(D3DXCOLOR, BGColor)

protected:
	int m_SendNResiveData = 0;

public:
	void C2MSend(int p_val);
	void M2CResive(int p_val);

public:
	WCHAR* SendC2M(WCHAR* p_char);
	WCHAR* ResiveM2C(WCHAR* p_char);
	
protected:
	WCHAR* m_TestChar = nullptr;

};

