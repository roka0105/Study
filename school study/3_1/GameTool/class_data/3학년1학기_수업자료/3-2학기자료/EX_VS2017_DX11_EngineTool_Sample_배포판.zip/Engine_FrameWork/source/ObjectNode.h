#pragma once
#include <d3d9.h>

class ObjectNode
{
public:
	ObjectNode();
	virtual ~ObjectNode();

public:
	virtual void Init();
	virtual void Update();
	virtual void Release();

	virtual void AddNode(ObjectNode* p_node);

protected:
	ObjectNode* m_ParentNode = NULL;


};

