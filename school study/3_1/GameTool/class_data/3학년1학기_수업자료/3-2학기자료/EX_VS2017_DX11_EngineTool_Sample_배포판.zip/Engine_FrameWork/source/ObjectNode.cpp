#include "ObjectNode.h"



ObjectNode::ObjectNode()
{
}


ObjectNode::~ObjectNode()
{
}

void ObjectNode::Init()
{
}

void ObjectNode::Update()
{
}

void ObjectNode::Release()
{
}

void ObjectNode::AddNode(ObjectNode * p_node)
{
}
