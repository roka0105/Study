#pragma once
#include <d3d9.h>
#include "ObjectNode.h"
#include "MeshBase.h"

struct CUSTOMVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
};

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)

class CTriangle:public MeshBase
{
private:
	LPDIRECT3DVERTEXBUFFER9 m_pVB;
	LPDIRECT3DDEVICE9  m_pd3dDevice;

public:
	virtual void OnInit( LPDIRECT3DDEVICE9  pd3dDevice );
	virtual void OnRender();
	virtual void OnRelease();

public:
	CTriangle(void);
	~CTriangle(void);
};

