﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class Test_Mono : MonoBehaviour
	{
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}