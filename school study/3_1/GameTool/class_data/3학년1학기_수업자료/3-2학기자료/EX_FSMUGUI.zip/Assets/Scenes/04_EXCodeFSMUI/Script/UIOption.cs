﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class UIOption : ElementBaseForm<E_UIState>
    {
        public override E_UIState EnumType => E_UIState.option;

        void Start()
		{
			
		}


	}
}