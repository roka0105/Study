﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class UIFieldMap : ElementBaseForm<E_UIState>
    {
        public override E_UIState EnumType => E_UIState.fieldmap;

        void Start()
		{
			
		}

	}
}