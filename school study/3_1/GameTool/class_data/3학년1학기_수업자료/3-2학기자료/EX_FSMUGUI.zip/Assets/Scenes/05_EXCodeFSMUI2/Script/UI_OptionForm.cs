﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class UI_OptionForm : ElementBaseForm<E_UIState>
    {
        public override E_UIState EnumType
        {
            get { return E_UIState.worldmap; }
        }
	
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}