﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DLL_Unity_ENCRYPT
{
    public class TestPluginDll2 : MonoBehaviour
    {
        void Start()
        {
            StartCoroutine(Log());
        }

        IEnumerator Log()
        {
            Debug.Log("Script Loaded");
            yield return new WaitForSeconds(1f);
            StartCoroutine(Log());
        }
    }
}
