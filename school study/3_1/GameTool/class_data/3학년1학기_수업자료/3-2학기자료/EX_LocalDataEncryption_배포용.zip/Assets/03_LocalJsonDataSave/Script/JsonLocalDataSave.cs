﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using System;
using Newtonsoft.Json.Bson;

namespace Du3Project
{

    // https://wergia.tistory.com/163
    // Newtonsoft.Json 기본적인 문제점들이 있음
    [System.Serializable]
    public class JsonTestDataCls
    {
        [JsonProperty("I")]
        public int i;
        public float f;
        public bool b;
        public string str;
        public int[] iArray;
        public List<int> iList = new List<int>();
        public Dictionary<string, float> fDictionary = new Dictionary<string, float>();

        [System.NonSerialized]
        public string nonestr;


        public JsonTestDataCls() { }

        public JsonTestDataCls(bool isSet)
        {

            if (isSet)
            {
                i = 10;
                f = 99.9f;
                b = true;
                str = "JSON Test String";
                iArray = new int[] { 1, 1, 3, 5, 8, 13, 21, 34, 55 };

                for (int idx = 0; idx < 5; idx++)
                {
                    iList.Add(2 * idx);
                }

                fDictionary.Add("PIE", Mathf.PI);
                fDictionary.Add("Epsilon", Mathf.Epsilon);
                fDictionary.Add("Sqrt(2)", Mathf.Sqrt(2));

                nonestr = "nonestr";
            }
        }
    }

    // https://wergia.tistory.com/163
    public class LocalSerializeData
    {
        public static void CreateJsonFile(string createPath, string fileName, string jsonData)
        {
            FileStream fileStream = new FileStream(string.Format("{0}/{1}.json", createPath, fileName), FileMode.Create);
            byte[] data = Encoding.UTF8.GetBytes(jsonData);
            fileStream.Write(data, 0, data.Length);
            fileStream.Close();
        }

        public static T LoadJsonFile<T>(string loadPath, string fileName)
        {
            FileStream fileStream = new FileStream(string.Format("{0}/{1}.json", loadPath, fileName), FileMode.Open);
            byte[] data = new byte[fileStream.Length];
            fileStream.Read(data, 0, data.Length);
            fileStream.Close();
            string jsonData = Encoding.UTF8.GetString(data);
            return JsonConvert.DeserializeObject<T>(jsonData);
        }
        public static string LoadJsonFile(string loadPath, string fileName)
        {
            FileStream fileStream = new FileStream(string.Format("{0}/{1}.json", loadPath, fileName), FileMode.Open);
            byte[] data = new byte[fileStream.Length];
            fileStream.Read(data, 0, data.Length);
            fileStream.Close();
            return Encoding.UTF8.GetString(data);
        }


        // 바이너리 저장 방법쪽 관련 자료
        // https://www.dotnetcurry.com/csharp/1279/serialize-json-data-binary
        // 문자 기반보다 데이터양이 늘어나는 형상이 생길수 있음
        public static void CreateJsonFileBinary(string createPath
            , string fileName
            , object p_data )
        {
            MemoryStream stream = new MemoryStream();
            BsonWriter bsonWriterObject = new BsonWriter(stream);
            JsonSerializer jsonSerializer = new JsonSerializer();
            jsonSerializer.Serialize(bsonWriterObject, p_data);

            FileStream fileStream = new FileStream(string.Format("{0}/{1}.json", createPath, fileName), FileMode.Create);
            byte[] data = stream.ToArray();
            fileStream.Write(data, 0, data.Length);
            fileStream.Close();
        }

        public static T LoadJsonFileBinary<T>(string loadPath, string fileName)
        {
            FileStream fileStream = new FileStream(string.Format("{0}/{1}.json", loadPath, fileName), FileMode.Open);
            BsonReader bsonreaderobject = new BsonReader(fileStream);
            JsonSerializer jsonSerializer = new JsonSerializer();
            T outobj = jsonSerializer.Deserialize<T>(bsonreaderobject);
            fileStream.Close();

            return outobj;
        }


    }




    // https://www.newtonsoft.com/json/help/html/SerializationAttributes.htm
    [JsonObject(MemberSerialization.OptIn)]
    public class JsonTestDataCls2
    {
        // "John Smith"
        [JsonProperty]
        public string Name { get; set; }

        // "2000-12-15T22:11:03"
        [JsonProperty]
        public DateTime BirthDate { get; set; }

        // new Date(976918263055)
        [JsonProperty]
        public DateTime LastModified { get; set; }

        // not serialized because mode is opt-in
        public string Department { get; set; }

        public override string ToString()
        {
            return string.Format("data : {0}, {1}, {2}, {3}"
                , Name
                , BirthDate
                , LastModified
                , Department );
        }
    }

    




    public class JsonLocalDataSave : MonoBehaviour
	{
        public JsonTestDataCls JsonData = new JsonTestDataCls();
        public JsonTestDataCls temploadJsonData0 = new JsonTestDataCls();
        public JsonTestDataCls temploadJsonData1 = new JsonTestDataCls();
        public JsonTestDataCls temploadJsonData2 = new JsonTestDataCls();

        // 데이터방식2
        public JsonTestDataCls2 JsonData2 = new JsonTestDataCls2();
        public JsonTestDataCls2 tempJsonData0 = new JsonTestDataCls2();
        public JsonTestDataCls2 tempJsonData1 = new JsonTestDataCls2();

        void TestJsonData2()
        {
            JsonData2.Name = "가나다";
            JsonData2.BirthDate = new DateTime(2010, 2, 10);
            JsonData2.LastModified = new DateTime(976918263055);
            JsonData2.Department = "abc";

            Debug.LogFormat("original data : {0}", JsonData2.ToString());

            // 직렬화
            string tempstr = JsonConvert.SerializeObject(JsonData2);
            Debug.LogFormat("Load data : {0}", tempstr);

            // 역직렬화
            tempJsonData0 = JsonConvert.DeserializeObject<JsonTestDataCls2>(tempstr);
            Debug.LogFormat("Load1 JSON data : {0}", tempJsonData0.ToString());



            // 암호화
            string tempaes = "Abcdefghi0kl4n7C";
            string descstr = Du3Project.Aes128PlayerPrefs.GetAESEncryptorAesValue(tempstr, tempaes);
            LocalSerializeData.CreateJsonFile(Application.dataPath, "descjson", descstr);

            // 복호화
            string loaddatastr = LocalSerializeData.LoadJsonFile(Application.dataPath, "descjson");
            string descdatastr = Du3Project.Aes128PlayerPrefs.GetAESDecryptorValue(loaddatastr, tempaes);
            tempJsonData1 = JsonConvert.DeserializeObject<JsonTestDataCls2>(descdatastr);

            // 복호화 혼합
            Debug.LogFormat("암호화 Load2 JSON data : {0}", tempJsonData1.ToString());

        }

        void TestJsonData()
        {
            // save
            string tempstr = JsonConvert.SerializeObject(JsonData);
            PlayerPrefs.SetString("TestJson", tempstr);

            // load
            string datastr = PlayerPrefs.GetString("TestJson");
            temploadJsonData0 = JsonConvert.DeserializeObject<JsonTestDataCls>(datastr);


            // string 기반
            // json save
            LocalSerializeData.CreateJsonFile(Application.dataPath, "testjson", tempstr);
            // json load
            temploadJsonData1 = LocalSerializeData.LoadJsonFile<JsonTestDataCls>(Application.dataPath, "testjson");


            // binary 기반
            // json save
            LocalSerializeData.CreateJsonFileBinary(Application.dataPath, "testjson2", JsonData);
            // json load
            temploadJsonData2 = LocalSerializeData.LoadJsonFileBinary<JsonTestDataCls>(Application.dataPath, "testjson2");
        }

		void Start()
		{
            TestJsonData();

            TestJsonData2();
        }

		void Update()
		{
			
		}
	}
}