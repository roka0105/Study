﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using UnityEngine;

namespace Du3Project
{
    // https://www.ikpil.com/1344
    public class DynamicAES256ScriptLoad : MonoBehaviour
    {
        public TextAsset assembly;

        private const string key = "090B235E9EB8F197F2DD927937222C570396D971222D9009A9189E2B6CC0A2C1";
        private const string iv = "5616574B106B7A77A10766351A74ACC9";

        public static byte[] HexStringToByteArray(string hex)
        {
            byte[] bytes = new byte[hex.Length / 2];
            for (int i = 0; i < hex.Length; i += 2)
            {
                bytes[i / 2] = System.Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }

        public static System.Reflection.Assembly LoadSecurityDLL(byte[] bytes)
        {
            using (RijndaelManaged aes256 = new RijndaelManaged())
            {
                aes256.KeySize = 256;
                aes256.BlockSize = 128;

                aes256.Key = HexStringToByteArray(key);
                aes256.IV = HexStringToByteArray(iv);

                aes256.Mode = CipherMode.CBC;
                aes256.Padding = PaddingMode.PKCS7;

                using (ICryptoTransform ct = aes256.CreateDecryptor())
                {
                    byte[] descrypted = ct.TransformFinalBlock(bytes, 0, bytes.Length);
                    return System.Reflection.Assembly.Load(descrypted);
                }
            }
        }

        [ContextMenu("[dll로딩 테스트]")]
        void Editor_Assemble()
        {
            // DLL_ClassSample.dll 파일은 dll로딩은 되지만 실제 안에 있는 클래스가 안타나남 
            //string filepath = string.Format("{0}/../DLL_ClassSample.dll", Application.dataPath);

            string filepath = string.Format("{0}/../DLL_Unity_ENCRYPT.dll", Application.dataPath);

            filepath = string.Format("{0}/DLL_Unity_ENCRYPT.dll", Path.GetDirectoryName(filepath));
            Assembly asem = System.Reflection.Assembly.LoadFile(filepath);

            Debug.LogFormat("확인용 : {0}", asem.GetTypes().Length.ToString());

            System.Type[] types = asem.GetExportedTypes();
            Debug.LogFormat("확인용 2 : {0}", types.Length.ToString());
            for (int i = 0; i < types.Length; i++)
            {
                Debug.Log(types[i].Name);
            }

            asem = null;
        }

        void Start()
        {
            Type myClass = null;

            byte[] bytes = Convert.FromBase64String(assembly.text);

            // 다이렉트 어셈블 로딩
            Assembly asem = LoadSecurityDLL(bytes);
            // 
            Type[] typescls = asem.GetTypes();
            for (int i = 0; i < typescls.Length; i++)
            {
                Debug.Log(typescls[i].Name);
            }

            myClass = asem.GetType("DLL_Unity_ENCRYPT.TestPluginDll2");

            GameObject newObject = new GameObject("new GameObject", myClass);

        }
    }
}