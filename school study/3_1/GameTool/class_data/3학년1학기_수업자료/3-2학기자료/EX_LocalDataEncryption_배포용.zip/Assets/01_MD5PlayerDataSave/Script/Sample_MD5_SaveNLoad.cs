﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using PlayerPrefs = Du3Project.MD5_ENCRYPT;

namespace Du3Project
{
    // md5 복호화등의 참고 싸이트
    // https://blog.serpongs.net/4
    // https://hashkiller.co.uk/Cracker/MD5

    // http://wiki.unity3d.com/index.php?title=MD5

    // https://teddy.tistory.com/15
    // https://gist.github.com/ftvs/5299600
    // PlayerPrefs  키값과 키값을 활용한 밸류값 저장방법
    public class Sample_MD5_SaveNLoad : MonoBehaviour
    {
        public string Key = "abc";
        public string Value = "efg";

        void LoadDatas()
        {
            string tempval = MD5_ENCRYPT.GetMD5String(Key);
            Debug.LogFormat("로드 데이터 : {0}", tempval);
        }

        void SaveDatas()
        {
            MD5_ENCRYPT.SetMD5String(Key, Value);
        }


        void Awake()
        {
            SaveDatas();
            LoadDatas();
        }

        void Start()
        {

        }

    }
}