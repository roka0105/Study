﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Security.Cryptography;
using System;

namespace Du3Project
{
    // https://theemeraldtablet.tistory.com/entry/%EC%95%94%ED%98%B8%ED%99%94-%ED%8C%81-MD5
    public class MD5_ENCRYPT
    {
        const CipherMode DEFAULT_CIPHERMODE = CipherMode.ECB;
        const string DEFAULT_ENCRYPT_KEY = "abc";
        public static void SetMD5String(string p_key, string p_val, string p_encryptkey = DEFAULT_ENCRYPT_KEY)
        {
            // key값 암호화
            MD5 md5hash = MD5.Create();
            byte[] hashdata = md5hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(p_key));
            string hashkey = System.Text.Encoding.UTF8.GetString(hashdata);
            byte[] secret = md5hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(p_encryptkey));

            // 암호화 p_val
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(p_val);


            // p_val 을 한번더 꼬아서 적용 Eecrypt '_value' with 3DES.  
            TripleDES des = new TripleDESCryptoServiceProvider();
            des.Key = secret;
            des.Mode = DEFAULT_CIPHERMODE;
            ICryptoTransform xform = des.CreateEncryptor();
            byte[] encrypted = xform.TransformFinalBlock(bytes, 0, bytes.Length);

            string encryptedstring = Convert.ToBase64String(encrypted);

            PlayerPrefs.SetString(hashkey, encryptedstring);
            Debug.LogFormat("SetString HashKey : {0}, {1} ", hashkey, encryptedstring);
        }

        public static string GetMD5String(string p_key, string p_encryptkey = DEFAULT_ENCRYPT_KEY)
        {
            MD5 md5hash = MD5.Create();
            byte[] hashdata = md5hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(p_key));
            string hashkey = System.Text.Encoding.UTF8.GetString(hashdata);

            string value = PlayerPrefs.GetString(hashkey, "");
            if (value == "")
            {
                Debug.LogFormat("키값이 없습니다. : {0}", p_key);
                return "";
            }

            byte[] bytes = Convert.FromBase64String(value);
            byte[] secret = md5hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(p_encryptkey));

            // decrypt "value" 3DES 로 복호화
            TripleDES des = new TripleDESCryptoServiceProvider();
            des.Key = secret;
            des.Mode = DEFAULT_CIPHERMODE;
            ICryptoTransform xform = des.CreateDecryptor();
            byte[] decrypted = xform.TransformFinalBlock(bytes, 0, bytes.Length);

            string decrpytedvalue = System.Text.Encoding.UTF8.GetString(decrypted);

            Debug.LogFormat("Get String Val : {0}, {1} ", hashkey, value, decrpytedvalue);

            return decrpytedvalue;
        }

        //public static void DeleteAll();

        //public static void DeleteKey(string key);
        //public static float GetFloat(string key, float defaultValue);

        //public static float GetFloat(string key);

        //public static int GetInt(string key, int defaultValue);

        //public static int GetInt(string key);

        //public static string GetString(string key, string defaultValue);

        //public static string GetString(string key);

        //public static bool HasKey(string key);

        //public static void Save();

        //public static void SetFloat(string key, float value);

        //public static void SetInt(string key, int value);

        //public static void SetString(string key, string value);
    }
}