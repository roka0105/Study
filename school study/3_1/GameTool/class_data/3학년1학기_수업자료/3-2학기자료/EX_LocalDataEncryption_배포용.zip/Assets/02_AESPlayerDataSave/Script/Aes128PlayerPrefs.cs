﻿#define USE_AES
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Security.Cryptography;
using System.IO;

namespace Du3Project
{
    public class Aes128PlayerPrefs
    {
        public static string NickNameAESKey = "1q2w3e4r";

        // 문자열의 문자는 16자로만 채우도록하기
        public static string[] AESKeys = new string[]
        {
            "2eeee02d3dc3ef6c"
            , "Abcdefghi0kl4n7R"
            , "Abcde4ghiPklmAR4"
            , "5bc2eBEhijPEmnAp"
            , "abcdef5hiPklmnBZ"
            , "a0c2eB3TUj9lmnop"
            , "aLcdefghUjPERA2R"
        };


        public static bool ISUSEAes()
        {
#if USE_AES
            return true;
#else
            return false;
#endif
        }


        static RijndaelManaged m_Aes = new RijndaelManaged();
        protected static RijndaelManaged GetAESKeyInput(string p_aesKeyval)
        {
            m_Aes.BlockSize = 128;
            m_Aes.KeySize = 128;
            m_Aes.Padding = PaddingMode.PKCS7;
            m_Aes.Mode = CipherMode.ECB;
            m_Aes.Key = System.Text.Encoding.UTF8.GetBytes(p_aesKeyval);

            return m_Aes;
        }
        protected static RijndaelManaged GetAES(string p_inval)
        {
            m_Aes.BlockSize = 128;
            m_Aes.KeySize = 128;
            m_Aes.Padding = PaddingMode.Zeros;
            m_Aes.Mode = CipherMode.ECB;
            m_Aes.Key = System.Text.Encoding.UTF8.GetBytes(GetAESKeyVal(p_inval));

            return m_Aes;
        }
        protected static RijndaelManaged GetAES(int p_aeskeyval)
        {
            m_Aes.BlockSize = 128;
            m_Aes.KeySize = 128;
            // PaddingMode.PKCS7 방식은 위에 AESKeys 8바이트가 안되었을때 빈자리를 채우기위한 방식임
            m_Aes.Padding = PaddingMode.Zeros;
            m_Aes.Mode = CipherMode.ECB;
            m_Aes.Key = System.Text.Encoding.UTF8.GetBytes(GetAESKeyVal(p_aeskeyval));

            return m_Aes;
        }


        protected static string GetAESKeyVal(string p_inval)
        {
            int index = p_inval.Length % AESKeys.Length;
            return AESKeys[index]; // 이건 기존것
            //int index = p_inval.Length % AESKeyData.AESKeys.Length;
            //return AESKeyData.AESKeys[index];
        }
        protected static string GetAESKeyVal(int p_index)
        {
            int index = p_index % AESKeys.Length;
            return AESKeys[index]; // 이건 기존것
            //int index = p_index % AESKeyData.AESKeys.Length;
            //return AESKeyData.AESKeys[index];
        }



        /// <summary>
        /// 직접사용위한 복호화
        /// </summary>
        /// <param name="p_val"></param>
        /// <param name="p_aeskeystr"></param>
        /// <returns></returns>
        public static string GetAESDecryptorValue(string p_val, string p_aeskeystr)
        {
            RijndaelManaged aesval = GetAESKeyInput(p_aeskeystr);
            ICryptoTransform decryptor = aesval.CreateDecryptor();

            byte[] encrypted = System.Convert.FromBase64String(p_val);
            byte[] planeText = new byte[encrypted.Length];

            MemoryStream memoryStream = new MemoryStream(encrypted);
            CryptoStream cryptStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            cryptStream.Read(planeText, 0, planeText.Length);

            return (System.Text.Encoding.UTF8.GetString(planeText));
        }
        /// <summary>
        /// 직접 사용위한 암호화
        /// </summary>
        /// <param name="p_val"></param>
        /// <param name="p_aeskeystr"></param>
        /// <returns></returns>
        public static string GetAESEncryptorAesValue(string p_val, string p_aeskeystr)
        {
            RijndaelManaged aesval = GetAESKeyInput(p_aeskeystr);
            ICryptoTransform encrypt = aesval.CreateEncryptor();

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptStream = new CryptoStream(memoryStream, encrypt, CryptoStreamMode.Write);
            byte[] text_bytes = System.Text.Encoding.UTF8.GetBytes(p_val);
            cryptStream.Write(text_bytes, 0, text_bytes.Length);
            cryptStream.FlushFinalBlock();

            byte[] encrypted = memoryStream.ToArray();

            return System.Convert.ToBase64String(encrypted);
        }


        /// <summary>
        /// 암호화 값
        /// </summary>
        /// <param name="p_inval"></param>
        /// <param name="p_aeskeystr"></param>
        /// <returns></returns>
        protected static string GetAESEncryptorAes(string p_inval, string p_aeskeystr)
        {
            RijndaelManaged aesval = GetAESKeyInput(p_aeskeystr);
            ICryptoTransform encrypt = aesval.CreateEncryptor();

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptStream = new CryptoStream(memoryStream, encrypt, CryptoStreamMode.Write);
            byte[] text_bytes = System.Text.Encoding.UTF8.GetBytes(p_inval);
            cryptStream.Write(text_bytes, 0, text_bytes.Length);
            cryptStream.FlushFinalBlock();

            byte[] encrypted = memoryStream.ToArray();

            return System.Convert.ToBase64String(encrypted);
        }

        /// <summary>
        /// 복호화 key값
        /// </summary>
        /// <param name="p_inval"></param>
        /// <param name="p_seedval"></param>
        /// <returns></returns>
        protected static string GetAESEncryptor(string p_inval, int p_seedval)
        {
            RijndaelManaged aesval = GetAES(p_seedval);
            ICryptoTransform encrypt = aesval.CreateEncryptor();

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptStream = new CryptoStream(memoryStream, encrypt, CryptoStreamMode.Write);
            byte[] text_bytes = System.Text.Encoding.UTF8.GetBytes(p_inval);
            cryptStream.Write(text_bytes, 0, text_bytes.Length);
            cryptStream.FlushFinalBlock();

            byte[] encrypted = memoryStream.ToArray();

            return System.Convert.ToBase64String(encrypted);
        }

        protected static string GetAESDecryptor(string p_inval, int p_seedval)
        {
            RijndaelManaged aesval = GetAES(p_seedval);
            ICryptoTransform decryptor = aesval.CreateDecryptor();

            byte[] encrypted = System.Convert.FromBase64String(p_inval);
            byte[] planeText = new byte[encrypted.Length];

            MemoryStream memoryStream = new MemoryStream(encrypted);
            CryptoStream cryptStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            cryptStream.Read(planeText, 0, planeText.Length);

            return (System.Text.Encoding.UTF8.GetString(planeText));
        }









        #region Set 플레이어 데이터 저장

        public static void SavePlayerPrefsAesKey(string p_key, string p_val, string p_aeskey)
        {
            string keyval;
            string val;

            if (ISUSEAes())
            {
                keyval = GetAESEncryptorAes(p_key, p_aeskey);
                val = GetAESEncryptorAes(p_val, p_aeskey);
            }
            else
            {
                keyval = p_key;
                val = p_val;
            }

            PlayerPrefs.SetString(keyval, val);
        }

        public static void SavePlayerPrefs(string p_key, string p_val)
        {
            string keyval;
            string val;
            if (ISUSEAes())
            {
                keyval = GetAESEncryptor(p_key, p_key.Length);
                val = GetAESEncryptor(p_val, p_key.Length);
            }
            else
            {
                keyval = p_key;
                val = p_val;
            }
            PlayerPrefs.SetString(keyval, val);
        }
        public static void SetBool(string p_key, bool p_val)
        {
            int val = p_val ? 1 : 0;
            SavePlayerPrefs(p_key, val.ToString());
        }
        public static void SetInt(string p_key, int p_val)
        {
            SavePlayerPrefs(p_key, p_val.ToString());
        }
        public static void SetFloat(string p_key, float p_val)
        {
            SavePlayerPrefs(p_key, p_val.ToString());
        }
        public static void SetString(string p_key, string p_val)
        {
            SavePlayerPrefs(p_key, p_val);
        }
        public static void SetStringAesKey(string p_key, string p_val, string p_aeskey)
        {
            SavePlayerPrefsAesKey(p_key, p_val, p_aeskey);
        }
        #endregion



        #region GET 실제 사용하기위한 기본 소스들 

        // 사용하기 위한곳
        static string m_key = "";
        static string m_Value = "";

        protected static bool LoadPlayerPrefs(string p_key, ref string p_defaultoutval)
        {
            if (ISUSEAes())
            {
                m_key = GetAESEncryptor(p_key, p_key.Length);
            }
            else
            {
                m_key = p_key;

            }


            if (!PlayerPrefs.HasKey(m_key))
                return false;


            p_defaultoutval = PlayerPrefs.GetString(m_key);

            if (ISUSEAes())
            {
                p_defaultoutval = GetAESDecryptor(p_defaultoutval, p_key.Length);
            }
            else
            {

            }

            return true;
        }



        public static bool HasKey(string p_key)
        {
            if (ISUSEAes())
            {
                m_key = GetAESEncryptor(p_key, p_key.Length);
            }
            else
            {
                m_key = p_key;
            }

            return PlayerPrefs.HasKey(m_key);
        }


        public static bool GetBool(string p_key, bool p_defaultoutval = false)
        {
            string outval = "";
            if (LoadPlayerPrefs(p_key, ref outval))
            {
                try
                {
                    return outval == "1" ? true : false;
                }
                catch (System.Exception ex)
                {
                    return p_defaultoutval;
                }

            }
            return p_defaultoutval;
        }

        public static int GetInt(string p_key, int p_defaultoutval = 0)
        {
            string outval = "";
            if (LoadPlayerPrefs(p_key, ref outval))
            {
                try
                {
                    return int.Parse(outval);
                }
                catch (System.Exception ex)
                {
                    return p_defaultoutval;
                }

            }
            return p_defaultoutval;
        }
        public static float GetFloat(string p_key, float p_defaultoutval = 0f)
        {
            string outval = "";
            if (LoadPlayerPrefs(p_key, ref outval))
            {
                try
                {
                    return float.Parse(outval);
                }
                catch (System.Exception ex)
                {
                    return p_defaultoutval;
                }

            }
            return p_defaultoutval;
        }


        public static string GetString(string p_key, string p_defaultoutval = "")
        {
            if (ISUSEAes())
            {
                m_key = GetAESEncryptor(p_key, p_key.Length);
            }
            else
            {
                m_key = p_key;

            }


            if (!PlayerPrefs.HasKey(m_key))
                return p_defaultoutval;


            m_Value = PlayerPrefs.GetString(m_key);

            if (ISUSEAes())
            {
                m_Value = GetAESDecryptor(m_Value, p_key.Length);
            }
            else
            {

            }
            return m_Value;
        }

        public static string LoadPlayerPrefs(string p_key, string p_defaultoutval = "")
        {
            if (ISUSEAes())
            {
                m_key = GetAESEncryptor(p_key, p_key.Length);
            }
            else
            {
                m_key = p_key;

            }


            if (!PlayerPrefs.HasKey(m_key))
                return p_defaultoutval;

            m_Value = PlayerPrefs.GetString(m_key);

            if (ISUSEAes())
            {
                m_Value = GetAESDecryptor(m_Value, p_key.Length);
            }
            else
            {

            }

            return m_Value;
        }

        #endregion

    }
}