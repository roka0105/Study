﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//namespace Du3Project
//{
//    // 소스 등록 한뒤에  Assembly Definition 이용해서 DLL  Export한뒤에
//    // 현재 소스를 주석 처리하는 방법임 
//    // export된 dll은 plugins 폴더에 넣어서 사용하면 됨
//    // export된 dll은 암호화 txt방식으로 저장한뒤 dll 로더 이용해서 복호화 해서 dll사용하는
//    // 방법등을 사용하면 됨
//	//public class AESKeyData
//	//{
// //       public static string NickNameAESKey = "1q2w3e4r";
// //       public static string[] AESKeys = new string[]
// //       {
// //           "2eeee02d3dc3ef6c"
// //           , "Abcdefghi0kl4n7R"
// //           , "Abcde4ghiPklmAR4"
// //           , "5bc2eBEhijPEmnAp"
// //           , "abcdef5hiPklmnBZ"
// //           , "a0c2eB3TUj9lmnop"
// //           , "aLcdefghUjPERA2R"
// //       };




// //   }


//}

