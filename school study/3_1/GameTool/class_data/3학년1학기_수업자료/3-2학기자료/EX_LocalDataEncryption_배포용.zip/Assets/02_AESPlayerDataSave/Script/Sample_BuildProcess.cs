﻿using UnityEngine;
using UnityEditor;
using UnityEditor.Callbacks;
using System.Diagnostics;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace Du3Project
{

    //public class Test_PreBuildProcess : IPreprocessBuildWithReport
    //{
    //    public int callbackOrder => 0;

    //    public void OnPreprocessBuild(BuildReport report)
    //    {
    //        throw new System.NotImplementedException();
    //    }

    //    [ PostProcessBuildAttribute(1)]
    //    public void TestCallBackPre()
    //    {

    //    }
    //}



    public class Sample_BuildProcess
    {
        // https://docs.unity3d.com/ScriptReference/Callbacks.PostProcessBuildAttribute.html
        [PostProcessBuildAttribute(1)]
        public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject)
        {
            UnityEngine.Debug.Log(pathToBuiltProject);

        }








        // https://docs.unity3d.com/Manual/BuildPlayerPipeline.html
        [MenuItem("MyTools/Windows Build With Postprocess")]
        public static void BuildGame()
        {
            //PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.Standalone, "AES_USE");




            // Get filename.
            string path = EditorUtility.SaveFolderPanel("Choose Location of Built Game", "", "");
            string[] levels = new string[] { "Assets/Scene1.unity", "Assets/Scene2.unity" };

            // Build player.
            BuildPipeline.BuildPlayer(levels, path + "/BuiltGame.exe", BuildTarget.StandaloneWindows, BuildOptions.None);

            // Copy a file from the project folder to the build folder, alongside the built game.
            FileUtil.CopyFileOrDirectory("Assets/Templates/Readme.txt", path + "Readme.txt");

            // Run the game (Process class from System.Diagnostics).
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = path + "/BuiltGame.exe";
            proc.Start();
        }

    }




    


}