﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PlayerPrefs = Du3Project.Aes128PlayerPrefs;
using UnityEngine.UI;

namespace Du3Project
{

    [System.Serializable]
    public class TestData
    {
        public int Val = 10;
        public float TempFloat = 20f;
        public string TempStr = "ABC";

        public Texture2D TempImage;
    }


    public class Sample_AES128SaveNLoad : MonoBehaviour
    {
        public string AESKeyData = "AESABC";
        public string AESValueData = "AES1234";

        public string JsonKey = "DataJson";
        public TestData TestDataCls = new TestData();

        public TestData TestDataCls2 = new TestData();

        public TestData TestDataCls3 = new TestData();
        void LoadDatas()
        {
            string tempstr = Aes128PlayerPrefs.GetString(AESKeyData);
            Debug.LogFormat("AES128 데이터 : {0}", tempstr);

            string tempstr2 = PlayerPrefs.GetString(AESKeyData + "A");
            Debug.LogFormat("AES128 데이터 : {0}", tempstr2);

            // json data load
            string jsonstr = PlayerPrefs.GetString(JsonKey);
            TestDataCls2 = JsonUtility.FromJson<TestData>(jsonstr);

            // 직접 데이터 로드방법해서 텍스처 적용
            string imgstr = UnityEngine.PlayerPrefs.GetString("Image");
            byte[] bytes = System.Convert.FromBase64String(imgstr);
            Texture2D tex = new Texture2D(2, 2);
            tex.LoadImage(bytes);
            TestDataCls3.TempImage = tex;
        }
        void SaveDatas()
        {
            // dll 링크연결하기
            string tempstr = Du3Project.AESKeyData.AESKeys[0];

            Aes128PlayerPrefs.SetString(AESKeyData, AESValueData);
            PlayerPrefs.SetString(AESKeyData + "A", AESValueData + "A");

            // json string 저장
            string jsondata = JsonUtility.ToJson(TestDataCls);
            PlayerPrefs.SetString(JsonKey, jsondata);


            // 이미지 직접 byte로 저장하기
            // https://docs.unity3d.com/ScriptReference/ImageConversion.EncodeToPNG.html
            // format type이 중요함
            // 용량때문에 jpg방식으로 처리함
            byte[] bytes = TestDataCls.TempImage.EncodeToJPG();
            //byte[] bytes = TestDataCls.TempImage.EncodeToPNG();
            string imgstr = System.Convert.ToBase64String(bytes);
            UnityEngine.PlayerPrefs.SetString("Image", imgstr);
        }

        void Start()
        {
            SaveDatas();
            LoadDatas();

        }

        void Update()
        {

        }
    }
}