﻿using UnityEditor;

namespace Du3Project
{
    [CustomEditor(typeof(NestedScrollRect))]
    [CanEditMultipleObjects]
    public class NestedScrollRectEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
        }
    }
}

