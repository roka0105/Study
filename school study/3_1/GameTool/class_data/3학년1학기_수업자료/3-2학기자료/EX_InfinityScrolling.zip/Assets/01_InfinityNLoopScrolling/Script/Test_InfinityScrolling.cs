﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
    // https://github.com/tsubaki/Unity_UI_Samples/tree/master/Assets/InfiniteScroll


    public class Test_InfinityScrolling : MonoBehaviour
	{
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}