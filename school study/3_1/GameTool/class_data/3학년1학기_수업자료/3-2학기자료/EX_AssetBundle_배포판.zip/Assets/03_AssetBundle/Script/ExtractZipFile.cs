﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using UnityEngine;

namespace Du3Project
{
    public class ExtractZipFile : MonoBehaviour
    {

        // https://gist.github.com/r2d2rigo/2bd3a1cafcee8995374f
        // https://github.com/icsharpcode/SharpZipLib/releases <- 다운 받아서 .nupkg -> .zip 확장자를 바꾼뒤 dll을 사용하면 된다
        // This sample function uses SharpZipLib (http://icsharpcode.github.io/SharpZipLib/) to extract 
        public static IEnumerator ExtractZipFileL(byte[] zipFileData
            , string targetDirectory
            , int bufferSize = 256 * 1024
            , Action p_callfn = null )
        {
            Directory.CreateDirectory(targetDirectory);

            using (MemoryStream fileStream = new MemoryStream())
            {
                fileStream.Write(zipFileData, 0, zipFileData.Length);
                fileStream.Flush();
                fileStream.Seek(0, SeekOrigin.Begin);

                ZipFile zipFile = new ZipFile(fileStream);

                foreach (ZipEntry entry in zipFile)
                {
                    // 폴더 생성 추가 ------
                    string directoryName = Path.GetDirectoryName(entry.Name);
                    string fileName = Path.GetFileName(entry.Name);
                    if( string.IsNullOrEmpty( fileName ) )
                    {
                        // 폴더 생성
                        Directory.CreateDirectory(targetDirectory + "/" + directoryName);
                        continue;
                    }
                    // 폴더 생성 추가 ------


                    string targetFile = Path.Combine(targetDirectory, entry.Name);
                    using (FileStream outputFile = File.Create(targetFile))
                    {
                        if (entry.Size > 0)
                        {
                            Stream zippedStream = zipFile.GetInputStream(entry);
                            byte[] dataBuffer = new byte[bufferSize];

                            int readBytes;
                            while ((readBytes = zippedStream.Read(dataBuffer, 0, bufferSize)) > 0)
                            {
                                outputFile.Write(dataBuffer, 0, readBytes);
                                outputFile.Flush();
                                yield return null;
                            }
                        }
                    }
                }
            }


            if(p_callfn != null)
            {
                p_callfn.Invoke();
            }
            
        }




    }
}