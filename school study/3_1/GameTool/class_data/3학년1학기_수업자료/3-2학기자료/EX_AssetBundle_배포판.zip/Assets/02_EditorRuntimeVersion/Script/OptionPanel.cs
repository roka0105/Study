﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Du3Project
{
	public class OptionPanel : MonoBehaviour
	{
        public Text VersionLabel = null;

        private void Awake()
        {
            VersionLabel.text = VersionSyncUpdate_Com.GetI.CurrentVersion;

        }

        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}