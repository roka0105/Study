﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;


namespace Du3Project
{
    [System.Serializable]
    public class VersionData
    {
        public int Major = 0;
        public int Miner = 0;
        public int Build = 0;
        public string VersionVal = "";
        public string GetVersionString()
        {
            VersionVal = string.Format("{0}.{1}.{2}", Major, Miner, Build);
            return VersionVal;
        }
    }

	public class VersionCheker : MonoBehaviour
	{
        public string CheckURL = "http://magotoolivesource.github.io/GitHomePage/TestVersion2.json";
        [Header("[값확인용]")]
        public VersionData LocalVersionData = new VersionData();
        public VersionData LocalLagecyVersionData = new VersionData();

        
        IEnumerator GetWWWVersionData()
        {
            string url = CheckURL;
            WWW www = new WWW(url);

            while (!www.isDone)
            {
                yield return null;
            }

            // html 정보가 바뀌는것이 좀 느린편인듯함 대략 10분 후에나 www가 잘 받아옴 테스트 해봐야지됨
            Debug.LogFormat("기존 WWW 페이지정보 : {0}", www.text);
            VersionData versionData = JsonUtility.FromJson<VersionData>(www.text);
            JsonUtility.FromJsonOverwrite(www.text, LocalLagecyVersionData);
        }

        IEnumerator GetWWWRequestVersionData()
        {
            string url = CheckURL; 
            UnityWebRequest www = new UnityWebRequest(url, UnityWebRequest.kHttpVerbGET);
            www.SetRequestHeader("Content-Type", "application/json");
            www.SetRequestHeader("Accept", "application/json");
            //www.method = "POST";


            // 다운로드 받을때 꼭 DownloadHandlerBuffer 를 등록 해줘야지 다운로드가 가능함
            // www 에서의 편한 방식에서 바뀜
            // 출처: https://smilejsu.tistory.com/1372 [{ 일등하이 :Unity3D }]
            DownloadHandlerBuffer dH = new DownloadHandlerBuffer();
            www.downloadHandler = dH;


            yield return www.SendWebRequest();

            if (www.isNetworkError || www.isHttpError)
            {
                Debug.LogErrorFormat("정보없거나 URL이 이상합니다.");
                yield break;
            }

            //Dictionary<string, string> getresponseheaders = www.GetResponseHeaders();

            Debug.LogFormat("페이지정보 : {0}", www.downloadHandler.text);
            VersionData versionData = JsonUtility.FromJson<VersionData>(www.downloadHandler.text);
            JsonUtility.FromJsonOverwrite(www.downloadHandler.text, LocalVersionData);
        }



        [ContextMenu("[테스트 URL연결하기]")]
        void CheckHomePageVersion()
        {
            StartCoroutine(GetWWWRequestVersionData() );
        }

        [ContextMenu("[테스트 기존 WWW 연결하기]")]
        void Test_LagecyCheckHomePageVersion()
        {
            StartCoroutine(GetWWWVersionData());
        }


        private void Awake()
        {
            //string tempstr = JsonUtility.ToJson(LocalVersionData);
            //Debug.LogFormat("versiondata : {0}", tempstr);

            CheckHomePageVersion();
            Test_LagecyCheckHomePageVersion();
        }
        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}