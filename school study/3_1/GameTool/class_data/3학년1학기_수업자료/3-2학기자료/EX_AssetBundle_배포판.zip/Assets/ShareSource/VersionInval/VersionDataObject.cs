﻿using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;
using System.Collections.Generic;
#endif



[System.Serializable]
public class VersionDataObject : ScriptableObject
{
    const string SettingsAssetName = "VersionDataObjectAsset";
    const string SettingsPath = "VersionInval/Resources";
    const string SettingsAssetExtension = ".asset";

    public string m_FileFullPath = "";


    public string BundleVersion = "";
    public string BundleIdentifier = "";
    public int AndroidBundleVersionCode = 0;


    public static string GetAssetDataPath()
    {
        return string.Format("Assets/{0}/{1}{2}"
                    , VersionDataObject.SettingsPath
                    , VersionDataObject.SettingsAssetName
                    , VersionDataObject.SettingsAssetExtension);
    }

    public static VersionDataObject CreateVersionAssetData()
    {
#if UNITY_EDITOR
        string path = GetAssetDataPath();
        VersionDataObject newobj = CreateInstance<VersionDataObject>();
        string properPath = System.IO.Path.Combine(Application.dataPath, path);
        if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(path)))
        {
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
        }

        AssetDatabase.CreateAsset(newobj, path);
        AssetDatabase.SaveAssets();

        return newobj;
#endif

        return null;
    }



    private static VersionDataObject instance = null;
    public static VersionDataObject GetI
    {
        get
        {
            if (instance == null)
            {
//                 string path = string.Format("{0}/{1}"
//                     , VersionDataObject.SettingsPath
//                     , VersionDataObject.SettingsAssetName);

                instance = Resources.Load(VersionDataObject.SettingsAssetName) as VersionDataObject;

                if (instance == null)
                {

                    // If not found, autocreate the asset object.
                    instance = CreateInstance<VersionDataObject>();
#if UNITY_EDITOR
                    string fullPath = GetAssetDataPath();
                    AssetDatabase.CreateAsset(instance, fullPath);
#endif

                }
            }
            return instance;
        }
    }

    public string GetVersionFullString()
    {
        return string.Format("{0}.{1}", BundleVersion, AndroidBundleVersionCode);
    }


}
