﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Du3Project
{
	public class Editor_BundleBuilder
	{

        [MenuItem("Bundles/내보내기 번들")]
        static void BuildAllAssetBundles()
        {
            //string[] assetbundlepatharr = new string[]
            //{
            //    "Assets/03_AssetBundle/Bundle_Ver01"
            //    , "Assets/03_AssetBundle/Bundle01"
            //    , "Assets/03_AssetBundle/Prefabs/Character01"
            //};

            //int totalcount = assetbundlepatharr.Length;
            //for (int i=0; i<assetbundlepatharr.Length; ++i)
            //{
            //    //예를 들어 Assets 하위 폴더에 저장하려면 "Assets/AssetBundles"로 입력해야합니다. 
            //    BuildPipeline.BuildAssetBundles( assetbundlepatharr[i]
            //        , BuildAssetBundleOptions.None
            //        , BuildTarget.StandaloneWindows);

            //    EditorUtility.DisplayProgressBar("진행사항", "진행중...", (float)(i / totalcount));
            //}

            //EditorUtility.ClearProgressBar();




            string savepath = Path.Combine(Application.streamingAssetsPath, "BuldleVer01");
            if (!Directory.Exists(savepath))
            {
                Directory.CreateDirectory(savepath);
            }

            BuildPipeline.BuildAssetBundles( savepath
                    , BuildAssetBundleOptions.None
                    , BuildTarget.StandaloneWindows);

            // 이후에 www에 파일을 강제로 올릴수 있도록 처리하면 된다.
            // github주소에 적용하기 위해서는 git을 이용한 커밋방식으로처리하면 된다.


        }
	}
}