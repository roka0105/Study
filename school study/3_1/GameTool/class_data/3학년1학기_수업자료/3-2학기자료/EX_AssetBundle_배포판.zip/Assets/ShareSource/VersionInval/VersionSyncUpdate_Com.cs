﻿#define VERSIONREMOVEPROTECTED

using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;
#endif



/// <summary>
/// 2가지 방식중 하나 에디터 상에서 항시 업데이트 하면서 값을 보고있는 방식
/// enable 끄면 안됨 값이 업데이트 되지않음
/// </summary>
#if VERSIONREMOVEPROTECTED
[ExecuteInEditMode]
#endif
public class VersionSyncUpdate_Com : Singleton_Mono<VersionSyncUpdate_Com>
{
    [SerializeField]
    public string m_CurrentVersion = "";
    public string BundleVersion = "";
    public int AndroidBundleVersionCode = 0;

    public string BundleIdenfiter = "";

    public string CurrentVersion
    {
        get{ return m_CurrentVersion; }
    }

#if VERSIONREMOVEPROTECTED
    void OnEnable()
    {
        // 인스팩터 디버그모드 확인하기
        this.hideFlags = HideFlags.NotEditable;
    }

    void OnDisable()
    {
        // 강제로 안바꾸도록 한것임
        this.enabled = true;
    }


    // 비헤이비어에서 적용이 되고있지않음
    //EditorApplication.modifierKeysChanged
    void Editor_SetModifier(bool p_flag)
    {
#if UNITY_EDITOR
        if (p_flag)
            EditorApplication.modifierKeysChanged += modifierKeysChanged;
        else
            EditorApplication.modifierKeysChanged -= modifierKeysChanged;
#endif
    }

    void modifierKeysChanged()
    {
#if UNITY_EDITOR
        if (BundleVersion != PlayerSettings.bundleVersion)
        {
            BundleVersion = PlayerSettings.bundleVersion;
            Debug.LogFormat("55 VersionInval_Com Change Version : {0} ", GUI.changed);
        }

        if (AndroidBundleVersionCode != PlayerSettings.Android.bundleVersionCode)
        {
            AndroidBundleVersionCode = PlayerSettings.Android.bundleVersionCode;
            Debug.LogFormat("66 VersionInval_Com Android Change Version : {0} ", GUI.changed);
        }

        if (!BundleIdenfiter.Equals(PlayerSettings.applicationIdentifier))
        {
            BundleIdenfiter = PlayerSettings.applicationIdentifier;
        }

#endif

    }

    private void UpdateCurrentVersionData()
    {
        m_CurrentVersion = string.Format("{0}.{1}", BundleVersion, AndroidBundleVersionCode);
    }

    // 에디터상 업데이트에서 직접 호출 하는 것이 가장 낳을듯함
    // 느려 질듯한 분위기도 있지만 이것이 가장 낳음
    void Update()
    {
#if UNITY_EDITOR
        if (BundleVersion != PlayerSettings.bundleVersion)
        {
            BundleVersion = PlayerSettings.bundleVersion;
            Debug.LogFormat("55 VersionInval_Com Change Version : {0} ", GUI.changed);

            UpdateCurrentVersionData();
        }

        if (AndroidBundleVersionCode != PlayerSettings.Android.bundleVersionCode)
        {
            AndroidBundleVersionCode = PlayerSettings.Android.bundleVersionCode;
            Debug.LogFormat("66 VersionInval_Com Android Change Version : {0} ", GUI.changed);

            UpdateCurrentVersionData();
        }

        if (!BundleIdenfiter.Equals(PlayerSettings.applicationIdentifier))
        {
            BundleIdenfiter = PlayerSettings.applicationIdentifier;
        }
#endif

    }


#endif
}
