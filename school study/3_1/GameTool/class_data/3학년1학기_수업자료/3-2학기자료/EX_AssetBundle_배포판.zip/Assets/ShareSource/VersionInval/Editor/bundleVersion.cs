﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System;

[InitializeOnLoad]
public class bundleVersion
{
    static bundleVersion()
    {
        CreateVersionDataObject();

        //EditorApplication.update += Update;
        //EditorApplication.projectWindowChanged += projectWindowChanged;
        //EditorApplication.delayCall += delayCall;
        EditorApplication.modifierKeysChanged += modifierKeysChanged;
    }

    static VersionDataObject m_VersionDataObject = null;
    static void CreateVersionDataObject()
    {
        if (m_VersionDataObject != null)
            return;


        string assetlocalpath = VersionDataObject.GetAssetDataPath();
        if (!System.IO.File.Exists(assetlocalpath))
        {
            VersionDataObject.CreateVersionAssetData();
        }

        m_VersionDataObject = AssetDatabase.LoadAssetAtPath<VersionDataObject>(assetlocalpath);
    }

    

    static void modifierKeysChanged()
    {
        CreateVersionDataObject();

        if (m_VersionDataObject.BundleIdentifier != PlayerSettings.applicationIdentifier)
        {
            m_VersionDataObject.BundleIdentifier = PlayerSettings.applicationIdentifier;
            Debug.LogFormat(" 11 modifierKeysChanged Indentifier : {0} ", GUI.changed);
        }

        if (m_VersionDataObject.BundleVersion != PlayerSettings.bundleVersion)
        {
            m_VersionDataObject.BundleVersion = PlayerSettings.bundleVersion;
            Debug.LogFormat("22 modifierKeysChanged Indentifier : {0} ", GUI.changed);
        }

        if (m_VersionDataObject.AndroidBundleVersionCode != PlayerSettings.Android.bundleVersionCode )
        {
            m_VersionDataObject.AndroidBundleVersionCode = PlayerSettings.Android.bundleVersionCode;
            Debug.LogFormat("33 modifierKeysChanged Indentifier : {0} ", GUI.changed);
        }
    }


    //static void delayCall()
    //{
    //    // 리빌드 적용시에만 호출됨
    //    Debug.LogFormat(" delayCall : ");
    //}
    //static void projectWindowChanged()
    //{
    //    Debug.LogFormat(" projectWindowItemOnGUI : ");
    //}
    //static void Update()
    //{
    //    string month;
    //    if (System.DateTime.Now.Month <= 9)
    //    {
    //        month = "0" + System.DateTime.Now.Month;
    //    }
    //    else
    //    {
    //        month = System.DateTime.Now.Month.ToString();
    //    }
    //    string day;

    //    if (System.DateTime.Now.Day <= 9)
    //    {
    //        day = "0" + System.DateTime.Now.Day;
    //    }
    //    else
    //    {
    //        day = System.DateTime.Now.Day.ToString();
    //    }
    //    string hour;
    //    if (System.DateTime.Now.Hour <= 9)
    //    {
    //        hour = "0" + System.DateTime.Now.Hour;
    //    }
    //    else
    //    {
    //        hour = System.DateTime.Now.Hour.ToString();
    //    }
    //    string minute;
    //    if (System.DateTime.Now.Minute <= 9)
    //    {
    //        minute = "0" + System.DateTime.Now.Minute;
    //    }
    //    else
    //    {
    //        minute = System.DateTime.Now.Minute.ToString();
    //    }
    //}


} 
