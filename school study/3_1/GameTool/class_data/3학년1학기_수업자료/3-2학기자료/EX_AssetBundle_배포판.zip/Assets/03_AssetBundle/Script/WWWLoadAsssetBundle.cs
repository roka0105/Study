﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace Du3Project
{

	public class WWWLoadAsssetBundle : MonoBehaviour
	{
        public string URL = "https://magotoolivesource.github.io/GitHomePage/BuldleVer01";
        public string RootBundleName = "BuldleVer01";

        public string ZIPURL = "https://magotoolivesource.github.io/GitHomePage/DownBundle";
        public string ZipBundleName = "BuldleVer01.zip";


        public string LocalZipBundleFolder = "ZipBundle";
        public string LocalZipRootBundleName = "BuldleVer01";

        [Header("[데이터 확인용]")]
        [SerializeField]
        protected AssetBundle m_MainBundle = null;
        protected Dictionary<string, AssetBundle> m_AllDepenciesBundleDict = new Dictionary<string, AssetBundle>();
        [SerializeField]
        protected List<LinkAssetBundleData> m_AllAssetBundleList = new List<LinkAssetBundleData>();


        [Header("테스트용")]
        public Image TestImage = null;



        void WWWLoadAssetBundle()
        {
            StartCoroutine(AsyndWWWLoadAssetBundle2());
        }


        IEnumerator AsyndWWWLoadAssetBundle2()
        {
            string uri = string.Format("{0}/{1}", ZIPURL, ZipBundleName);
            UnityEngine.Networking.UnityWebRequest request = UnityEngine.Networking.UnityWebRequestAssetBundle.GetAssetBundle(uri);
            request.downloadHandler = new UnityEngine.Networking.DownloadHandlerBuffer();
            yield return request.SendWebRequest();

            if (request.isNetworkError || request.isHttpError)
            {
                Debug.LogErrorFormat("WWW 로딩실패 : {0}", uri);
                yield break;
            }

            byte[] zipbyte = request.downloadHandler.data;
            //zip 파일 압축 풀어서 로컬에 저장 그후에 일반 LocalLoad 방식으로 데이터 로드하기

            SaveZipFile(zipbyte);
            UnZipFile(zipbyte);



            // 기존 방식대로 확인하기용
            //LoadAssetBuldle2(LocalZipBundleFolder, LocalZipRootBundleName);

            

            

        }

        // 로컬 저장
        void SaveZipFile(byte[] p_data)
        {
            
            string path = Path.Combine(Application.streamingAssetsPath, string.Format("{0}/", LocalZipBundleFolder));
            //string testpath = System.IO.Path.GetDirectoryName(path);
            if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(path)))
            {
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
            }

            string savepath = Path.Combine(Application.streamingAssetsPath, string.Format("{0}/{1}", LocalZipBundleFolder, ZipBundleName));
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(savepath, FileMode.Create);
            formatter.Serialize(stream, p_data);

            stream.Close();
        }

        void UnZipFile( byte[] p_bytezipdatas )
        {
            string unzippath = Path.Combine(Application.persistentDataPath, string.Format("{0}", LocalZipBundleFolder));

            StartCoroutine( ExtractZipFile.ExtractZipFileL(p_bytezipdatas, unzippath, 256 * 1024, CompleteUnZip ) );

        }

        void CompleteUnZip()
        {
            if(false)
            {
                // 내부 저장된 파일 로드방식
                LoadAssetBundle2(LocalZipBundleFolder, LocalZipRootBundleName);
                DynamicLoadInstance();
                Test_AssetBundleLoadGameObject();
                Test_AssetBundleLoadUI();
            }
            else
            {
                // url 방식 로드
                StartCoroutine( LoadAssetBundle3(LocalZipBundleFolder, LocalZipRootBundleName) );
            }
        }

        IEnumerator LoadAssetBundle3(string p_bundlepath, string p_rootbundlename)
        {
            // string uri = "file:///Users/user/AssetBundles/" + assetBundleName;

            // 중간부분
            string uri = "file:///" + Application.persistentDataPath + string.Format("/{0}/{1}", p_bundlepath, p_rootbundlename);
            UnityWebRequest request = UnityWebRequestAssetBundle.GetAssetBundle(uri, 0);
            yield return request.SendWebRequest();
            AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(request);
            m_MainBundle = bundle;


            AssetBundleManifest manifest = m_MainBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");

            string path = Path.Combine(Application.persistentDataPath, string.Format("{0}", p_bundlepath));
            string[] assetbundleinfoarr = manifest.GetAllAssetBundles();
            foreach (string dependency in assetbundleinfoarr)
            {
                uri = Path.Combine(path + "/", dependency);
                request = UnityWebRequestAssetBundle.GetAssetBundle(uri, 0);
                yield return request.SendWebRequest();


                bundle = DownloadHandlerAssetBundle.GetContent(request);
                m_AllDepenciesBundleDict.Add(dependency, bundle);
                m_AllAssetBundleList.Add(new LinkAssetBundleData() { BundleName = dependency, AssetBundleData = bundle });
            }

            DynamicLoadInstance();
            Test_AssetBundleLoadGameObject();
            Test_AssetBundleLoadUI();
        }

        void LoadAssetBundle2( string p_bundlepath, string p_rootbundlename )
        {
            // : Application.persistentDataPath  %userprofile%\AppData/LocalLow/<companyname>/<productname>
            string path = Path.Combine(Application.persistentDataPath, string.Format("{0}/{1}", p_bundlepath, p_rootbundlename));

            m_MainBundle = AssetBundle.LoadFromFile(path);
            m_AllAssetBundleList.Add(new LinkAssetBundleData() { BundleName = "main", AssetBundleData = m_MainBundle });

            // "AssetBundleManifest" 이름은 고정임 파일 내부의 고유 이름으로 찾는방식임
            AssetBundleManifest manifest = m_MainBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");



            path = Path.Combine(Application.persistentDataPath, string.Format("{0}", p_bundlepath));
            string[] assetbundleinfoarr = manifest.GetAllAssetBundles();
            foreach (string dependency in assetbundleinfoarr)
            {
                AssetBundle bundle = AssetBundle.LoadFromFile(Path.Combine(path + "/", dependency));
                m_AllDepenciesBundleDict.Add(dependency, bundle);
                m_AllAssetBundleList.Add(new LinkAssetBundleData() { BundleName = dependency, AssetBundleData = bundle });
            }
        }



        void DynamicLoadInstance()
        {
            // 단일애셋로드
            //GameObject obj = m_MainBundle.LoadAsset<GameObject>( "asset-name" );



            // 전체파일 로드방식
            UnityEngine.Object[] objectArray = m_MainBundle.LoadAllAssets();
            foreach (var item in objectArray)
            {
                Debug.LogFormat("child item : {0}", item.name );
            }

            // 해당 아이템들 전체 확인
            foreach (var item in m_AllDepenciesBundleDict)
            {
                UnityEngine.Object[] childarray = item.Value.LoadAllAssets();
                foreach (var child in childarray)
                {
                    Debug.LogFormat("child item : {0}", child.name);
                }
            }

        }

        void Test_AssetBundleLoadGameObject()
        {
            // 프리팹 확인용
            AssetBundle bundle = m_AllDepenciesBundleDict["prefab/character01.ver01"];
            GameObject obj = bundle.LoadAsset<GameObject>("Character01");
            GameObject copyobj = GameObject.Instantiate(obj);
            copyobj.name = "프리팹";

            obj = bundle.LoadAsset<GameObject>("Character02");
            copyobj = GameObject.Instantiate(obj, new Vector3(1, 0f, 0f), Quaternion.identity);
            copyobj.name = "번들로드2";


            obj = bundle.LoadAsset<GameObject>("Character03");
            copyobj = GameObject.Instantiate(obj, new Vector3(2, 0f, 0f), Quaternion.identity);
            copyobj.name = "번들로드3";
        }

        void Test_AssetBundleLoadUI()
        {
            AssetBundle bundle = m_AllDepenciesBundleDict["ui/yellow01"];
            TestImage.sprite = bundle.LoadAsset<Sprite>("yellow");
        }

        private void Awake()
        {
            WWWLoadAssetBundle();
            //DynamicLoadInstance();
            //Test_AssetBundleLoadGameObject();
            //Test_AssetBundleLoadUI();
        }

        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}