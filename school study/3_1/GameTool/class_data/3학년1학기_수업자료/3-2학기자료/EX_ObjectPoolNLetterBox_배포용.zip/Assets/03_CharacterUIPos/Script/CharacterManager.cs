﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class CharacterManager : Singleton_Mono<CharacterManager>
    {
        [Header("[캐릭터 설정]")]
        public BaseActor CloneBaseActor = null;
        public LayerMask CloneActorLayerMask;
        public Transform ActorParent;

        [Header("[마우스클릭 설정값들]")]
        public Camera m_WorldCamera = null;
        public float DirectionLength = 400f;
        protected Ray m_Ray = new Ray();
        [SerializeField]
        protected BaseActor m_CopyActor = null;


        protected List<BaseActor> m_ActorAllList = new List<BaseActor>();


        private void Awake()
        {
            CharacterTableManager tablemanaer = CharacterTableManager.GetI; // 초기화용
            m_ActorAllList.Clear();

        }


        void Start()
		{
			
		}

        public void RemoveActor()
        {
            if(m_ActorAllList.Count > 0)
            {
                m_ActorAllList[0].DestroyActor();
                ObjectPoolManager.GetI.RemoveObject(m_ActorAllList[0], this.transform);
                m_ActorAllList.RemoveAt(0);
            }
            
        }

        public bool ISLandHit()
        {
            m_Ray = m_WorldCamera.ScreenPointToRay(Input.mousePosition);

            RaycastHit hitinfo;
            if (Physics.Raycast(m_Ray, out hitinfo, DirectionLength, CloneActorLayerMask))
            {
                return true;
            }

            return false;
        }

        public void GetWorldPos(Transform p_targetobj)
        {
            m_Ray = m_WorldCamera.ScreenPointToRay(Input.mousePosition);

            RaycastHit hitinfo;
            if (Physics.Raycast(m_Ray, out hitinfo, DirectionLength, CloneActorLayerMask))
            {
                p_targetobj.transform.position = hitinfo.point;
            }
        }

        void MousePositionCreateCharacter()
        {
            m_CopyActor = ObjectPoolManager.GetI.CreateObject(CloneBaseActor, ActorParent);
            m_ActorAllList.Add(m_CopyActor);

            uint actorid = CharacterTableManager.GetI.Test_GetRandomActorID();
            m_CopyActor.InitSetting(actorid);
        }


		void Update()
		{

            if(m_CopyActor)
            {
                GetWorldPos(m_CopyActor.transform);
            }

            if(Input.GetMouseButtonDown(0)
                && ISLandHit() )
            {
                MousePositionCreateCharacter();
            }

            if(Input.GetMouseButtonUp(0))
            {
                m_CopyActor = null;
            }


            if( Input.GetKeyDown(KeyCode.D))
            {
                RemoveActor();
            }
		}


        private void OnDrawGizmos()
        {
            Vector3 startpos = this.m_WorldCamera.transform.position;
            Vector3 endpos = this.m_WorldCamera.transform.position + (m_Ray.direction * DirectionLength);

            Debug.DrawLine(startpos, endpos, Color.red);
        }



        [Header("[HP바참고용]")]
        public Camera UI3DWorldCamera = null;
        public HPBarUI m_CloneHPBarUI = null;
        public Transform m_HPBarTrans = null;
        public Transform m_HPBarRemoveTrans = null;
        public HPBarUI CreateHPBarUI()
        {
            HPBarUI copyhpbarui = ObjectPoolManager.GetI.CreateObject(m_CloneHPBarUI, m_HPBarTrans);
            return copyhpbarui;
        }

        public void RemoveHPBarUI(HPBarUI p_hpbar)
        {
            ObjectPoolManager.GetI.RemoveObject(p_hpbar, m_HPBarRemoveTrans);
        }

    }
}