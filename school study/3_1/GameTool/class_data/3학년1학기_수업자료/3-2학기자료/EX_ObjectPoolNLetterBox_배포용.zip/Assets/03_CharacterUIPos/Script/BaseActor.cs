﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{

	public class BaseActor : MonoBehaviour
	{
        [SerializeField]
        protected HPBarUI m_HpBarUI = null;
        //public Transform HPBarUITrans = null;

        [SerializeField]
        protected ActorTableData m_ActorTableData = null;

        private void Awake()
        {
            
        }

        public void InitSetting(uint p_actorid)
        {
            m_HpBarUI = CharacterManager.GetI.CreateHPBarUI();
            m_HpBarUI.Init(CharacterManager.GetI.UI3DWorldCamera, this.transform);

            m_ActorTableData = CharacterTableManager.GetI.GetActorTableData(p_actorid);
        }
        public void DestroyActor()
        {
            CharacterManager.GetI.RemoveHPBarUI(m_HpBarUI);
            m_ActorTableData = null;
        }

        void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}