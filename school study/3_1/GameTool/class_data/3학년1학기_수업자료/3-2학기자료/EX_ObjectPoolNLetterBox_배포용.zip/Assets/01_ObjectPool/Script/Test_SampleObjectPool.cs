﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class Test_SampleObjectPool : MonoBehaviour
	{
        [Header("[세트1]")]
        public GameObject TestGameObject = null;
        public Transform TestCreateObjectParent1 = null;
        public Transform TestRemoveCreateObjectParent1 = null;


        [Header("[세트2]")]
        public Test_SampleCompoment TestSampleGameObject = null;
        public Transform TestCreateObjectParent2 = null;
        public Transform TestRemoveCreateObjectParent2 = null;

        //[ContextMenu("[]")]
        public void Test_CloneGameObject()
        {
            Transform cpyobj = ObjectPoolManager.GetI.CreateDelayRemoveObject(TestGameObject.transform
                                , 2f
                                , TestCreateObjectParent1
                                , TestRemoveCreateObjectParent1 );
            cpyobj.transform.position = new Vector3(Random.value * 4f, Random.value * 4f, Random.value * 4f);


        }


        public List<Test_SampleCompoment> m_TestCloneObjectList = new List<Test_SampleCompoment>();
        public void Test_CreateCloneObject()
        {
            Test_SampleCompoment copyobj = ObjectPoolManager.GetI.CreateObject(TestSampleGameObject, TestCreateObjectParent2);
            m_TestCloneObjectList.Add(copyobj);

            copyobj.transform.position = new Vector3(Random.value * 4f, Random.value * 4f, Random.value * 4f);
        }
        public void Test_DestroyCloneObject()
        {
            if(m_TestCloneObjectList.Count > 0)
            {
                ObjectPoolManager.GetI.RemoveObject(m_TestCloneObjectList[0], TestRemoveCreateObjectParent2);
                m_TestCloneObjectList.RemoveAt(0);
            }
            
        }

		void Start()
		{
			
		}

		void Update()
		{
			if(Input.GetKeyDown(KeyCode.A ))
            {
                Test_CloneGameObject();
            }


            if (Input.GetKeyDown(KeyCode.H))
            {
                Test_CreateCloneObject();
            }

            if(Input.GetKeyDown(KeyCode.J))
            {
                Test_DestroyCloneObject();
            }

        }
	}
}