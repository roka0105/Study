﻿using UnityEngine;

public class SingletonTample<T> where T : class, new()
{
    protected static T instance = null;

    /**
      Returns the instance of this singleton.
   */
    public static T GetI
    {
        get
        {
            if (instance == null)
            {
                instance = new T();
                SingletonTample<T> tempinst = instance as SingletonTample<T>;
                tempinst.SingletoneInit();
                if (instance == null)
                {
                    Debug.LogError("An instance of " + typeof(T) +
                                   " is needed in the scene, but there is none.");
                }
            }

            return instance;
        }
    }


    // 초기화구현용.
    public virtual void SingletoneInit() { }


    #region 싱글톤 생성및 지우는것 

    public static void DestroyInstance()
    {
        if (instance != null)
        {
            instance = null;
        }
    }

    #endregion 싱글톤 생성및 지우는것 

}