﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
    [System.Serializable]
    public class ActorTableData
    {
        protected ActorTableData()
        {

        }
        public ActorTableData(uint p_id)
        {
            m_ID = p_id;
        }
        protected uint m_ID = 0;
        public uint ID
        {
            get { return m_ID; }
        }

        public string Name = "";
        public float AttackVal = 1f;
        public float DefVal = 1f;
        public int MaxLV = 20;
        public int MAXHP = 100;
        public int MAXMP = 100;
        public string SpriteImageName = "";

    }


    public enum MainActorIDType : uint
    {
        MainActorStartIndex = CharacterTableManager.MainActorStartIndex,
        MainActorTyp01,
        MainActorTyp02,
        MainActorTyp03,
        MainActorTyp04,

        Max
    }

    public enum MobActorIDType : uint
    {
        MobActorStartIndex = CharacterTableManager.MobActorStartIndex,
        MobType01,
        MobType02,
        MobType03,
        MobMiddleBoxxType01,
        MobMiddleBoxxType02,
        BossType01,

        Max
    }

    [System.Serializable]
    public class CharacterTableManager : SingletonTample<CharacterTableManager>
	{
        public const uint MainActorStartIndex = 100;
        public const uint MobActorStartIndex = 10000;
        public const uint NPCActorStartIndex = 100000;


        protected List<ActorTableData> m_ActorTableDataList = new List<ActorTableData>()
        {
            new ActorTableData((uint)MainActorIDType.MainActorTyp01){ Name ="캐릭터1", AttackVal = 2f, DefVal = 2f },
            new ActorTableData((uint)MainActorIDType.MainActorTyp02){ Name ="캐릭터2", AttackVal = 3f, DefVal = 1f },

            new ActorTableData((uint)MobActorIDType.MobType01){ Name ="몹1", AttackVal = 2f, DefVal = 2f },
            new ActorTableData((uint)MobActorIDType.MobType02){ Name ="몹2", AttackVal = 3f, DefVal = 2f },
            new ActorTableData((uint)MobActorIDType.BossType01){ Name ="보스몹3", AttackVal = 4f, DefVal = 4f },
        };

        protected Dictionary<uint, ActorTableData> m_ActorTableDataDict = new Dictionary<uint, ActorTableData>();
        public override void SingletoneInit()
        {
            m_ActorTableDataDict.Clear();

            foreach (var item in m_ActorTableDataList)
            {
                m_ActorTableDataDict.Add(item.ID, item);
            }
        }

        public ActorTableData GetActorTableData( uint p_id )
        {
            ActorTableData outdata = null;
            if(m_ActorTableDataDict.TryGetValue(p_id, out outdata) )
            {
                return outdata;
            }

            return null;
        }

        public uint Test_GetRandomActorID()
        {
            int index = Random.Range(0, m_ActorTableDataList.Count);
            return m_ActorTableDataList[index].ID;
        }





    }
}