﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Du3Project
{
    // 기타 다른 letterbox 
    // https://unity-programmer.tistory.com/7
    // http://wiki.unity3d.com/index.php?title=AspectRatioEnforcer
    [ExecuteInEditMode]
	public class LetterBox : MonoBehaviour
	{
        [Header("[값확인용]")]
        [SerializeField]
        protected Vector2 ReferenceResolution = new Vector2(1280, 720);
        [SerializeField]
        protected CanvasScaler m_CanvasScaler = null;
        [SerializeField]
        protected float m_Aspector = 1.77777f;
        [SerializeField]
        protected float m_CompareAspector = 1.77777f;

        [SerializeField]
        protected Vector2Int m_ScreenSize = new Vector2Int(0, 0);
        [SerializeField]
        protected Camera m_MainCamera = null;
        [SerializeField]
        protected float m_CameraAspect = 1.7777f;

        public void UpdateScreen()
        {
            m_CameraAspect = m_MainCamera.aspect;
            
            m_ScreenSize.x = m_MainCamera.pixelWidth;
            m_ScreenSize.y = m_MainCamera.pixelHeight;
            float aspector = (float)m_ScreenSize.x / (float)m_ScreenSize.y;
            if( (aspector - 0.00001f < m_Aspector) && (m_Aspector < aspector + 0.00001f) )
            {
                return;
            }

            m_Aspector = aspector;
            if ( m_Aspector >= m_CompareAspector)
            {
                m_CanvasScaler.matchWidthOrHeight = 1f;
            }
            else
            {
                m_CanvasScaler.matchWidthOrHeight = 0f;
            }
        }

        [ContextMenu("[화면비율변화용]")]
        void Test_EditorScreen()
        {
            UpdateScreen();
        }

        private void Awake()
        {
            m_CanvasScaler = GetComponent<CanvasScaler>();
            ReferenceResolution = m_CanvasScaler.referenceResolution;
            m_CompareAspector = (float)m_CanvasScaler.referenceResolution.x / (float)m_CanvasScaler.referenceResolution.y;

#if !UNITY_EDITOR
            if( Application.isPlaying )
                UpdateScreen();
#endif
        }

        void Start()
		{
			
		}

		void Update()
		{
#if UNITY_EDITOR
            UpdateScreen();
#endif


        }
	}
}