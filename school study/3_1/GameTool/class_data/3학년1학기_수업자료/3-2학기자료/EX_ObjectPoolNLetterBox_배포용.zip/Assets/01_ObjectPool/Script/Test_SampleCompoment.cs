﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class Test_SampleCompoment : MonoBehaviour
	{
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}