﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class WorldPosTOScreenUIPos : MonoBehaviour
	{
        [Header("[3D상의 오브젝트및 카메라]")]
        public Camera m_WorldCamera = null;
        public Transform World3DObject = null;
        public Transform Guide3DObject = null;
        public Transform Guide2DObject = null;

        [Header("[2D상의오브젝트및카메라]")]
        public Camera m_UICamera = null;
        public RectTransform m_RectTransform = null;
        public float OffsetPos = 0f;



        [Header("[확인용값들]")]
        public Vector3 ScreenWorldPos = new Vector3();


        [SerializeField]
        Canvas m_ParentCanvas = null;


        [ContextMenu("[3D값확인용]")]
        void Test_UpdateContext()
        {
            Test_UpdateGet2DUIPosTO3DWorldPos();
        }

        public void Test_UpdateGet2DUIPosTO3DWorldPos()
        {
            if(m_RectTransform == null)
            {
                m_RectTransform = GetComponent<RectTransform>();
            }

            if(m_ParentCanvas == null)
            {
                m_ParentCanvas = GetComponentInParent<Canvas>();
            }

            ScreenWorldPos = m_WorldCamera.WorldToScreenPoint(World3DObject.position);
            Guide3DObject.transform.position = ScreenWorldPos;


            if (m_ParentCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                // ui가 overlap 일때는 
                // anchers.min = anchers.max = Vector2(0f, 0f), Poviot = Vector2(0.5f, 0.5f) 
                // 로 설정해야지 가운데 잘 정리가됨 
                // 이때는 왼하단을 기준으로 위치값을 가지고 있어야지됨
                Guide2DObject.transform.position = ScreenWorldPos;
            }
            else
            {
                m_RectTransform = this.transform.parent as RectTransform;
                m_UICamera = m_ParentCanvas.worldCamera;

                var localpos = Vector2.zero;
                RectTransformUtility.ScreenPointToLocalPointInRectangle(m_RectTransform
                    , ScreenWorldPos
                    , m_UICamera
                    , out localpos);

                localpos.y += OffsetPos;
                //this.transform.localPosition = localpos;
                Guide2DObject.transform.localPosition = localpos;

            }
        }

		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}
