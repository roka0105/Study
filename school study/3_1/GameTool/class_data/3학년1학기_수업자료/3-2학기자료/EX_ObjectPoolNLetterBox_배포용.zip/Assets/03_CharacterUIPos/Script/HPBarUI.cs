﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
    [RequireComponent(typeof(RectTransform)) ]
	public class HPBarUI : MonoBehaviour
	{
        [Header("[3D상의 오브젝트및 카메라]")]
        public Camera m_WorldCamera = null;
        public Transform World3DObject = null;

        [Header("[2D상의오브젝트및카메라]")]
        protected Camera m_UICamera = null;
        protected RectTransform m_RectTransform = null;
        public float OffsetPos = 0f;

        [Header("[확인용값들]"), SerializeField]
        protected Vector3 m_ScreenWorldPos = new Vector3();
        [SerializeField]
        Canvas m_ParentCanvas = null;
        RectTransform m_ThisRect = null;


        // 귀찮음 프리팹으로 사용시는 값들을 직접 받아서 적용하도록 하면됨 
        // 사용자들이 알아서 만들어야지됨 -_-;
        public void Init( Camera p_worldcam, Transform p_targetobj )
        {
            m_WorldCamera = p_worldcam;
            World3DObject = p_targetobj;
            m_RectTransform.localScale = new Vector3(1f, 1f, 1f); // 복사 될때 스케일값 이상하게 됨 위치 이동되면서 생기는 현상값음
        }

        public void DestroyHPBarUI()
        {
            m_WorldCamera = null;
            World3DObject = null;
        }

        void UpdateTargetMove()
        {
            if (m_WorldCamera == null || World3DObject == null)
                return;

            m_ScreenWorldPos = m_WorldCamera.WorldToScreenPoint(World3DObject.position);
            //Vector3 temppos = ScreenWorldPos;


            if (m_ParentCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                // ui가 overlap 일때는 
                // anchers.min = anchers.max = Vector2(0f, 0f), Poviot = Vector2(0.5f, 0.5f) 
                // 로 설정해야지 가운데 잘 정리가됨 
                // 이때는 왼하단을 기준으로 위치값을 가지고 있어야지됨
                this.transform.position = m_ScreenWorldPos;
            }
            else
            {
                m_RectTransform = this.transform.parent as RectTransform;
                m_UICamera = m_ParentCanvas.worldCamera;

                var localpos = Vector2.zero;
                RectTransformUtility.ScreenPointToLocalPointInRectangle(m_RectTransform
                    , m_ScreenWorldPos
                    , m_UICamera
                    , out localpos);

                localpos.y += OffsetPos;
                this.transform.localPosition = localpos;
            }
        }

        private void Awake()
        {
            if (m_RectTransform == null)
                m_RectTransform = GetComponent<RectTransform>();

            if (m_ParentCanvas == null)
                m_ParentCanvas = GetComponentInParent<Canvas>();

            
        }

        void Start()
		{
			
		}

		void Update()
		{
            UpdateTargetMove();

        }
	}
}