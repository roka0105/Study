﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Du3Project
{
	public class Screen2DTOWorldPos : MonoBehaviour
	{
        [Header("[설정값들]")]
        public Camera m_WorldCamera = null;
        public Transform m_TargetObject = null;
        public float DirectionLength = 400f;

        protected Ray m_Ray = new Ray();


        [Header("[확인용값들]")]
        [SerializeField]
        protected Vector3 m_StartPos = new Vector3();
        [SerializeField]
        protected Vector3 m_EndPos = new Vector3();

        public void Test_UpdatePos()
        {
            GetWorldPos();
        }

        public void GetWorldPos()
        {
            m_Ray = m_WorldCamera.ScreenPointToRay( Input.mousePosition );

            RaycastHit hitinfo;
            if( Physics.Raycast(m_Ray, out hitinfo, DirectionLength) )
            {
                m_TargetObject.transform.position = hitinfo.point;
                //m_StartPos = hitinfo.point;

                m_StartPos = m_Ray.origin;
                m_EndPos = m_StartPos + (m_Ray.direction * DirectionLength);
            }
        }

        private void OnDrawGizmos()
        {
            Vector3 startpos = this.m_WorldCamera.transform.position;
            Vector3 endpos = this.m_WorldCamera.transform.position + (m_Ray.direction * DirectionLength);

            Debug.DrawLine(startpos, endpos, Color.red );
        }


        void Start()
		{
			
		}

		void Update()
		{
			if( Input.GetMouseButton(0) )
            {
                GetWorldPos();

            }
		}
	}
}