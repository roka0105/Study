use cookdb;
-- 한번이라도 구매 기록이 있는 회원의 이름과 주소
select distinct u.username,u.addr from usertbl as u join buytbl as b on u.userid=b.userid;

-- 각 지역 별로 평균키보다 큰 사람들의 주소,이름,키를 조회
-- 상관 커리 사용  아 근데 이거는 전체 평균보다 큰 사람 조회임. 조금 다름.
select addr,username,height from usertbl as u where height >=(select avg(height)from usertbl);
-- join 사용
-- join에 대상이 되는 테이블이 쿼리문의 결과 테이블일수 있다.
select u.addr,u.username,u.height from usertbl as u join (select addr,avg(height) as 키 from usertbl group by addr) as u2 on u.addr=u2.addr where u.height>u2.키;
select u.addr,u.username,u.height from usertbl as u join (select addr,avg(height) as 키 from usertbl group by addr) as u2 on u.addr=u2.addr and u.height>u2.키 ;

use madang;
-- 각 고객이 주문한 도서의 이름들을 조회
select c.customer_name,b.bookname from orders_table as o join customer_table as c on o.custid=c.custid join book_table as b on o.bookid =b.bookid;
-- 교수님 버전
select c.customer_name,b.bookname from customer_table as c join orders_table as o on c.custid=o.custid join book_table as b on o.bookid=b.bookid order by c.customer_name;

-- 가격이 20,000원 이상인 도서를 주문한 고객의 이름과 도서의 이름 조회
select c.customer_name,b.bookname from customer_table as c join orders_table as o on c.custid=o.custid join book_table as b on o.bookid=b.bookid where b.price>=20000 order by c.customer_name;

-- 정가보다 싸게 산 고객의 아이디, 이름, 구매가격을 조회
select c.customer_name,b.bookname,b.price as 원가, o.saleprice as 할인가 from customer_table as c join orders_table as o on c.custid=o.custid join book_table as b on o.bookid=b.bookid
where b.price > o.saleprice order by c.customer_name;

-- 날짜 별로 가장 돈을 많이 쓴 고객의 이름과 구매 가격 조회
-- 이거는 출력이 올바르게 안됨 join 의 custid가.
select t.orderdate,c.customer_name,t.최고가 from customer_table as c join (select orderdate,custid,max(saleprice)as 최고가 from orders_table group by orderdate) as t on c.custid=t.custid order by t.orderdate;

-- 여기 서브쿼리는 독립 서브쿼리이며 안쪽에서 한번만 실행된것 토대로 바깥도 한번 실행
select o.orderdate,c.customer_name,o.saleprice from customer_table as c 
join(select * from orders_table where (orderdate,saleprice) in (select orderdate,max(saleprice)as 최고가 from orders_table group by orderdate)) as o on c.custid=o.custid order by o.orderdate;

-- 상관 서브쿼리로 바꿔서 같은 결과가 나오게 변경하기
-- 상관 쿼리에서는 바깥의 레코드 수 만큼 안쪽에서도 실행된다.
select o1.orderdate,o1.custid,o1.saleprice from orders_table as o1
where o1.saleprice = (select max(o2.saleprice) from orders_table as o2 where o1.orderdate=o2.orderdate);

use cookdb;
-- 총 구매액이 1000이 넘는 고객들의 정보 조회
-- 독립서브쿼리 ver
-- 내가 한 오답
select * from usertbl as u where u.userid in (select userid,sum(price*amount)from buytbl group by userid having sum(price*amount)>=1000) as u2);
-- 교수님 풀이
select userid,username,addr from usertbl where userid in (select userid from buytbl group by userid having sum(price*amount)>1000);

-- 상관쿼리 ver
select distinct b1.userid from buytbl as b1 where (select sum(b2.price*b2.amount) from buytbl as b2 where b1.userid=b2.userid)>1000;

-- join ver  중첩쿼리를 join으로 해결할수 있다면 join 사용, 그다음이 독립, 그래도 힘들다 상관 으로 구현 이 순으로 구현 우선순위 두는걸 추천.
select u.userid,u.username,u.addr from usertbl as u join (select userid,sum(price*amount)as 구매가 from buytbl group by userid)as b on u.userid=b.userid where b.구매가 >1000;  

-- 제품 분류 별로 가장 구매액이 큰 유저의 이름과, 연락처, 구매액을 조회
select userid,productname,구매가 from (select userid,productname,max(price*amount)as 구매가 from buytbl group by productname)as b;
select userid,productname, max(price*amount)as 구매가 from buytbl group by productname,userid;

select b.productname,u.username,u.mobile1,u.mobile2,b.구매가 from usertbl as u join (select userid,productname, max(price*amount)as 구매가 from buytbl as b1 where b1.구매가 <= (select userid,productname, max(price*amount)as 구매가 from buytbl as b2 group by productname,userid)group by userid) as b 
on u.userid=b.userid;
select b.productname,u.username,u.mobile1,u.mobile2,b.구매가 from usertbl as u join (select userid,productname, max(price*amount)as 구매가 from buytbl as b1 group by productname,userid) as b 
on u.userid=b.userid join (select userid,productname, max(price*amount)as 구매가 from buytbl as b1 group by productname,userid) as b2 on b.구매가 <= b2.구매가;

-- 교수님 풀이
-- 그룹네임이 null 인것은 없음으로 변경시키기.
update buytbl set groupname ='없음' where groupname is null;
select groupname,userid,price*amount from buytbl where (groupname,price*amount) in (select groupname,max(price*amount)as 구매최고액 from buytbl group by groupname);

-- 위 문제를 join으로 변경 join 쓰는게 효율이 더 좋음! 집계함수를 사용할때 그 정보를 빼와서 그 대상을 가지고 무언가를 할때 join 사용이 편함.
-- 항상 어떤걸 구현할때 어떤 구현이 효율적인지 생각하고 그 순서대로 짜기.
select b.groupname,u.username,u.addr,b.구매최고액 from usertbl as u join (select b.groupname,b.userid,b2.구매최고액 from buytbl as b 
join (select userid,groupname,max(price*amount)as 구매최고액 from buytbl group by groupname) as b2 
on b.groupname=b2.groupname where b.price*b.amount=b2.구매최고액) as b
on u.userid=b.userid;

-- 외부 join 학습
-- 두 조건을 만족하는 레코드를 붙여서 출력하는것이 내부조인인데 한쪽 레코드의 필드가 대상 테이블에 없으면 보통 탈락인데
-- 외부조인에서는 그자리를 null로 채워서 포함시킨다.
-- 외부조인은 어느 테이블을 기준으로 조인하는지에 따라 결과가 달라진다.
-- 먼저나온 테이블 기준 left outer join 나중에 나온 테이블 기준 right outer join
-- concat 은 두 필드를 하나로 붙여서 출력하는 키워드 

-- 전체 회원의 구매기록을 출력하되 구매기록이 없는 회원도 출력
use cookdb;
select * from usertbl as u left outer join buytbl as b on u.userid=b.userid
where b.productname is null;

-- 동아리 테이블 생성
USE cookdb;
CREATE TABLE stdTBL 
( stdName VARCHAR(10) NOT NULL PRIMARY KEY, 
  addr CHAR(4) NOT NULL
);
CREATE TABLE clubTBL 
( clubName VARCHAR(10) NOT NULL PRIMARY KEY, 
  roomNo CHAR(4) NOT NULL
);
CREATE TABLE stdclubTBL 
( num int AUTO_INCREMENT NOT NULL PRIMARY KEY, 
  stdName VARCHAR(10) NOT NULL, 
  clubName VARCHAR(10) NOT NULL, 
  FOREIGN KEY(stdName) REFERENCES stdTBL(stdName), 
  FOREIGN KEY(clubName) REFERENCES clubTBL(clubName)
);
INSERT INTO stdTBL VALUES ('강호동', '경북'), ('김제동', '경남'), ('김용만', '서울'), ('이휘재', '경기'), ('박수홍', '서울');
INSERT INTO clubTBL VALUES ('수영', '101호'), ('바둑', '102호'), ('축구', '103호'), ('봉사', '104호');
INSERT INTO stdclubTBL VALUES (NULL, '강호동', '바둑'), (NULL, '강호동', '축구'), (NULL, '김용만', '축구'), (NULL, '이휘재', '축구'), (NULL, '이휘재', '봉사'), (NULL, '박수홍', '봉사');

-- 학생들의 동아리 가입정보를 출력하는데 가입한 동아리가 없는 학생도 출력
select * from stdtbl as s left outer join stdclubtbl as c on s.stdName=c.stdName
left outer join clubtbl as ct on c.clubName=ct.clubName union
-- 위의 명령줄에서 ; 를 지우고 union 을 하면 위의 명령문의 결과와 아래 명령문의 결과를 합쳐서 출력한다. 하지만 이렇게 하면 실행했을때 필드 위치가 적절하지 않게 섞이게 되는데
-- 출력을 * 이 아닌 순서에 맞게 필드명들을 넣어주면 된다.
-- 동아리를 기준으로 가입 학생을 출력하되, 가입 학생이 한명도 없는 동아리도 출력
select * from clubtbl as c left outer join stdclubtbl as s  on c.clubName=s.clubName
left outer join stdtbl as st on s.stdname=st.stdname;

-- 상호조인
-- on 이 없다 join 될 조건이 없다.
-- 앞의 테이블 레코드 * 뒤의 테이블 레코드
-- 각각을 다 join 이는 join 쿼리 속도 테스트용으로 쓰는 경우는 있지만 실제로 사용하는 경우는 드물다.
-- cross join 키워드 사용

-- 자체조인 self join
-- 계층 구조를 갖는 데이터를 테이블로 나타낼때. (직장 조직도에서 직속 상사와 부하에 대한 테이블 같은 경우)
-- 직원 이름(기본키)/상관이름/구내번호
-- 우대리의 상관의 구내번호를 조회한다 할때 그럴때 self join 사용.
-- 조직도 1 의 상관이름이 조직도 2의 직원이름과 같은것을 join 

USE cookDB;
CREATE TABLE empTBL(emp CHAR(3), manager CHAR(3), empTel VARCHAR(8));
INSERT INTO empTBL VALUES ('나사장', NULL, '0000');
INSERT INTO empTBL VALUES ('김재무', '나사장', '2222');
INSERT INTO empTBL VALUES ('김부장', '김재무', '2222-1');
INSERT INTO empTBL VALUES ('이부장', '김재무', '2222-2');
INSERT INTO empTBL VALUES ('우대리', '이부장', '2222-2-1');
INSERT INTO empTBL VALUES ('지사원', '이부장', '2222-2-2');
INSERT INTO empTBL VALUES ('이영업', '나사장', '1111');
INSERT INTO empTBL VALUES ('한과장', '이영업', '1111-1');
INSERT INTO empTBL VALUES ('최정보', '나사장', '3333');
INSERT INTO empTBL VALUES ('윤차장', '최정보', '3333-1');
INSERT INTO empTBL VALUES ('이주임', '윤차장', '3333-1-1');

-- 똑같은 테이블로 join 했을때 self join 이라 함.
select e1.emp as 직원 ,e1.manager as 상관 ,e1.emptel as 직원번호,e2.emptel as 상관번호 from emptbl as e1 
join emptbl as e2 on e1.manager=e2.emp;

-- duration 은 서버에서 돌아가는 시간 체크 fetch는 서버에서 클라로 보내는 시간 체크
-- use employees; 시간 부족해서 이문제는 안나감.


