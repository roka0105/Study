drop database if exists madang;
create database madang;
use madang;
create table book_table(bookid int auto_increment primary key,bookname varchar(20) not null,publisher varchar(20) not null,price int not null);
create table customer_table(custid int auto_increment primary key,customer_name varchar(10) not null,address varchar(20) not null, phone char(13));
create table orders_table(orderid int auto_increment primary key,custid int not null,bookid int not null,saleprice int not null,orderdate date not null,
                          constraint fk_custid foreign key(custid) references customer_table(custid)
                          on update cascade on delete cascade,
                          constraint fk_bookid foreign key(bookid)references book_table(bookid)
                          on update cascade on delete cascade);
                          
insert into Book_table values(null,'축구의 역사','굿스포츠',7000);
insert into Book_table values(null,'축구아는 여자','나무수',13000);
insert into Book_table values(null,'축구의 이해','대한미디어',22000);
insert into Book_table values(null,'골프 바이블','대한미디어',35000);
insert into Book_table values(null,'피겨 교본','굿스포츠',8000);
insert into Book_table values(null,'역도 단계별기술','굿스포츠',6000);
insert into Book_table values(null,'야구의 추억','이상미디어',20000);
insert into Book_table values(null,'야구를 부탁해','이상미디어',13000);
insert into Book_table values(null,'올림픽 이야기','삼성당',7500);
insert into Book_table values(null,'Olympic Champions','Pearson',13000);

insert into Customer_table values(null,'박지성','영국 맨체스타','000-5000-0001');
insert into Customer_table values(null,'김연아','대한민국 서울','000-6000-0001');
insert into Customer_table values(null,'장미란','대한민국 강원도','000-7000-0001');
insert into Customer_table values(null,'추신수','미국 클리블랜드','000-8000-0001');
insert into Customer_table values(null,'박세리','대한민국 대전',null);

insert into Orders_table values(null,1,1,6000,'2014-07-01');
insert into Orders_table values(null,1,3,21000,'2014-07-03');
insert into Orders_table values(null,2,5,8000,'2014-07-03');
insert into Orders_table values(null,3,6,6000,'2014-07-04');
insert into Orders_table values(null,4,7,20000,'2014-07-05');
insert into Orders_table values(null,1,2,12000,'2014-07-07');
insert into Orders_table values(null,4,8,13000,'2014-07-07');
insert into Orders_table values(null,3,10,12000,'2014-07-08');
insert into Orders_table values(null,2,10,7000,'2014-07-09');
insert into Orders_table values(null,3,8,13000,'2014-07-10');

-- 1 가격 20000원 미만 도서 검색
select * from book_table where price < 20000;
-- 2 가격이 10000원 20000이하 도서 검색
select * from book_table where price between 10000 and 20000;
-- 3 출판사 굿스포츠 or 대한미디어 도서검색
select * from book_table where publisher in('굿스포츠','대한미디어');
-- 4 출판사 굿스포츠 or 대한미디어 아닌 도서 검색
select * from book_table where publisher not in('굿스포츠','대한미디어');
-- 5 '축구의 역사'를 출간한 출판사 검색
select bookname as 책이름,publisher as 출판사 from book_table where bookname='축구의 역사';
-- 6 도서이름에 '축구'가 포함된 출판사 검색
select bookname as 책이름,publisher as 출판사 from book_table where bookname like '%축구%';
-- 7 도서이름이 여섯 글자인 도서를 검색
select * from book_table where bookname like '______';
-- 8 도서이름의 왼쪽 두번째 위치에 '구'라는 문자열을 갖는 도서 검색
select * from book_table where bookname like '_구%';
-- 9 축구에 관한 도서 중 가격이 20000원 이상인 도서를 검색
select * from book_table where bookname like '%축구%' and price >=20000;
-- 10 야구에 관한 책을 모두 구입하려면 필요한 금액 계산
select sum(price) as 총금액 from book_table where bookname like '%야구%';
-- 11 도서를 가격순으로 검색하고 가격이 같으면 이름순으로 검색
select bookname as 도서명,price as 금액 from book_table order by price desc,bookname asc; 
-- 12 도서를 가격의 내림차순으로 검색하고 만약 가격이 같다면 출판사의 오름차순으로 검색
select bookname as 도서명,price as 금액,publisher as 출판사 from book_table order by price desc,publisher asc;  
-- 13 주소가 우리나라나 영국인 선수정보 조회
select customer_name as 고객,address as 주거지 from customer_table where address like '%대한민국%'or address like '%영국%';
-- 14 고객이 주문한 도서의 총 판매액
select sum(saleprice) from orders_table;
-- 15 2번 김연아 고객이 주문한 도서의 총 판매액 조회
select sum(saleprice) from orders_table where custid =2;
-- 16 고객이 주문한 도서의 총 판매액,평균값,최저가,최고가 조회
select sum(saleprice)as 총판매액,avg(saleprice)as 평균값,min(saleprice)as 최저가,max(saleprice) as 최고가 from orders_table;
-- 17 마당 서점의 도서 판매 건수 조회
select count(*) from orders_table;
-- 18 고객별로 주문한 도서의 총 수량과 총 판매액 조회
select custid as 고객아이디,count(*) as 총수량,sum(saleprice) as 총판매액 from orders_table group by custid; 
-- 19 가격이 8000이상인 도서 구매 고객에 대하여 고객별 주문 도서 총 수량 구하기 2권이상 구매한 고객만 조회
select custid as 고객아이디,count(*) as 총수량 from orders_table where saleprice >=8000 group by custid having count(*)>=2;
-- 20 날짜별 총 구매건수와 총 판매액을 조회
select orderdate as 주문일자,count(*),sum(saleprice) from orders_table group by orderdate;
-- 21 총 판매액이 20000이 넘는 날짜의 총 구매 건수 조회
select orderdate as 주문일자,count(*) as주문건수 from orders_table group by orderdate having sum(saleprice)>20000;
-- 22 가장 구매건수가 많은 날짜를 조회 구매건수가 같은 경우 가장 최근 날짜를 조회.
select orderdate as 주문일자,count(*) as 주문건수 from orders_table group by orderdate order by 주문건수 desc,orderdate desc limit 1;


use cookdb;
select groupname,userid,sum(price*amount) as 비용 from buytbl group by groupname,userid with rollup;

create table test01(id int auto_increment primary key,username char(3) unique,age int);
insert into test01 values(null,null,10);
insert into test01 values(null,null,20);
insert into test01 values(null,'aa',30);
insert into test01 values(null,'bb',40);
insert into test01 values(null,'cc',50);
-- auto_increment는 insert into가 실행되면 오류가 났든 안났든 증가시킴.
select * from test01;

alter table test01 auto_increment=300;
insert into test01 values(null,'kk',33);
insert into test01 values(null,'gg',36);
select * from test01;
set @@auto_increment_increment=1;
show variables like '%auto_increment_increment%';

update test01 set username='aaa' where username ='aa';
update test01 set age=age+10 where username='aaa';
-- 이름이 없는 유저들을 나이 99로 변경
-- is ~ 이면 이라는 의미로 쓰임 is / = not is / !=
update test01 set age=99 where username is null;

-- 다른테이블에 있는 데이터 가져오기
create table imported_book(
bookid int,bookname varchar(20),publisher varchar(20),price int);

insert into imported_book values(21,'Zen Golf','Pearson',12000);
insert into imported_book values(22,'Soccer Skills','Human Kinetics',15000);
use cookdb;
select * from imported_book;

use madang;
-- 피겨교본에 있느 굿스포츠 출판사를 21번 zen golf의 출판사로 바꾸겠다.
select * from book_table;
update book_table set publisher =(select publisher from cookdb.imported_book where bookname='Zen Golf') where bookname='야구의 추억';
select publisher from imported_book where bookname='Zen Golf';

-- 테이블 삭제
use employees;
create table test01(select* from employees);
create table test02(select* from employees);
create table test03(select* from employees);
-- 삭제하는동안의 duration 시간 차이 비교.
delete from test01;
drop table test02;
truncate table test03;

use cookdb;
-- alter
create table membertbl (select userid,username,addr from usertbl limit 3);
-- userid를 primary key로 설정하겠다.
alter table membertbl add primary key(userid);
-- primary key는 한개이니 (이름)하지 않고 그냥 drop
alter table membertbl drop primary key;
-- foreign key 넣는법
create table buytbl2(select * from buytbl limit 3);
alter table buytbl2 add primary key(num);
alter table buytbl2 add constraint fk_user_id foreign key(userid) references usertbl(userid) on update cascade on delete cascade;
-- foreign key 삭제/ foreign key 삭제시 인덱스도 같이 삭제해줘야한다.
alter table buytbl2 drop foreign key fk_user_id;
alter table buytbl2 drop index fk_user_id;

use madang;
-- 필드추가
alter table book_table add column isbn varchar(10);
alter table book_table drop column isbn;
-- 데이터 타입이 변함 modify default로 숫자를 변경하는 경우는 이미 생성된 레코드는 변경안되고 생성할 레코드의 값은 변함.
alter table book_table modify column isbn int default 10;
desc book_table;
insert into book_table(bookname,publisher,price) values('C언어','한빛미디어',25000);
select * from book_table;

use cookdb;
select * from membertbl;
-- 중복은 제외하고 나머지를 처리하도록 하는 ignore
insert ignore into membertbl values('KHD','강후덜','미국');
insert ignore into membertbl values('LSM','이상민','서울');
insert ignore into membertbl values('KSJ','김성주','경기');

-- 중복일때 새로 넣는걸로 변경하고 싶다면
-- ignore 보다 on duplicate key가 더 실용성 있다. primary key의 중복이 일어났을때 새로운 내용을 원래 내용으로 업데이트 한다.
insert into membertbl values('KHD','강후덜','미국') on duplicate key update username='강후덜',addr='미국';


