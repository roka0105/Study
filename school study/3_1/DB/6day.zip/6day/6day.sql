use employees;
-- 현재 Development부서에서 근무하는 직원의 이름과 생년월일을 조회
-- 내 오답
select e.first_name,e.last_name,e.birth_date from employees as e
where e.emp_no in (select de.emp_no from dept_emp as de outer left join departments as d on de.dept_no = d.dept_no where de.dept_name="Development");
-- 풀이
select concat(e.first_name,e.last_name),e.birth_date from employees as e
join dept_emp as dpte
on e.emp_no=dpte.emp_no
join departments as dpt
on dpt.dept_no=dpte.dept_no
where dpte.to_date='9999-01-01' and dept_name="Development";

-- name이 Christ Muchinsky인 직원의 현재 소속 부서명과 현재 연봉
select concat(e.first_name,e.last_name)as employeesname,dpt.dept_name,s.salary from employees as e  join salaries as s on e.emp_no=s.emp_no 
join dept_emp as dpte on e.emp_no=dpte.emp_no
join departments as dpt
on dpt.dept_no=dpte.dept_no
where e.first_name="Christ"and e.last_name = "Muchinsky" and dpte.to_date = '9999-01-01' and s.to_date='9999-01-01';
-- concat 사용시 where에서도 사용 가능하지만 띄어쓰기 없이 비교해야한다 만약 띄어쓰기를 넣고싶으면 concat할때 띄어쓰기도 넣어야함.
select concat(e.first_name,e.last_name)as employeesname,dpt.dept_name,s.salary from employees as e  join salaries as s on e.emp_no=s.emp_no 
join dept_emp as dpte on e.emp_no=dpte.emp_no
join departments as dpt
on dpt.dept_no=dpte.dept_no
where concat(e.first_name,e.last_name)="ChristMuchinsky"and dpte.to_date = '9999-01-01' and s.to_date='9999-01-01';

-- 현재 title이 senior Engineer 로 일하고 있는 직원의 이름과 연봉
select concat(e.first_name,e.last_name) as 직원이름,s.salary as 연봉 from employees as e join titles as t on e.emp_no=t.emp_no
join salaries as s on e.emp_no=s.emp_no where t.title ='Senior Engineer' and s.to_date='9999-01-01' and t.to_date = '9999-01-01';

-- 각 부서별 매니저들의 현재 연봉
select dpt.dept_name as 부서이름,concat(e.first_name,e.last_name) as 직원이름,s.salary as 연봉 from employees as e 
join dept_manager as dptm on e.emp_no=dptm.emp_no
join departments as dpt on dptm.dept_no=dpt.dept_no
join salaries as s on s.emp_no=e.emp_no
where s.to_date='9999-01-01' and dptm.to_date='9999-01-01';

-- 부서별로 매니저가 바뀐 횟수를 조회 (부서명,역대 매니저 수)
-- 방법 1)
select dpt.dept_name as 부서명 ,count(*) as 역대매니저수 from dept_manager as dptm 
join departments as dpt on dptm.dept_no=dpt.dept_no
group by dpt.dept_name;

-- 방법2)
select dpt.dept_name as 부서명 ,dptm.매니저수 from departments as dpt
join (select dept_no,count(*)as 매니저수 from dept_manager group by dept_no) as dptm on dpt.dept_no=dptm.dept_no;

-- 방법3) 자주 쓸 데이터면 테이블로 만들어놓고 사용해도 된다. 대용량의 데이터에서 추출한 데이터,집계한 데이터를 테이블로 만들어놓고 그 테이블을 활용해서 검색쿼리를 구현
create table cnttbl(select dept_no,count(*)as 매니저수 from dept_manager group by dept_no);
select dpt.dept_name as 부서명 ,dptm.매니저수 from departments as dpt
join cnttbl as dptm on dpt.dept_no=dptm.dept_no;

-- 각 부서별 최고 연봉을 받는 직원들의 이름과 연봉
select dpt.emp_no,dpt.dept_no,s.salary from dept_emp as dpt
join salaries as s on dpt.emp_no=s.emp_no where s.to_date ='9999-01-01' and dpt.to_date='9999-01-01';

drop table if exists employee_salary; 
create table employee_salary(select dpt.emp_no,dpt.dept_no,s.salary from dept_emp as dpt
join salaries as s on dpt.emp_no=s.emp_no where s.to_date ='9999-01-01' and dpt.to_date='9999-01-01');

select concat(e.first_name,e.last_name)as 직원이름,dpt.dept_name as 부서명, es.부서별최대연봉 as 연봉 from employees as e 
join (select emp_no,dept_no,max(salary) as 부서별최대연봉 from employee_salary group by dept_no) as es 
on e.emp_no = es.emp_no 
join departments as dpt on dpt.dept_no=es.dept_no;
-- 오답노트  자꾸 실수하는 부분 group by로 데이터를 뺄때  기준이 되는 데이터 이외의 데이터 ex emp_no 를 하면 첨에 들어간 값이 나오며 값이 달라지는 실수를 함.
select dept_no,emp_no,salary from employee_salary where (dept_no,salary) in( select dept_no,max(salary) as 부서별최대연봉 from employee_salary group by dept_no);
-- 교수님 풀이
select dept_no,max(salary) from employee_salary group by dept_no;
select dept_no,emp_no,salary from employee_salary where (dept_no,salary) in (select dept_no,max(salary) from employee_salary group by dept_no);
create table emp_max_salary(select dept_no,emp_no,salary from employee_salary where (dept_no,salary) in (select dept_no,max(salary) from employee_salary group by dept_no));

select concat(e.first_name,e.last_name)as 직원이름,dpt.dept_name as 부서명,ems.salary
from employees as e
join emp_max_salary as ems
on e.emp_no=ems.emp_no
join departments dpt
on dpt.dept_no=ems.dept_no;

-- add constraint 제약조건 추가 2개를 묶어서 add constraint를 할 수 있다 이경우는 둘이 묶였을때 유일하면 된다. 
-- aa 01 aa 02 bb 01 bb 02 이렇게 있다면 개별적으로 겹치더라도 같이 묶어서 봤을때는 독립적이기 때문에 성립함.
-- 이름 지어줄때는 constraint 붙여줄수 있다.
-- 테이블을 만든 다음에 외래키를 넣는 경우 add constraint 이름 추가해주고 foreign ket ~ references ~ 

-- 필드의 구조나 자료형 틀을 고치려고 하면 alter or modify 사용.

--  describe 테이블 구조 보는 키워드
use cookdb;
describe buytbl;
-- auto increment 삭제하고나서 삭제해야됨 그냥하면 삭제 안됨.
alter table buytbl drop primary key;
-- modify 는 수정하는 기능인데 필드 이름은 못바꿈.
alter table buytbl modify num int default 0;

-- 테이블의 만들어진 형태를 보겠다는 명령어.
show create table buytbl;
-- index와 foreign key는 함께 지워줘야 한다.
alter table  buytbl drop foreign key fk_userid;
alter table buytbl drop index fk_userid; 

alter table buytbl add primary key(num);
alter table buytbl add constraint fk_userid 
foreign key(userid) references usertbl(userid)
on update cascade on delete cascade;

-- 필드 이름을 바꾸고 싶을때
alter table buytbl change num cnt int default -1;

-- ppt 9 의 12 슬라이드같은 경우
-- foreign key로 연결된 두 테이블 사이에 없는 데이터를 집어넣어야 하는 상황이 있을때 권장하지 않지만 밑의 코드를 사용해서
-- foreign_key_checks=0 으로 바꿔주어서 foreign_key 검사를 안하게 한 다음에 넣고나서 다시 1로 값을 변경해줘야 한다.
set foreign_key_checks=0;
set foreign_key_checks=1;

CREATE TABLE userTBL2
( userID CHAR(8) NOT NULL PRIMARY KEY, 
  userName VARCHAR(10) NOT NULL, 
  birthYear INT NOT NULL, 
  email CHAR(30) NULL, 
  CONSTRAINT AK_email UNIQUE (email) 
);

-- 유니크 제약조건 삭제할때 필드삭제가 아닌 제약조건 삭제임 유니크는 삭제시 index도 같이 삭제되는데 index가 같이 삭제되지 않는 경우는 foreign key 밖에 없음.
alter table usertbl2 drop CONSTRAINT AK_email;
-- modify로는 되는가? 제약조건은 삭제가 안된다. 따라서 제약조건을 삭제하려고 하면 modify 사용은 적절치 않음
alter table usertbl2 modify email char(30);

CREATE TABLE userTBL3 
( userID CHAR(8) NOT NULL PRIMARY KEY, 
userName VARCHAR(10) NOT NULL, 
birthYear int NOT NULL  default -1 , 
addr CHAR(2) NOT NULL default '서울', 
mobile1 CHAR(3) NULL, 
mobile2 CHAR(8) NULL, 
height smallint NULL default 170, 
mDate date NULL,
constraint ck_birthyear check(birthyear >=1900 and birthyear <= 2022)
);
-- 그냥 하면 안된다 왜냐하면 제약조건이 1900 이상 2022 이하인데 default 값이 -1 이기 때문.
INSERT INTO userTBL3 VALUES ('YBJ', '유병재', default, default, '010', '12345678', default, '2019.12.12');
-- default 값 수정
alter table usertbl3 modify birthyear int default 1900;
-- addr의 제약조건을 추가한다. 
alter table usertbl3 add constraint ck_addr 
check(addr in ('서울','경기','경북','경남','충북'));
-- 안들어가는 이유는 위에 addr 제약조건을 걸어놨기 때문.
INSERT INTO userTBL3 VALUES ('WB', '원빈', 1982, '대전', '010', '98765432', 176, '2020.5.5');
-- 제약조건 삭제
alter table usertbl3 drop constraint ck_addr;

-- check 조건 줄때 () 안이 참이면 되는것이다. 조건과 맞는지 체크하는거임. 내장함수를 사용하는건 안됨.
-- ex) constraint ck_birthyear check(birthyear >=1900 and birthyear <= year(curyear())) 이런식 
-- 근데 아직 내장함수 안배움. 아무튼 ()에 조건은 고정된 값을 사용해야함 변경될수 있는 값(함수같이) 사용하면 안됨.

-- ROW_FORMAT=COMPRESSED 압축테이블 됨.
-- nomaltbl과 compresstbl의 duration 시간 차이가 나는 이유는 압축해서 저장하는 용도이기 때문이다.
-- 백업용 데이터를 보통 이렇게 사용한다 저장장치 절약을 위해. 근데 검색을 자주 하는 테이블에는 그렇게 하면 안된다.
CREATE DATABASE IF NOT EXISTS compressDB;
USE compressDB;
CREATE TABLE normalTBL (emp_no INT, first_name VARCHAR(14));
CREATE TABLE compressTBL (emp_no INT, first_name VARCHAR(14)) 
      ROW_FORMAT=COMPRESSED;
      
INSERT INTO normalTbl 
      SELECT emp_no, first_name FROM employees.employees;
INSERT INTO compressTBL 
      SELECT emp_no, first_name FROM employees.employees;
      
SHOW TABLE STATUS FROM compressDB;

use employees;
-- 워크벤티에서 같은 아이디로 또 들어가면 두 섹션이 만들어지는데 이것은 두 클라이언트가 실행된것과 같음(콘솔창 열듯이).
-- 임시 테이블 생성하고나서 테이블 출력하면 원래 테이블은 지워지고 임시 테이블을 출력함. 근데 나갔다 오면 원래 테이블 보여줌
-- 그리고 다른 클라이언트에서 호출시에는 임시테이블이 아닌 원래 테이블이 출력.
create temporary table employees (select * from employees limit 10);
select * from employees;


      
