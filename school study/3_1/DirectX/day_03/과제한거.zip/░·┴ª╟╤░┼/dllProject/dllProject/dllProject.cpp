#include "dllProject.h"

extern "C" DLLPROJECT_API int Multi(int data1,int data2)
{
	return data1 * data2;
}