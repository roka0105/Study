﻿// libProject.cpp : 정적 라이브러리를 위한 함수를 정의합니다.
//

#include "framework.h"
#include "libProject.h"
int Sum(int data1, int data2)
{
	return data1 + data2;
}