#pragma once

int Sum(int data1, int data2);