#pragma comment(lib, "ws2_32")
#include <winsock2.h>
#include <stdlib.h>
#include <stdio.h>

#define SERVERPORT 9000
#define BUFSIZE    512

#define LOGIN_SUCCESS "�α��ο� �����߽��ϴ�.\n"
#define LOGIN_FAIL "�α��ο� �����߽��ϴ�. \n"

enum
{
	NODATA=-1,
	LOGIN = 1,
	FAIL = 2
};

struct _UserInfo
{
	char id[10];
	char pw[10];
}UserInfo[3] = { {"aaa","111"}, {"bbb","111"}, {"ccc","111"}};
// ���� �Լ� ���� ��� �� ����
void err_quit(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

// ���� �Լ� ���� ���
void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

int main(int argc, char *argv[])
{
	int retval;

	// ���� �ʱ�ȭ
	WSADATA wsa;
	if(WSAStartup(MAKEWORD(2,2), &wsa) != 0)
		return 1;

	// socket()
	SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
	if(sock == INVALID_SOCKET) err_quit("socket()");

	// bind()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if(retval == SOCKET_ERROR) err_quit("bind()");

	// ������ ��ſ� ����� ����
	SOCKADDR_IN clientaddr;
	int addrlen;
	char buf[BUFSIZE+1];

	// Ŭ���̾�Ʈ�� ������ ���
	while(1)
	{
		// ������ �ޱ�
		_UserInfo userinfo;
		addrlen = sizeof(clientaddr);
		retval = recvfrom(sock, (char*)&userinfo, sizeof(_UserInfo), 0,
			(SOCKADDR *)&clientaddr, &addrlen);
		if(retval == SOCKET_ERROR){
			err_display("recvfrom()");
			continue;
		}

		// ���� ������ ���
		buf[retval] = '\0';
		printf("[UDP/%s:%d] id:%s  pw:%s\n", inet_ntoa(clientaddr.sin_addr),
			ntohs(clientaddr.sin_port), userinfo.id, userinfo.pw);

		int result = NODATA;
		char msg[BUFSIZE];

		for (int i = 0; i < 3; i++)
		{
			if (strcmp(userinfo.id, UserInfo[i].id) == 0 && strcmp(userinfo.pw, UserInfo[i].pw) == 0)
			{
				result = LOGIN;
				strcpy(msg, LOGIN_SUCCESS);
				break;
			}
		}

		if (result == NODATA)
		{
			result = FAIL;
			strcpy(msg, LOGIN_FAIL);
		}

		memset(buf, 0, sizeof(buf));
		memcpy(buf, &result, sizeof(int));
		memcpy(buf + sizeof(int), msg, strlen(msg));
		// ������ ������
		retval = sendto(sock, buf, sizeof(int)+strlen(msg), 0,
			(SOCKADDR *)&clientaddr, sizeof(clientaddr));
		if(retval == SOCKET_ERROR){
			err_display("sendto()");
			continue;
		}
	}

	// closesocket()
	closesocket(sock);

	// ���� ����
	WSACleanup();
	return 0;
}