/*
 * BroadSender_win.c
 * Written by SW. YOON
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>

#define BUFSIZE 100
#define TRUE 1
#define FALSE 0
#define NUM_MEMBER 4

void ErrorHandling(char *message);

int main(int argc, char **argv)
{
  WSADATA wsaData;
  SOCKET hSendSock;
  SOCKADDR_IN broadAddr;
  SOCKADDR_IN ClntAddr;
  int state;
  char buf[BUFSIZE]="���� �� �ְ��� Ÿ�ڸ� �����Ͽ� �ּ���. \n 1.�ڿ���\n 2.����ȯ\n 3.������\n 4.ä����\n 5.������";
  

  if(argc!=3){
    printf("Usage : %s <Boradcast IP> <port>\n", argv[0]);
    exit(1);
  }

  if(WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) /* Load Winsock 2.2 DLL */
	  ErrorHandling("WSAStartup() error!"); 
  
  hSendSock=socket(PF_INET, SOCK_DGRAM, 0); /*��ε�ĳ��Ʈ�� ���� UDP���� ���� */
  if(hSendSock == INVALID_SOCKET)
    ErrorHandling("socket() error");
 
  memset(&broadAddr, 0, sizeof(broadAddr));
  broadAddr.sin_family=AF_INET;
  broadAddr.sin_addr.s_addr=htonl(INADDR_BROADCAST);
  broadAddr.sin_port=htons(atoi(argv[2]));
  
  int so_broadcast = TRUE;
  state=setsockopt(hSendSock, SOL_SOCKET, SO_BROADCAST, (char*)&so_broadcast, sizeof(so_broadcast));
  if(state==SOCKET_ERROR)
    ErrorHandling("setsockopt() error");
  
  int retval=sendto(hSendSock, buf, strlen(buf), 0, (SOCKADDR*)&broadAddr, sizeof(broadAddr));
  if(retval==SOCKET_ERROR)ErrorHandling("sendto() error");
  
  int Count=0;
  int Val, Val1 = 0, Val2 = 0, Val3 = 0, Val4 = 0, Val5 = 0, Err = 0, Total;
  int AddrSize;
  while(Count<NUM_MEMBER)
  {
	 	  AddrSize=sizeof(broadAddr);
	      recvfrom(hSendSock, (char*)&Val, sizeof(Val),0,(SOCKADDR*)&broadAddr, &AddrSize);
		  switch(Val)
		  {
		  case 1: 
			  Val1++; 
			  break;
		  case 2: 
			  Val2++; 
			  break;
		  case 3: 
			  Val3++; 
			  break;
		  case 4: 
			  Val4++; 
			  break;
		  case 5:	
			  Val5++; 
			  break;

		  default:
			  Err++;
		  }
	 Count++;
  }

  Total=Val1+Val2+Val3+Val4+Val5+Err;
  printf("1.�ڿ��� : %d , %4.2lf \% \n", Val1, (double)Val1/Total*100);
  printf("2.����ȯ : %d , %4.2lf \% \n", Val2, (double)Val2/Total*100);
  printf("3.������ : %d , %4.2lf \% \n", Val3, (double)Val3/Total*100);
  printf("4.ä���� : %d , %4.2lf  \% \n", Val4, (double)Val4/Total*100);
  printf("5.������ : %d , %4.2lf  \% \n", Val5, (double)Val5 / Total * 100);
  
  closesocket(hSendSock);
  /*closesocket(RecvSock);*/
  WSACleanup();
  return 0;
}

void ErrorHandling(char *message)
{
  fputs(message, stderr);
  fputc('\n', stderr);
  exit(1);
}


