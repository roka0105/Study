/*
 * BroadReceiver_win.c
 * Written by SW. YOON
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>

#define BUFSIZE 100
void ErrorHandling(char *message);

int main(int argc, char **argv)
{
  WSADATA wsaData;
  SOCKET hRecvSock;
  SOCKADDR_IN addr,RecvAddr;
  int strLen, option;
  char buf[BUFSIZE];

  if(argc!=2){
    printf("Usage : %s  <port>\n", argv[0]);
    exit(1);
  }

  if(WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) /* Load Winsock 2.2 DLL */
	  ErrorHandling("WSAStartup() error!"); 
  
  hRecvSock=socket(PF_INET, SOCK_DGRAM, 0); /*��ε�ĳ��Ʈ�� ���� UDP���� ���� */
  if(hRecvSock == INVALID_SOCKET)
	  ErrorHandling("socket() error");

  memset(&addr, 0, sizeof(addr));
  addr.sin_family=AF_INET;
  addr.sin_addr.s_addr=htonl(INADDR_ANY);	
  addr.sin_port=htons(atoi(argv[1]));	   /* ��ε�ĳ��Ʈ port ���� */

  option=1;
  setsockopt(hRecvSock,SOL_SOCKET, SO_REUSEADDR, (char*)&option, sizeof(option));
 
  if(bind(hRecvSock, (SOCKADDR*) &addr, sizeof(addr))==SOCKET_ERROR)
	  ErrorHandling("bind() error");

   memset(&RecvAddr, 0, sizeof(RecvAddr));
   int RecvAddrSize=sizeof(RecvAddr);
   strLen=recvfrom(hRecvSock, buf, BUFSIZE-1,0, (SOCKADDR*)&RecvAddr, &RecvAddrSize);
   if(strLen==SOCKET_ERROR) ErrorHandling("recvfrom error");  
   buf[strLen]=0;
   puts(buf);
   printf("����:");
   int Val;
   scanf("%d", &Val);
   strLen=sendto(hRecvSock, (char*)&Val, sizeof(Val), 0,(SOCKADDR*)&RecvAddr, sizeof(RecvAddr));
   if(strLen==SOCKET_ERROR) ErrorHandling("sendto error");
  closesocket(hRecvSock);
  WSACleanup();
  return 0;
}

void ErrorHandling(char *message)
{
  fputs(message, stderr);
  fputc('\n', stderr);
  exit(1);
}

