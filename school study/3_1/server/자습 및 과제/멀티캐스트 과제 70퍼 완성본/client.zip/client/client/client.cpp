#pragma comment (lib,"ws2_32")
#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#define BUFSIZE 512
#define SERVERIP "127.0.0.1"
#define PORT 9000

ip_mreq mreq;

enum class PROTOCOL
{
	NONE = 0,
	MENU,
	ADDRESS,
	INCHATTING,
	MAX,
};
struct Packet
{
	Packet() 
	{ 
		ZeroMemory(buf, BUFSIZE);
		ZeroMemory(username, BUFSIZE);
	}
	PROTOCOL protocol;
	char username[BUFSIZE];
	char buf[BUFSIZE];
	int number;
};
void err_quit(char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
		GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, (LPCWSTR)msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}
void err_display(char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
		GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char*)lpMsgBuf);
	LocalFree(lpMsgBuf);
}
DWORD WINAPI RecvThread(LPVOID lpParam)
{
	SOCKET sock = (SOCKET)lpParam;
	SOCKADDR_IN multipeeraddr;
	ZeroMemory(&multipeeraddr, sizeof(multipeeraddr));
	int peerlen = 0;
	char buf[BUFSIZE];
	int retval= 0;
	Packet packet;
	while (1)
	{	
		ZeroMemory(buf, BUFSIZE);
		retval = recvfrom(sock, (char*)&packet,sizeof(packet), 0,(SOCKADDR*)&multipeeraddr, &peerlen);
		if (retval == SOCKET_ERROR)
			err_display((char*)"recvfrom()");
		printf("%s\n", buf);
	}
	return 0;
}
int main(int argv, char* argc[])
{
	int retval = 0;
	WSADATA ws;
	if (WSAStartup(MAKEWORD(2, 2), &ws) != 0)
		return 1;
	SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock == INVALID_SOCKET)
		err_quit((char*)"socket()");
	
	SOCKADDR_IN localaddr;
	ZeroMemory(&localaddr, sizeof(localaddr));
	localaddr.sin_family = AF_INET;
	localaddr.sin_addr.s_addr = inet_addr(SERVERIP);
	localaddr.sin_port = htons(PORT);
	
	BOOL bEnable = TRUE;
	retval = setsockopt(sock, SOL_SOCKET, SO_REUSEADDR,
		(char*)&bEnable
		, sizeof(bEnable));
	
	SOCKADDR_IN peeraddr;
	ZeroMemory(&peeraddr, sizeof(peeraddr));
	int peerlen = sizeof(peeraddr);
	char buf[BUFSIZE];
	ZeroMemory(buf, BUFSIZE);
	
	
	Packet packet;
	packet.protocol = PROTOCOL::MENU;
	int room_number = 0;
	while (1)
	{
		retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&localaddr, sizeof(localaddr));
		if (retval == SOCKET_ERROR)
			err_display((char*)"sendto()");
		//recvfrom()
		retval = recvfrom(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, &peerlen);
		if (retval == SOCKET_ERROR)
			err_display((char*)"recvfrom");
		if (sizeof(peeraddr) != peerlen)
		{
			printf("�߸��� ����\n");
		}
		//closesocket()
		while (1)
		{
			printf("%s\n", packet.buf);
			ZeroMemory(packet.buf, BUFSIZE);
			scanf("%d", &packet.number);
			if (packet.number > 3 || packet.number <= 0)
				printf("�ٽ��Է��ϼ���!\n");
			else 
			{
				printf("�����̸��Է�:");
				scanf("%s", packet.username);
				break;
			}
		}
		packet.protocol = PROTOCOL::ADDRESS;
		//�ּ� ��û
		retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&localaddr, sizeof(localaddr));
		if (retval == SOCKET_ERROR)
			err_display((char*)"sendto()");
		//�ּ� �޾ƿ�
		retval = recvfrom(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, &peerlen);
		if (retval == SOCKET_ERROR)
			err_display((char*)"recvfrom()");
		//��Ƽĳ��Ʈ ������
		
		//�������ּ�
		mreq.imr_multiaddr.s_addr = inet_addr(packet.buf);
		//���ּ�
		mreq.imr_interface.s_addr=inet_addr(SERVERIP);
		retval = setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&mreq, sizeof(mreq));
		if (retval == SOCKET_ERROR)err_quit((char*)"setsockopt()");
		
		SOCKADDR_IN multiaddr;
		ZeroMemory(&multiaddr, sizeof(multiaddr));
		multiaddr.sin_family = AF_INET;
		multiaddr.sin_addr.s_addr = inet_addr(packet.buf);
		multiaddr.sin_port = htons(PORT);

		//��Ƽ������ �����
		HANDLE hThread = CreateThread(NULL, 0, RecvThread, (LPVOID)sock, 0, NULL);

		packet.protocol = PROTOCOL::INCHATTING;
		
		while(1)
		{
			ZeroMemory(packet.buf, BUFSIZE);
			printf("�Է�:");
			scanf("%s", packet.buf);
			retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, sizeof(peeraddr));
			if (retval == SOCKET_ERROR)
				err_display((char*)"sendtooo()");
		}

		retval = setsockopt(sock, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*)&mreq, sizeof(mreq));
		if (retval == SOCKET_ERROR)err_quit((char*)"setsockopt()");
	}

	closesocket(sock);
	WSACleanup();
	return 0;
}
