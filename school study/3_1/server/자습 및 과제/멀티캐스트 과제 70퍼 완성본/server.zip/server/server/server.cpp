#pragma comment (lib,"ws2_32")
#include <WinSock2.h>
#include <stdio.h>
#include <stdlib.h>

#define BUFSIZE 512
#define SERVERIP "127.0.0.1"
#define PORT 9000

enum class PROTOCOL
{
	NONE=0,
	MENU,
	ADDRESS,
	INCHATTING,
	MAX,
};
struct Packet
{
	Packet() 
	{ 
		ZeroMemory(buf, BUFSIZE);
		ZeroMemory(username, BUFSIZE);
	}
	PROTOCOL protocol;
	char username[BUFSIZE];
	char buf[BUFSIZE];
	int number;
};
struct Address
{
	Address(const char* addr)
	{
		ZeroMemory(buf, BUFSIZE);
		strcpy(buf, addr);
	}
	char buf[BUFSIZE];
};
void err_quit(char* msg)
{
	 LPVOID lpMsgBuf;
	 FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
		 GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	 MessageBox(NULL, (LPCTSTR)lpMsgBuf, (LPCWSTR)msg, MB_ICONERROR);
	 LocalFree(lpMsgBuf);
	 exit(1);	
}
void err_display(char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
		GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char*)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

int main(int argv,char* argc[])
{
	int retval = 0;
	Address addr[3] = { ("224.0.0.0"),("224.0.0.1"),("224.0.0.2") };
	WSADATA ws;
	if (WSAStartup(MAKEWORD(2, 2), &ws) != 0)
		return 1;
	//socket
	SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock == INVALID_SOCKET)
		err_quit((char*)"socket()");
	SOCKADDR_IN localaddr;
	ZeroMemory(&localaddr, sizeof(localaddr));
	localaddr.sin_family = AF_INET;
	localaddr.sin_addr.s_addr= inet_addr(SERVERIP);
	localaddr.sin_port = htons(PORT);

	int locallen=0;
	//bind
	retval = bind(sock, (SOCKADDR*)&localaddr, sizeof(localaddr));
	if (retval == SOCKET_ERROR)
		err_quit((char*)"bind()");

	SOCKADDR_IN peeraddr;
	ZeroMemory(&peeraddr, sizeof(peeraddr));
	int peerlen = sizeof(peeraddr);
	char buf[BUFSIZE];
	ZeroMemory(buf, BUFSIZE);
	Packet packet;
	while (1)
	{
		ZeroMemory(&packet, sizeof(packet));
		//�޴���û�޾ƿ���
		retval = recvfrom(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, &peerlen);
		if (retval == SOCKET_ERROR)
			err_display((char*)"recvfrom");
		//buf�� �޴� ����.
		switch (packet.protocol)
		{
			case PROTOCOL::MENU:
			sprintf(packet.buf, "%s", "1.�ڿ���\n2.����ȯ\n3.������\n�Է�:");
			//sendto()
			retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, sizeof(peeraddr));
			if (retval == SOCKET_ERROR)
				err_display((char*)"sendto()");
			printf("[UDP] %d ����Ʈ ���½��ϴ�.\n", retval);
			break;

			case PROTOCOL::ADDRESS:
				switch (packet.number)
				{
				case 1:
					printf("�ڿ��ù� %s�� ����\n",packet.username);
					strcpy(packet.buf, addr[0].buf);
					break;
				case 2:
					printf("����ȯ�� %s�� ����\n", packet.username);
					strcpy(packet.buf, addr[1].buf);
					break;
				case 3:
					printf("�������� %s�� ����\n", packet.username);
					strcpy(packet.buf, addr[2].buf);
					break;
				}
				retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, sizeof(peeraddr));
				if (retval == SOCKET_ERROR)
				{
					err_display((char*)"sendto()");
			    }
				break;
			case PROTOCOL::INCHATTING:
				retval = sendto(sock, (char*)&packet, sizeof(packet), 0, (SOCKADDR*)&peeraddr, sizeof(peeraddr));
				if (retval == SOCKET_ERROR)
				{
					err_display((char*)"sendto()");
				}
				printf("[%s] : %s", packet.username, packet.buf);

				break;
		}
	}
	
	//recvfrom()
	//closesocket()
	closesocket(sock);
	WSACleanup();
	return 0;
}