//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// server.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDOUTROOM                       3
#define IDEND                           4
#define IDNEXTROOM                      5
#define IDD_DIALOG1                     101
#define IDC_EDIT                        1001
#define IDC_EDIT2                       1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
