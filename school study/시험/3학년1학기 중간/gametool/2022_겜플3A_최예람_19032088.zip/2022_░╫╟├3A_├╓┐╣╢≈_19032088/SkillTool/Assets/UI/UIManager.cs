using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum UIType
{
	None,
	Skill_Setting_UI,
	Skill_Manager_UI,
	Max
}
public class UIManager : Singleton_Ver1.Singleton<UIManager>
{
	KeyInputManager M_keyInput;
	MouseInputManager M_mouseInput;
	Dictionary<UIType, GameObject> UIObjList = new Dictionary<UIType, GameObject>();
	Dictionary<UIType, bool> UIObjActiveList = new Dictionary<UIType, bool>();
	List<UIType> ActiveTrueUI = new List<UIType>();
	[SerializeField]
	SkillManagerUI SkillM_UI;
	public void Enable_SkillSetUI(UIType calltype)
	{
		if (UIObjList.ContainsKey(calltype))
		{
			bool check = UIObjActiveList[calltype] = !UIObjActiveList[calltype];
			if (check)
			{
				ActiveTrueUI.Add(calltype);
			}
			else
			{
				ActiveTrueUI.Remove(calltype);
			}
			UIObjList[calltype].SetActive(UIObjActiveList[calltype]);
		}
	}
	public void Close_SkillSetUI(UIType calltype)
	{
		if (ActiveTrueUI.Count != 0)
		{
			UIType nowUI = ActiveTrueUI[ActiveTrueUI.Count - 1];
			ActiveTrueUI.Remove(nowUI);

			if (UIObjList.ContainsKey(nowUI))
			{
				UIObjActiveList[nowUI] = false;
				UIObjList[nowUI].SetActive(UIObjActiveList[nowUI]);
			}
		}
	}
	public void SaveSkill(UIType calltype)
	{

	}
	public void MoveUI(UIType calltype)
	{
		if (UIObjList.ContainsKey(calltype))
		{
			Vector2 pos = M_mouseInput.MousePos;
			//pos.x -= 500;
		    pos.y += 40;
			UIObjList[calltype].transform.position = pos;
		}
	}

	public void ChangeNextDropDownInfo(E_DropDownLevelType droplevel, int itemindex)
    {
		SkillM_UI.ChangeNextDropDownInfo(droplevel, itemindex);
    }
	void Start()
	{
		GameObject item = GameObject.Find("Skill_Setting_UI");
		UIObjList.Add(UIType.Skill_Setting_UI, item);
		UIObjActiveList.Add(UIType.Skill_Setting_UI, false);
		UIObjList[UIType.Skill_Setting_UI].SetActive(false);

		item = GameObject.Find("Skill_Manager_UI");
		UIObjList.Add(UIType.Skill_Manager_UI, item);
		UIObjActiveList.Add(UIType.Skill_Manager_UI, false);
		//UIObjList[UIType.Skill_Manager_UI].SetActive(false);

		M_keyInput = GameObject.Find("KeyManager").GetComponent<KeyInputManager>();
		M_keyInput.SetKey(KeyCode.K, Enable_SkillSetUI, UIType.Skill_Setting_UI);
		M_keyInput.SetKey(KeyCode.Escape, Close_SkillSetUI, UIType.None);

		M_mouseInput = GameObject.Find("MouseManager").GetComponent<MouseInputManager>();
		M_mouseInput.SetBtn(E_BTNType.ManagerMode, Enable_SkillSetUI, UIType.Skill_Manager_UI);
		//M_mouseInput.SetBtn(E_BTNType.SaveSkill, SaveSkill, UIType.None);
		M_mouseInput.SetBtn(E_BTNType.SettingExit, Close_SkillSetUI, UIType.Skill_Setting_UI);
		M_mouseInput.SetBtn(E_BTNType.SkillManagerExit, Close_SkillSetUI, UIType.Skill_Manager_UI);
		M_mouseInput.SetBtn(E_BTNType.Bar, MoveUI, UIType.Skill_Manager_UI);

	}

	// Update is called once per frame
	void Update()
	{
		M_keyInput.KeyDownCheck();
		M_mouseInput.BtnDownCheck();
	}
}
