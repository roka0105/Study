using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;
public class test : MonoBehaviour
{
	//public Image myskill;

	static string SPLITLINE_RE = @";";
	string testStr1 = "hello,my, name , is yeram;hihi;yes";
	void Start()
	{
		//Object[] skillicons = Resources.LoadAll("Skill_Icon/01-01");

		//Sprite[] skillicons = Resources.LoadAll<Sprite>("Skill_Icon/01-01");
		//myskill.sprite = skillicons[0];
		string[] test1 = Regex.Split(testStr1, SPLITLINE_RE);
		int number=test1.Length;
		for(int i=0;i<number;i++)
		Debug.Log(test1[i]);
	}
	void Update()
	{

	}
}
