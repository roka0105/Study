using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct Sheet2ExcelData
{
	public int No;
	public int CodeIndex;
	public int Skill01_Code;
	public int Skill02_Code;
	public int Skill03_Code;
}

[CreateAssetMenu(fileName="Sheet2ExcelLoader",menuName= "ExcelData/Sheet2ExcelLoader")]
public class Sheet2ExcelLoader : ScriptableObject
{
	[SerializeField] string filepath;
	public List<Sheet2ExcelData> DataList;

	private Sheet2ExcelData Read(string line)
	{
		line=line.TrimStart('\n');
		Sheet2ExcelData data= new Sheet2ExcelData();
		string[] strs= line.Split('`');

		int index=0;
		data.No=int.Parse(strs[index++]);
		data.CodeIndex=int.Parse(strs[index++]);
		data.Skill01_Code=int.Parse(strs[index++]);
		data.Skill02_Code=int.Parse(strs[index++]);
		data.Skill03_Code=int.Parse(strs[index++]);
		return data;
	}
	[ContextMenu("파일 읽기")]
	public void ReadAllFile()
	{
		string currentpath = System.IO.Directory.GetCurrentDirectory();
		DataList= new List<Sheet2ExcelData>();
		string alltxt= System.IO.File.ReadAllText(System.IO.Path.Combine(currentpath,filepath));
		string[] strs=alltxt.Split(';');
		foreach(var item in strs)
		{
			if(item.Length<2)
			continue;
			Sheet2ExcelData data = Read(item);
			DataList.Add(data);
		}
	}
}
