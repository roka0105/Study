using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine;
using UnityEngine.UI;
using System;

public class MouseInputManager : MonoBehaviour
{
	GraphicRaycaster m_Raycaster;
	PointerEventData m_PointEData;
	EventSystem m_EventSystem;

	BtnSetting m_btnSetting;
	bool is_clickcheck = false;
	bool is_presscheck = false;
	Vector2 m_currentmouspos;
	public bool IS_ClickCheck
	{
		set { is_clickcheck = value; }
		get { return is_clickcheck; }
	}
	public Vector3 MousePos
	{
		get { return m_currentmouspos; }
	}
	public void SetBtn(E_BTNType btntype, BtnEvent btnevent, UIType uitype)
	{
		if (btntype == null || btnevent == null)
			return;
		m_btnSetting.SetBtn(btntype, btnevent, uitype);
	}
	public void BtnDownCheck()
	{
		E_BTNType btntype = Get_InputBtnType();
		if (btntype == null || btntype == E_BTNType.None)
			return;
		m_btnSetting.CallBtn(btntype);
		if (is_clickcheck) //�������� üũ�ϴ� �Լ� �ʱ�ȭ.
		{
			is_clickcheck = false;
		}
		if(is_presscheck&& Input.GetMouseButtonUp(0))//������������ üũ�ϴ� �Լ� ������ �ʱ�ȭ.
		{
			is_presscheck = false;
			m_currentmouspos = new Vector3(0f,0f,0f) ;
		}
	}
	private E_BTNType Get_InputBtnType()
	{
		if(is_presscheck)
		{
			m_currentmouspos = Input.mousePosition;
			return E_BTNType.Bar;
		}
		if (Input.GetMouseButtonDown(0))
		{
			//Set up the new Pointer Event
			m_PointEData = new PointerEventData(m_EventSystem);
			//Set the Pointer Event Position to that of the mouse position
			m_PointEData.position = Input.mousePosition;
			
			m_currentmouspos = m_PointEData.position;
			//Create a list of Raycast Results
			List<RaycastResult> results = new List<RaycastResult>();

			//Raycast using the Graphics Raycaster and mouse click position
			m_Raycaster.Raycast(m_PointEData, results);

			//For every result returned, output the name of the GameObject on the Canvas hit by the Ray
			foreach (RaycastResult result in results)
			{
				if (result.gameObject.tag == "Btn")
				{
					if (is_clickcheck) return E_BTNType.None;
					is_clickcheck = true;
					int index = result.gameObject.name.LastIndexOf("Btn");
					string name = result.gameObject.name.Substring(0, index);
					E_BTNType btntype;
					if (Enum.TryParse<E_BTNType>(name, out btntype))
					{
						return btntype;
					}


				}
				else if(result.gameObject.tag=="Bar")
				{
					is_presscheck = true;
					return E_BTNType.Bar;
				}
			}
		}
		return E_BTNType.None;
	}
	// Start is called before the first frame update
	void Start()
	{
		m_Raycaster = GameObject.Find("Canvas").GetComponent<GraphicRaycaster>();
		m_EventSystem = GameObject.Find("EventSystem").GetComponent<EventSystem>();
		m_btnSetting = GameObject.Find("BtnSetting").gameObject.GetComponent<BtnSetting>();
		m_currentmouspos = new Vector3(0f, 0f, 0f);
	}

	// Update is called once per frame
	void Update()
	{
		
	}
}
