using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyInputManager : MonoBehaviour
{
	KeySetting keysetting;
	public void SetKey(KeyCode keyname, KeyEvent keyfunc,UIType calltype)
	{
		if (keyname == null || keyfunc == null)
			return;
		keysetting.SetKey(keyname, keyfunc,calltype);
	}
	public void KeyDownCheck()
	{
		KeyCode keycode = Get_InputKeyCode();
		if(keycode!=KeyCode.None)
		keysetting.CallKey(keycode);

	}
	private KeyCode Get_InputKeyCode()
	{
		if (!Input.anyKeyDown)
		{
			Debug.Log("�ƹ��Է¾���");
			return KeyCode.None;
		}

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			return KeyCode.Escape;
		}
		else if (Input.GetKeyDown(KeyCode.K))
		{
			return KeyCode.K;
		}
		Debug.Log("�ش� Ű�� ����");
		return KeyCode.None;
	}
	
	private void Awake()
	{
		//keysetting = new KeySetting();
		keysetting = GameObject.Find("KeySetting").GetComponent<KeySetting>();
		Debug.Log(keysetting);
	}

}
