using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void KeyEvent(UIType calltype);
public class KeySetting : MonoBehaviour
{
	private Dictionary<KeyCode, KeyEvent> Dic_KeyEvent;
	private Dictionary<KeyCode,UIType> keylist;
	public void SetKey(KeyCode keyname,KeyEvent keyfunc,UIType calltype)
	{
		Dic_KeyEvent.Add(keyname,keyfunc);
		keylist.Add(keyname,calltype);
	}
	public void CallKey(KeyCode keyname)
	{
		if (Dic_KeyEvent.ContainsKey(keyname))
		{
			Debug.Log(keyname);
			Dic_KeyEvent[keyname].Invoke(keylist[keyname]);
		}
	}
    void Awake()
    {
		Dic_KeyEvent = new Dictionary<KeyCode, KeyEvent>();
		keylist= new Dictionary<KeyCode, UIType>();
	}

    void Update()
    {
        
    }
}
