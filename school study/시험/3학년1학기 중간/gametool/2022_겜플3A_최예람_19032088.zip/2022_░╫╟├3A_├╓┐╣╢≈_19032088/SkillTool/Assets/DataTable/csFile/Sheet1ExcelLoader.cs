using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct Sheet1ExcelData
{
	public int No;
	public string NameKR;
	public string NameEN;
	public int CodeIndex;
	public int LevelCondition;
	public int TreeLevel;
	public int PrevSkillPointCondition;
	public int PrevCode;
	public int NextCode;
	public int MaxLevel;
	public int IconIndex;
	public Vector3 Position;
	public string SkillText;
}

[CreateAssetMenu(fileName="Sheet1ExcelLoader",menuName= "ExcelData/Sheet1ExcelLoader")]
public class Sheet1ExcelLoader : ScriptableObject
{
	[SerializeField] string filepath;
	public List<Sheet1ExcelData> DataList;

	private Sheet1ExcelData Read(string line)
	{
		line=line.TrimStart('\n');
		Sheet1ExcelData data= new Sheet1ExcelData();
		string[] strs= line.Split('`');

		int index=0;
		data.No=int.Parse(strs[index++]);
		data.NameKR= strs[index++];
		data.NameEN= strs[index++];
		data.CodeIndex=int.Parse(strs[index++]);
		data.LevelCondition=int.Parse(strs[index++]);
		data.TreeLevel=int.Parse(strs[index++]);
		data.PrevSkillPointCondition=int.Parse(strs[index++]);
		data.PrevCode=int.Parse(strs[index++]);
		data.NextCode=int.Parse(strs[index++]);
		data.MaxLevel=int.Parse(strs[index++]);
		data.IconIndex=int.Parse(strs[index++]);
		string vector_data=strs[index++];
		if(vector_data=="null")
		{
			data.Position= new Vector3();
		}
		else
		{
			string[] floatdata = vector_data.Split(',');
			data.Position= new Vector3(float.Parse(floatdata[0]),float.Parse(floatdata[1]),float.Parse(floatdata[2]));
		}
		data.SkillText= strs[index++];
		return data;
	}
	[ContextMenu("파일 읽기")]
	public void ReadAllFile()
	{
		string currentpath = System.IO.Directory.GetCurrentDirectory();
		DataList= new List<Sheet1ExcelData>();
		string alltxt= System.IO.File.ReadAllText(System.IO.Path.Combine(currentpath,filepath));
		string[] strs=alltxt.Split(';');
		foreach(var item in strs)
		{
			if(item.Length<2)
			continue;
			Sheet1ExcelData data = Read(item);
			DataList.Add(data);
		}
	}
}
