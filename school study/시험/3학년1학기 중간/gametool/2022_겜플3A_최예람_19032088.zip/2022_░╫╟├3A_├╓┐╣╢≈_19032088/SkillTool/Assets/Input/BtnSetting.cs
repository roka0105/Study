using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public delegate void BtnEvent(UIType uitype);
public enum E_BTNType
{
	None,
	ManagerMode,
	SaveSkill,
	SettingExit,
	SkillManagerExit,
	Bar,
	Max
}
public class BtnSetting : MonoBehaviour
{
	[SerializeField]
	private List<GameObject> BtnList = new List<GameObject>();

	
	Dictionary<E_BTNType, BtnEvent> m_BtnEvent = new Dictionary<E_BTNType, BtnEvent>();
	Dictionary<E_BTNType, UIType> m_btnlist=new Dictionary<E_BTNType, UIType>();
	
	public void SetBtn(E_BTNType btntype,BtnEvent btnevent,UIType uitype)
	{
		m_BtnEvent.Add(btntype, btnevent);
		m_btnlist.Add(btntype, uitype);
	}
	public void CallBtn(E_BTNType btntype)
	{
		if(m_BtnEvent.ContainsKey(btntype))
		{
			Debug.Log(btntype.ToString());
			UIType uitype = m_btnlist[btntype];
			m_BtnEvent[btntype].Invoke(uitype);
		}
	}

}
