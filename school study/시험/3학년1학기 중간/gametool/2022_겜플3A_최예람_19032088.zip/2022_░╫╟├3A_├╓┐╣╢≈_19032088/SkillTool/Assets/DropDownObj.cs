using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum E_DropDownLevelType
{
    None,
    Base,
    Tree1,
    Tree2,
    Tree3,
    Max
}
public class DropDownObj : MonoBehaviour
{
    E_DropDownLevelType e_droptype;
    UIManager M_UIManager => UIManager.Instance;
    int itemCode;
    private void Start()
    {
        switch(this.gameObject.name)
        {
            case "BaseSkill":
                e_droptype = E_DropDownLevelType.Base;
                break;
            case "TreeSkill_1":
                e_droptype = E_DropDownLevelType.Tree1;
                break;
            case "TreeSkill_2":
                e_droptype = E_DropDownLevelType.Tree2;
                break;
            case "TreeSkill_3":
                e_droptype = E_DropDownLevelType.Tree3;
                break;
        }
      
            
    }
    public void OnDropdownEvent(int index)
    {
        M_UIManager.ChangeNextDropDownInfo(e_droptype, index);
    }
}
