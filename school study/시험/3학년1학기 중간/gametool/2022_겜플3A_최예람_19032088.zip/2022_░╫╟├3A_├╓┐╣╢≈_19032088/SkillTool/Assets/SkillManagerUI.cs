using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using TMPro;

public class SkillManagerUI : MonoBehaviour
{
    SkillDataManager M_SkillDataManager => SkillDataManager.Instance;
    [SerializeField, Header("Dropdown")]
    TMP_Dropdown m_BaseSkill;

    TMP_Dropdown[] m_TreeSkill;
    [SerializeField, Header("�̸�����")]
    Image m_ShowSkillImage;
    [SerializeField]
    TMP_Text m_ShowSkillTxt;
    const int TREE_MAX = 4;

    Sprite[] Skill_Icons;
    List<Sheet1ExcelData>NextDropData;
    List<Sheet1ExcelData>[] CurrentDropData;
    int[] CurrentCode = new int[4];
    public void ChangeNextDropDownInfo(E_DropDownLevelType droplevel, int itemindex)
    {
        TMP_Dropdown drop_obj;
        TMP_Dropdown next_drop;
        string caption_txt = "";
        int treelevel = (int)droplevel;
        int itemidx = itemindex - 1;
        switch (droplevel)
        {
            case E_DropDownLevelType.Base:
                drop_obj = m_BaseSkill;
                next_drop = m_TreeSkill[0];
                m_TreeSkill[1].gameObject.SetActive(false);
                m_TreeSkill[2].gameObject.SetActive(false);
                CurrentCode[1] = 0;
                CurrentCode[2] = 0;
                CurrentCode[3] = 0;
                caption_txt = "��ų_" + 2;
                break;
            case E_DropDownLevelType.Tree1:
                drop_obj = m_TreeSkill[0];
                next_drop = m_TreeSkill[1];
                m_TreeSkill[2].gameObject.SetActive(false);
                CurrentCode[2] = 0;
                CurrentCode[3] = 0;
                caption_txt = "��ų_" + 3;
                break;
            case E_DropDownLevelType.Tree2:
                drop_obj = m_TreeSkill[1];
                next_drop = m_TreeSkill[2];
                CurrentCode[3] = 0;
                caption_txt = "��ų_" + 4;
                break;
            case E_DropDownLevelType.Tree3:
                drop_obj = m_TreeSkill[2];
                next_drop = null;
                break;
            default:
                drop_obj = null;
                next_drop = null;
                break;
        }
        if (drop_obj == null)
            return;
       
        if (treelevel - 1 == 0)
        {
            CurrentDropData[treelevel-1] = M_SkillDataManager.GetTreeAllData(treelevel);
            //m_ShowSkillTxt.text = CurrentDropData[treelevel - 1][itemidx].SkillText;
            //m_ShowSkillImage.sprite = Skill_Icons[CurrentDropData[treelevel - 1][itemidx].IconIndex];
            //CurrentCode[treelevel - 1] = CurrentDropData[treelevel - 1][itemidx].CodeIndex;
        }
        m_ShowSkillTxt.text = CurrentDropData[treelevel - 1][itemidx].SkillText;
        m_ShowSkillImage.sprite = Skill_Icons[CurrentDropData[treelevel - 1][itemidx].IconIndex];
        CurrentCode[treelevel - 1] = CurrentDropData[treelevel - 1][itemidx].CodeIndex; 
        if (next_drop == null && treelevel == 4)
            return;
        //������� ���� Ŭ������ ����.
        //���⼭���� Ŭ���� ���� ���� ���� ����.
        NextDropData = M_SkillDataManager.GetTreeData(CurrentCode[treelevel-1], treelevel);
        CurrentDropData[treelevel] = NextDropData;
        if (NextDropData.Count == 0)
        {
            if (next_drop != null)
                next_drop.gameObject.SetActive(false);
            next_drop = null;
        }
        
        if (next_drop != null)
        {
            next_drop.gameObject.SetActive(true);
            next_drop.ClearOptions();
            next_drop.value = -1;

            int limit = 0;
            for (int i = 0; i < NextDropData.Count+1; i++)
            {
                TMP_Dropdown.OptionData option = new TMP_Dropdown.OptionData();
                if (i==0)
                {
                    option.text = "����";
                    next_drop.options.Add(option);
                    continue;
                }
                Sheet1ExcelData data = NextDropData[i-1];
                option.text = data.NameKR;
                next_drop.options.Add(option);
            }
            next_drop.captionText.text = caption_txt;
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        CurrentDropData = new List<Sheet1ExcelData>[4];
        Skill_Icons = Resources.LoadAll<Sprite>("Skill_Icon/01-01");
        int count = Skill_Icons.Length;
        List<Sheet1ExcelData> datalist;

        m_TreeSkill = new TMP_Dropdown[TREE_MAX - 1];
        for (int i = 0; i < TREE_MAX - 1; ++i)
        {
            m_TreeSkill[i] = GameObject.Instantiate<TMP_Dropdown>(m_BaseSkill, this.gameObject.transform);
            Vector2 pos = m_TreeSkill[i].transform.position;
            pos.y -= 40 * (i + 1);
            m_TreeSkill[i].transform.position = pos;
            m_TreeSkill[i].name = "TreeSkill_" + (i + 1);
            datalist = M_SkillDataManager.GetTreeAllData(i + 2);
            m_TreeSkill[i].gameObject.SetActive(false);
        }
        datalist = M_SkillDataManager.GetTreeAllData(1);
        for (int i = 0; i < datalist.Count+1; i++)
        {
            TMP_Dropdown.OptionData option = new TMP_Dropdown.OptionData();
            if(i==0)
            {
                option.text = "����";
            }
            else
            option.text = datalist[i-1].NameKR;

            m_BaseSkill.options.Add(option);
            m_BaseSkill.value = -1;
        }
        m_BaseSkill.captionText.text = "��ų_1";

        DropDownObj drop_obj = m_BaseSkill.GetComponent<DropDownObj>();
        m_BaseSkill.onValueChanged.AddListener(drop_obj.OnDropdownEvent);
        for (int i = 0; i < TREE_MAX - 1; ++i)
        {
            drop_obj = m_TreeSkill[i].GetComponent<DropDownObj>();
            m_TreeSkill[i].onValueChanged.AddListener(drop_obj.OnDropdownEvent);
            m_TreeSkill[i].value = -1;
        }
        this.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

    }
}
