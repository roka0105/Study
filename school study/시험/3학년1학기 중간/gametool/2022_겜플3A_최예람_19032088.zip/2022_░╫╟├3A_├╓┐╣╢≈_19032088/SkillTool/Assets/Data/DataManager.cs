using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public enum DataTableType
{
	None,
	Sheet1,
	Sheet2,
	Max
}
public class DataManager : Singleton_Ver1.Singleton<DataManager>
{
	[SerializeField]
	private List<ScriptableObject> m_DataListPrefeb;

	public Dictionary<DataTableType, ScriptableObject> m_DataList;
	
	private void Awake()
	{
		m_DataList = new Dictionary<DataTableType, ScriptableObject>(); 
		
		for(DataTableType i=DataTableType.None+1;i<DataTableType.Max;i++)
		{
			m_DataList.Add(i, m_DataListPrefeb.Where(item => i.ToString() + "ExcelLoader" == item.name).SingleOrDefault());
		}
	}
	
	public T GetDataTable<T>() where T:ScriptableObject
	{
		int index = typeof(T).ToString().LastIndexOf("Excel");
		string typename = typeof(T).ToString().Substring(0, index);
		DataTableType type;
		if(Enum.TryParse<DataTableType>(typename,out type))
		{
			return m_DataList[type] as T;
		}
		return null;
	}

}
