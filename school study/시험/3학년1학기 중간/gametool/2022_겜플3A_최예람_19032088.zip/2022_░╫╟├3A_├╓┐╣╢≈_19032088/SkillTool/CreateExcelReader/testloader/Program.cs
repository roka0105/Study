﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
namespace CreateExcel
{
    class Program
    {
        static void Main(string[] arg)
        {
            string filepath = @"C:\Users\user\Desktop\SkillTool\SkillTool\DataTable";
            string excelName = "Skill.xlsx";
            string sheetName = "Sheet1";
            ExcelReader excel = new ExcelReader();
            if (!filepath.EndsWith("\\"))
                filepath += "\\";
            excel._Initialize(filepath + excelName);
            excel.ReadSheet(sheetName);
            excel._Finalize();
        }
    }
    class ExcelReader
    {
        Application m_Application = null;
        Workbook m_Workbook = null;
        string m_filepath;
        bool Is_finalcheck = false;
        public struct SheetPos
        {
            public int row_index;
            public int col_index;
            public SheetPos(int r, int c)
            {
                row_index = r;
                col_index = c;
            }
        }
        //초기화 (엑셀)
        public ExcelReader() { }
        public bool _Initialize(string path)
        {
            /*
			 * 1.어플리케이션 로드
			  2.워크북 로드
			*/
            m_Application = new Application();
            m_Workbook = m_Application.Workbooks.Open(path);
            m_filepath = path;
            return true;
        }
        //소멸작업 (엑셀)
        ~ExcelReader()
        {
            if (Is_finalcheck)
                _Finalize();
        }
        public void _Finalize()
        {
            Is_finalcheck = true;
            m_Workbook.Close();
            m_Application.Quit();
            ReleaseObject(m_Workbook);
            ReleaseObject(m_Application);

            GC.Collect();
        }
        void ReleaseObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception e)
            {
                obj = null;
                throw e;
            }
            finally
            {
                GC.Collect();
            }
        }
        //시트 읽기
        public void ReadSheet(string seetName)
        {
            Excel.Worksheet worksheet = m_Workbook.Worksheets.get_Item(seetName);
            /*읽을 범위 지정하기*/
            VPageBreak vPagestart = worksheet.VPageBreaks.Item[1];
            VPageBreak vPageend = worksheet.VPageBreaks.Item[2];
            HPageBreak hPagestart = worksheet.HPageBreaks.Item[1];
            HPageBreak hPageend = worksheet.HPageBreaks.Item[2];

            Excel.Range vPagestart_Range = vPagestart.Location;
            Excel.Range vPageend_Range = vPageend.Location;
            Excel.Range hPagestart_Range = hPagestart.Location;
            Excel.Range hPageend_Range = hPageend.Location;

            WriteFile(worksheet, vPagestart_Range.Column, vPageend_Range.Column, hPagestart_Range.Row, hPageend_Range.Row);

            ReleaseObject(vPagestart_Range);
            ReleaseObject(vPageend_Range);
            ReleaseObject(hPagestart_Range);
            ReleaseObject(hPageend_Range);

            ReleaseObject(vPagestart);
            ReleaseObject(hPagestart);
            ReleaseObject(vPageend);
            ReleaseObject(hPageend);

            ReleaseObject(worksheet);
        }

        public void WriteFile(Excel.Worksheet sheet, int left, int right, int top, int bottom)
        {
            /*
			 엑셀 데이터 읽어와서 cvs로 만들기
			 엑셀 데이터 토대로 script 만들기 
			 */
            int idx = m_filepath.LastIndexOf("\\");
            string sheetName = sheet.Name;
            string structName = sheetName + "ExcelData";
            string savepath_cs = System.IO.Path.Combine(m_filepath.Substring(0, idx), sheetName + "ExcelLoader" + ".cs");
            string savepath_txt = System.IO.Path.Combine(m_filepath.Substring(0, idx), sheetName + ".txt");
            StringBuilder sb = new StringBuilder();

            #region create cs file
            sb.Append("using System.Collections.Generic;\n");
            sb.Append("using UnityEngine;\n\n");

            List<string> types = new List<string>();
            List<string> names = new List<string>();
            //구조체
            sb.Append("[System.Serializable]\n");
            sb.Append("public struct " + structName + "\n");
            sb.Append("{\n");

            for (int i = left; i != right; ++i)
            {
                Excel.Range typename_range = sheet.Cells[top + 1, i];
                Excel.Range dataname_range = sheet.Cells[top, i];

                string typename = typename_range.Value2.ToString();
                string dataname = dataname_range.Value2.ToString();
                types.Add(typename);
                names.Add(dataname);

                sb.Append("\tpublic " + typename + " " + dataname + ";\n");
                ReleaseObject(typename_range);
                ReleaseObject(dataname_range);
            }
            sb.Append("}\n\n");

            // 클래스
            string tab = "\t";
            sb.Append("[CreateAssetMenu(fileName=\"" + sheetName + "ExcelLoader\"," + "menuName= \"ExcelData/" + sheetName + "ExcelLoader\")]\n");
            sb.Append("public class " + sheetName + "ExcelLoader : ScriptableObject\n");
            sb.Append("{\n");
            sb.Append(tab + "[SerializeField] string filepath;\n");
            sb.Append(tab + "public List<" + structName + "> DataList;\n\n");


            sb.Append(tab + "private " + structName + " Read(string line)\n");
            sb.Append(tab + "{\n");
            tab += '\t';
            sb.Append(tab + "line=line.TrimStart('\\n');\n");
            sb.Append(tab + structName + " data= new " + structName + "();\n");
            sb.Append(tab + "string[] strs= line.Split('`');\n\n");
            sb.Append(tab + "int index=0;\n");

            for (int i = 0; i < types.Count; i++)
            {
                switch (types[i])
                {
                    case "string":
                        sb.Append(tab + "data." + names[i] + "= strs[index++];\n");
                        break;
                    case "Vector3":
                        {
                            sb.Append(tab + "string vector_data=strs[index++];\n");
                            sb.Append(tab + "if(vector_data==\"null\")\n");
                            sb.Append(tab + "{\n");
                            tab += '\t';
                            sb.Append(tab + "data." + names[i] + "= new Vector3();\n");
                            tab = tab.Remove(tab.Length - 1);
                            sb.Append(tab + "}\n");

                            sb.Append(tab + "else\n");
                            sb.Append(tab + "{\n");
                            tab += '\t';
                            sb.Append(tab + "string[] floatdata = vector_data.Split(',');\n");
                            sb.Append(tab + "data." + names[i] + "= new Vector3(float.Parse(floatdata[0]),float.Parse(floatdata[1]),float.Parse(floatdata[2]));\n");
                            tab = tab.Remove(tab.Length - 1);
                            sb.Append(tab + "}\n");
                            break;
                        }
                    default:
                        sb.Append(tab + "data." + names[i] + "=" + types[i] + ".Parse(strs[index++]);\n");
                        break;
                }
            }
            sb.Append(tab + "return data;\n");
            tab = tab.Remove(tab.Length - 1);
            sb.Append(tab + "}\n");

            sb.Append(tab + "[ContextMenu(\"파일 읽기\")]\n");
            sb.Append(tab + "public void ReadAllFile()\n");
            sb.Append(tab + "{\n");
            tab += '\t';
            sb.Append(tab + "string currentpath = System.IO.Directory.GetCurrentDirectory();\n");
            sb.Append(tab + "DataList= new List<" + structName + ">();\n");
            sb.Append(tab + "string alltxt= System.IO.File.ReadAllText(System.IO.Path.Combine(currentpath,filepath));\n");
            sb.Append(tab + "string[] strs=alltxt.Split(\';\');\n");

            sb.Append(tab + "foreach(var item in strs)\n");

            sb.Append(tab + "{\n");
            tab += '\t';
            sb.Append(tab + "if(item.Length<2)\n");
            sb.Append(tab + "continue;\n");
            sb.Append(tab + structName + " data = " + "Read(item);\n");
            sb.Append(tab + "DataList.Add(data);\n");
            tab = tab.Remove(tab.Length - 1);
            sb.Append(tab + "}\n");
            tab = tab.Remove(tab.Length - 1);
            sb.Append(tab + "}\n");
            tab = tab.Remove(tab.Length - 1);
            sb.Append("}\n");


            CreateFile(savepath_cs);
            SaveFile(savepath_cs, sb.ToString());
            #endregion
            #region create txt file
            sb.Length = 0;

            for (int j = top + 2; j < bottom; j++)
            {
                for (int i = left; i < right; i++)
                {
                    try
                    {
                        Excel.Range r = sheet.Cells[j, i];
                        sb.Append(r.Value2.ToString());
                        sb.Append("`");
                        ReleaseObject(r);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(i + "번 줄," + j + "번 칸");
                        throw;
                    }
                }
                --sb.Length;
                sb.Append(";\n");
            }
            --sb.Length;

            CreateFile(savepath_txt);
            SaveFile(savepath_txt, sb.ToString());

            #endregion

        }
        void CreateFile(string path)
        {
            if (System.IO.File.Exists(path))
            {
                FileStream fs = System.IO.File.Create(path);
                fs.Close();
            }
        }
        void SaveFile(string path, string text)
        {
            System.IO.File.WriteAllText(path, text);
        }
    }

}